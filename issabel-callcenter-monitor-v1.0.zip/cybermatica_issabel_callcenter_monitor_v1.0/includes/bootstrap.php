<?php
$config = require dirname(__DIR__) . '/config.php';

date_default_timezone_set(isset($config['app']['timezone']) ? $config['app']['timezone'] : 'America/Asuncion');

if (!empty($config['app']['debug'])) {
    ini_set('display_errors', '1');
    ini_set('display_startup_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED & ~E_STRICT);
}

if (session_status() === PHP_SESSION_NONE) {
    $sessionName = isset($config['auth']['session_name']) ? $config['auth']['session_name'] : 'ISSABEL_CC_PANEL';
    session_name($sessionName);
    session_start();
}

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/SimplePdf.php';
require_once __DIR__ . '/ReportRepository.php';
require_once __DIR__ . '/AnalyticsRepository.php';
require_once __DIR__ . '/AmiClient.php';
