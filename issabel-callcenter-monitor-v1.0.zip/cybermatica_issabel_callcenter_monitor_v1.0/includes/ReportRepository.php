<?php
class ReportRepository
{
    private $ccAgent;
    private $ccAudit;
    private $ccBreak;
    private $ccCallEntry;
    private $ccCalls;
    private $ccCampaign;
    private $ccCampaignEntry;
    private $ccQueue;
    private $ccRecording;
    private $ccProgress;
    private $ccCurrentCalls;
    private $ccCurrentCallEntry;
    private $ccFormDataOut;
    private $ccFormDataIn;
    private $ccFormField;
    private $cdr;
    private $cel;

    public function __construct()
    {
        $this->ccAgent = DB::q('call_center', 'agent');
        $this->ccAudit = DB::q('call_center', 'audit');
        $this->ccBreak = DB::q('call_center', 'break');
        $this->ccCallEntry = DB::q('call_center', 'call_entry');
        $this->ccCalls = DB::q('call_center', 'calls');
        $this->ccCampaign = DB::q('call_center', 'campaign');
        $this->ccCampaignEntry = DB::q('call_center', 'campaign_entry');
        $this->ccQueue = DB::q('call_center', 'queue_call_entry');
        $this->ccRecording = DB::q('call_center', 'call_recording');
        $this->ccProgress = DB::q('call_center', 'call_progress_log');
        $this->ccCurrentCalls = DB::q('call_center', 'current_calls');
        $this->ccCurrentCallEntry = DB::q('call_center', 'current_call_entry');
        $this->ccFormDataOut = DB::q('call_center', 'form_data_recolected');
        $this->ccFormDataIn = DB::q('call_center', 'form_data_recolected_entry');
        $this->ccFormField = DB::q('call_center', 'form_field');
        $this->cdr = DB::q('cdr', 'cdr');
        $this->cel = DB::q('cdr', 'cel');
    }

    public function getAgents()
    {
        // Se muestran solo agentes activos y se evita duplicar extensiones recreadas.
        // Si el admin elimina y vuelve a crear el agente 106, queda visible solo el registro activo más reciente.
        $sql = "SELECT id, type, number, name, estatus FROM {$this->ccAgent} WHERE estatus = 'A' ORDER BY CAST(number AS UNSIGNED), number, id DESC";
        $rows = DB::fetchAll($sql);
        $seen = array();
        $out = array();
        foreach ($rows as $r) {
            $key = trim((string)$r['number']);
            if ($key === '') { $key = 'id_' . (int)$r['id']; }
            if (isset($seen[$key])) continue;
            $seen[$key] = true;
            $out[] = $r;
        }
        return $out;
    }

    public function getBreaks()
    {
        $sql = "SELECT id, name, description, status, tipo FROM {$this->ccBreak} WHERE status = 'A' ORDER BY name";
        return DB::fetchAll($sql);
    }

    private function agentFilter($alias, $agentId, &$params)
    {
        if ($agentId !== null && $agentId !== '') {
            $params[':agent_id'] = (int)$agentId;
            return " AND {$alias}.id_agent = :agent_id ";
        }
        return '';
    }

    private function cdrAgentFilter($agentId, &$params)
    {
        if ($agentId !== null && $agentId !== '') {
            $params[':cdr_agent_id'] = (int)$agentId;
            return " AND a.id = :cdr_agent_id ";
        }
        return '';
    }

    public function getSummary($from, $to, $agentId = null, $includeCallbacks = true)
    {
        $summary = array(
            'incoming' => 0,
            'outgoing_campaign' => 0,
            'manual_outgoing' => 0,
            'manual_incoming' => 0,
            'total_calls' => 0,
            'abandoned' => 0,
            'transferred' => 0,
            'talk_seconds' => 0,
            'total_duration_seconds' => 0,
            'pause_count' => 0,
            'pause_seconds' => 0,
            'session_count' => 0,
            'session_seconds' => 0,
            'forms_count' => 0,
            'callbacks_done' => 0,
            'callbacks_pending' => 0,
        );

        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->agentFilter('ce', $agentId, $params);
        $row = DB::fetch("SELECT COUNT(*) total, SUM(IFNULL(ce.duration,0)) talk, SUM(TIMESTAMPDIFF(SECOND, COALESCE(ce.datetime_entry_queue, ce.datetime_init), COALESCE(ce.datetime_end, ce.datetime_init, ce.datetime_entry_queue))) total_duration, SUM(CASE WHEN ce.transfer IS NOT NULL AND ce.transfer<>'' THEN 1 ELSE 0 END) transferred FROM {$this->ccCallEntry} ce WHERE COALESCE(ce.datetime_init, ce.datetime_entry_queue) >= :from AND COALESCE(ce.datetime_init, ce.datetime_entry_queue) < :to {$agentSql}", $params);
        if ($row) {
            $summary['incoming'] = (int)$row['total'];
            $summary['talk_seconds'] += (int)$row['talk'];
            $summary['total_duration_seconds'] += (int)$row['total_duration'];
            $summary['transferred'] += (int)$row['transferred'];
        }

        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->agentFilter('c', $agentId, $params);
        $row = DB::fetch("SELECT COUNT(*) total, SUM(IFNULL(c.duration,0)) talk, SUM(TIMESTAMPDIFF(SECOND, COALESCE(c.datetime_entry_queue, c.datetime_originate, c.fecha_llamada, c.start_time), COALESCE(c.end_time, c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue))) total_duration, SUM(CASE WHEN c.transfer IS NOT NULL AND c.transfer<>'' THEN 1 ELSE 0 END) transferred FROM {$this->ccCalls} c WHERE COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue) >= :from AND COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue) < :to {$agentSql}", $params);
        if ($row) {
            $summary['outgoing_campaign'] = (int)$row['total'];
            $summary['talk_seconds'] += (int)$row['talk'];
            $summary['total_duration_seconds'] += (int)$row['total_duration'];
            $summary['transferred'] += (int)$row['transferred'];
        }

        $params = array(':from' => $from, ':to' => $to);
        $agentCdrSql = $this->cdrAgentFilter($agentId, $params);
        $row = DB::fetch("SELECT COUNT(DISTINCT COALESCE(NULLIF(cd.linkedid,''), cd.uniqueid)) total, SUM(cd.billsec) talk, SUM(cd.duration) total_duration FROM {$this->cdr} cd INNER JOIN {$this->ccAgent} a ON (a.number = cd.src OR cd.channel LIKE CONCAT('PJSIP/', a.number, '-%') OR cd.channel LIKE CONCAT('SIP/', a.number, '-%') OR cd.channel LIKE CONCAT('IAX2/', a.number, '-%')) WHERE cd.calldate >= :from AND cd.calldate < :to {$agentCdrSql} AND cd.dst NOT IN (SELECT number FROM {$this->ccAgent}) AND NOT EXISTS (SELECT 1 FROM {$this->ccCalls} c WHERE c.uniqueid IS NOT NULL AND c.uniqueid <> '' AND (c.uniqueid = cd.uniqueid OR c.uniqueid = cd.linkedid)) AND NOT EXISTS (SELECT 1 FROM {$this->ccCallEntry} ce WHERE ce.uniqueid IS NOT NULL AND ce.uniqueid <> '' AND (ce.uniqueid = cd.uniqueid OR ce.uniqueid = cd.linkedid))", $params);
        if ($row) {
            $summary['manual_outgoing'] = (int)$row['total'];
            $summary['talk_seconds'] += (int)$row['talk'];
            $summary['total_duration_seconds'] += (int)$row['total_duration'];
        }

        $params = array(':from' => $from, ':to' => $to);
        $agentCdrSql = $this->cdrAgentFilter($agentId, $params);
        $row = DB::fetch("SELECT COUNT(DISTINCT COALESCE(NULLIF(cd.linkedid,''), cd.uniqueid)) total, SUM(cd.billsec) talk, SUM(cd.duration) total_duration FROM {$this->cdr} cd INNER JOIN {$this->ccAgent} a ON (cd.dst = a.number OR cd.dstchannel LIKE CONCAT('PJSIP/', a.number, '-%') OR cd.dstchannel LIKE CONCAT('SIP/', a.number, '-%') OR cd.dstchannel LIKE CONCAT('IAX2/', a.number, '-%')) WHERE cd.calldate >= :from AND cd.calldate < :to {$agentCdrSql} AND cd.src NOT IN (SELECT number FROM {$this->ccAgent}) AND NOT EXISTS (SELECT 1 FROM {$this->ccCallEntry} ce WHERE ce.uniqueid IS NOT NULL AND ce.uniqueid <> '' AND (ce.uniqueid = cd.uniqueid OR ce.uniqueid = cd.linkedid))", $params);
        if ($row) {
            $summary['manual_incoming'] = (int)$row['total'];
            $summary['talk_seconds'] += (int)$row['talk'];
            $summary['total_duration_seconds'] += (int)$row['total_duration'];
        }

        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->agentFilter('ce', $agentId, $params);
        $summary['abandoned'] = (int)DB::value("SELECT COUNT(*) FROM {$this->ccCallEntry} ce WHERE ce.datetime_entry_queue >= :from AND ce.datetime_entry_queue < :to {$agentSql} AND (ce.id_agent IS NULL OR ce.status LIKE '%abandon%' OR ce.status LIKE '%ABANDON%' OR ce.status LIKE '%Abandon%')", $params, 0);

        $pause = $this->getPauseTotals($from, $to, $agentId);
        $summary['pause_count'] = (int)$pause['count'];
        $summary['pause_seconds'] = (int)$pause['seconds'];
        $session = $this->getSessionTotals($from, $to, $agentId);
        $summary['session_count'] = (int)$session['count'];
        $summary['session_seconds'] = (int)$session['seconds'];
        $summary['forms_count'] = (int)$this->getFormsCount($from, $to, $agentId);

        if ($includeCallbacks) {
            $callbacks = $this->getCallbacks($from, $to, $agentId, 5000);
            foreach ($callbacks as $cb) {
                if ($cb['devuelta'] === 'Sí') $summary['callbacks_done']++; else $summary['callbacks_pending']++;
            }
        }

        $summary['total_calls'] = $summary['incoming'] + $summary['outgoing_campaign'] + $summary['manual_outgoing'] + $summary['manual_incoming'];
        return $summary;
    }

    private function getPauseTotals($from, $to, $agentId = null)
    {
        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->agentFilter('au', $agentId, $params);
        $row = DB::fetch("SELECT COUNT(*) count, SUM(TIMESTAMPDIFF(SECOND, GREATEST(au.datetime_init, :from), LEAST(COALESCE(au.datetime_end, NOW()), :to))) seconds FROM {$this->ccAudit} au WHERE au.id_break IS NOT NULL AND au.datetime_init < :to AND COALESCE(au.datetime_end, NOW()) > :from {$agentSql}", $params);
        return array('count' => isset($row['count']) ? $row['count'] : 0, 'seconds' => isset($row['seconds']) ? $row['seconds'] : 0);
    }

    private function getSessionTotals($from, $to, $agentId = null)
    {
        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->agentFilter('au', $agentId, $params);
        $row = DB::fetch("SELECT COUNT(*) count, SUM(TIMESTAMPDIFF(SECOND, GREATEST(au.datetime_init, :from), LEAST(COALESCE(au.datetime_end, NOW()), :to))) seconds FROM {$this->ccAudit} au WHERE au.id_break IS NULL AND au.datetime_init < :to AND COALESCE(au.datetime_end, NOW()) > :from {$agentSql}", $params);
        return array('count' => isset($row['count']) ? $row['count'] : 0, 'seconds' => isset($row['seconds']) ? $row['seconds'] : 0);
    }

    private function getFormsCount($from, $to, $agentId = null)
    {
        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->agentFilter('c', $agentId, $params);
        $out = (int)DB::value("SELECT COUNT(DISTINCT f.id_calls) FROM {$this->ccFormDataOut} f INNER JOIN {$this->ccCalls} c ON c.id = f.id_calls WHERE COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue) >= :from AND COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue) < :to {$agentSql}", $params, 0);
        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->agentFilter('ce', $agentId, $params);
        $in = (int)DB::value("SELECT COUNT(DISTINCT f.id_call_entry) FROM {$this->ccFormDataIn} f INNER JOIN {$this->ccCallEntry} ce ON ce.id = f.id_call_entry WHERE COALESCE(ce.datetime_init, ce.datetime_entry_queue) >= :from AND COALESCE(ce.datetime_init, ce.datetime_entry_queue) < :to {$agentSql}", $params, 0);
        return $out + $in;
    }

    public function getAgentPerformance($from, $to, $agentId = null)
    {
        $agents = $this->getAgents();
        $returnedAbandonedByAgent = array();
        $callbacksForTotals = $this->getCallbacks($from, $to, null, (int)app_config('app.max_export_rows', 30000));
        foreach ($callbacksForTotals as $cb) {
            if (!isset($cb['devuelta']) || $cb['devuelta'] !== 'Sí') continue;
            // Se cuenta por número de agente/extensión, no por ID, para evitar problemas
            // cuando el admin elimina y recrea un agente con el mismo número.
            $agentDevNumber = isset($cb['agente_devolvio_numero']) ? trim((string)$cb['agente_devolvio_numero']) : '';
            if ($agentDevNumber !== '') {
                if (!isset($returnedAbandonedByAgent[$agentDevNumber])) $returnedAbandonedByAgent[$agentDevNumber] = 0;
                $returnedAbandonedByAgent[$agentDevNumber]++;
            }
        }
        $result = array();
        foreach ($agents as $a) {
            if ($agentId !== null && (int)$a['id'] !== (int)$agentId) continue;
            $s = $this->getSummary($from, $to, (int)$a['id'], false);
            $occupancy = $s['session_seconds'] > 0 ? round(($s['talk_seconds'] / $s['session_seconds']) * 100, 2) : 0;
            $pauseRate = $s['session_seconds'] > 0 ? round(($s['pause_seconds'] / $s['session_seconds']) * 100, 2) : 0;
            $agentKeyId = (int)$a['id'];
            $agentKeyNumber = trim((string)$a['number']);
            $abandonedReturned = 0;
            if (isset($returnedAbandonedByAgent[$agentKeyId])) {
                $abandonedReturned += (int)$returnedAbandonedByAgent[$agentKeyId];
            }
            if ($agentKeyNumber !== '' && isset($returnedAbandonedByAgent[$agentKeyNumber])) {
                $abandonedReturned += (int)$returnedAbandonedByAgent[$agentKeyNumber];
            }
            $result[] = array(
                'id_agent' => $a['id'],
                'agente' => $a['number'],
                'nombre' => $a['name'],
                'tipo' => $a['type'],
                'estado' => $a['estatus'],
                'recibidas' => $s['incoming'] + $s['manual_incoming'],
                'realizadas' => $s['outgoing_campaign'] + $s['manual_outgoing'],
                'campania_saliente' => $s['outgoing_campaign'],
                'manuales_salientes' => $s['manual_outgoing'],
                'manuales_entrantes' => $s['manual_incoming'],
                'abandonadas' => $s['abandoned'],
                'abandonadas_devueltas' => $abandonedReturned,
                'devueltas' => $abandonedReturned,
                'transferidas' => $s['transferred'],
                'tiempo_hablado' => seconds_to_hms($s['talk_seconds']),
                'tiempo_hablado_seg' => $s['talk_seconds'],
                'sesiones' => $s['session_count'],
                'tiempo_sesion' => seconds_to_hms($s['session_seconds']),
                'tiempo_sesion_seg' => $s['session_seconds'],
                'pausas' => $s['pause_count'],
                'tiempo_pausa' => seconds_to_hms($s['pause_seconds']),
                'tiempo_pausa_seg' => $s['pause_seconds'],
                'ocupacion_pct' => $occupancy . '%',
                'pausa_pct' => $pauseRate . '%',
                'formularios' => $s['forms_count'],
            );
        }
        return $result;
    }

    public function getUnifiedCalls($from, $to, $agentId = null, $type = '', $limit = 5000)
    {
        $rows = array();
        if ($type === '' || $type === 'entrante_callcenter') {
            $params = array(':from' => $from, ':to' => $to);
            $agentSql = $this->agentFilter('ce', $agentId, $params);
            $sql = "SELECT 'entrante_callcenter' tipo_llamada, ce.id id_origen, ce.uniqueid, ce.uniqueid linkedid, COALESCE(ce.datetime_init, ce.datetime_entry_queue) fecha_inicio, ce.datetime_end fecha_fin, ce.callerid numero_cliente, a.id id_agent, a.number agente, a.name nombre, a.type tipo_agente, ce.duration tiempo_hablado_seg, TIMESTAMPDIFF(SECOND, COALESCE(ce.datetime_entry_queue, ce.datetime_init), COALESCE(ce.datetime_end, ce.datetime_init, ce.datetime_entry_queue)) duracion_total_seg, ce.duration_wait espera_seg, ce.status estado, ce.transfer transferencia, ce.trunk troncal, q.queue cola, camp.name campania, cr.recordingfile grabacion FROM {$this->ccCallEntry} ce LEFT JOIN {$this->ccAgent} a ON a.id=ce.id_agent LEFT JOIN {$this->ccQueue} q ON q.id=ce.id_queue_call_entry LEFT JOIN {$this->ccCampaignEntry} camp ON camp.id=ce.id_campaign LEFT JOIN {$this->ccRecording} cr ON cr.id_call_incoming=ce.id WHERE COALESCE(ce.datetime_init, ce.datetime_entry_queue) >= :from AND COALESCE(ce.datetime_init, ce.datetime_entry_queue) < :to {$agentSql} ORDER BY fecha_inicio DESC LIMIT " . (int)$limit;
            $rows = array_merge($rows, DB::fetchAll($sql, $params));
        }
        if ($type === '' || $type === 'saliente_campania') {
            $params = array(':from' => $from, ':to' => $to);
            $agentSql = $this->agentFilter('c', $agentId, $params);
            $sql = "SELECT 'saliente_campania' tipo_llamada, c.id id_origen, c.uniqueid, c.uniqueid linkedid, COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue) fecha_inicio, c.end_time fecha_fin, c.phone numero_cliente, a.id id_agent, a.number agente, a.name nombre, a.type tipo_agente, c.duration tiempo_hablado_seg, TIMESTAMPDIFF(SECOND, COALESCE(c.datetime_entry_queue, c.datetime_originate, c.fecha_llamada, c.start_time), COALESCE(c.end_time, c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue)) duracion_total_seg, c.duration_wait espera_seg, c.status estado, c.transfer transferencia, c.trunk troncal, NULL cola, camp.name campania, cr.recordingfile grabacion FROM {$this->ccCalls} c LEFT JOIN {$this->ccAgent} a ON a.id=c.id_agent LEFT JOIN {$this->ccCampaign} camp ON camp.id=c.id_campaign LEFT JOIN {$this->ccRecording} cr ON cr.id_call_outgoing=c.id WHERE COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue) >= :from AND COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue) < :to {$agentSql} ORDER BY fecha_inicio DESC LIMIT " . (int)$limit;
            $rows = array_merge($rows, DB::fetchAll($sql, $params));
        }
        if ($type === '' || $type === 'manual_saliente') {
            $params = array(':from' => $from, ':to' => $to);
            $agentSql = $this->cdrAgentFilter($agentId, $params);
            $sql = "SELECT 'manual_saliente' tipo_llamada, cd.sequence id_origen, cd.uniqueid, cd.linkedid, cd.calldate fecha_inicio, DATE_ADD(cd.calldate, INTERVAL cd.duration SECOND) fecha_fin, cd.dst numero_cliente, a.id id_agent, a.number agente, a.name nombre, a.type tipo_agente, cd.billsec tiempo_hablado_seg, cd.duration duracion_total_seg, 0 espera_seg, cd.disposition estado, '' transferencia, '' troncal, NULL cola, 'Manual por extensión' campania, cd.recordingfile grabacion FROM {$this->cdr} cd INNER JOIN {$this->ccAgent} a ON (a.number = cd.src OR cd.channel LIKE CONCAT('PJSIP/', a.number, '-%') OR cd.channel LIKE CONCAT('SIP/', a.number, '-%') OR cd.channel LIKE CONCAT('IAX2/', a.number, '-%')) WHERE cd.calldate >= :from AND cd.calldate < :to {$agentSql} AND cd.dst NOT IN (SELECT number FROM {$this->ccAgent}) AND NOT EXISTS (SELECT 1 FROM {$this->ccCalls} c WHERE c.uniqueid IS NOT NULL AND c.uniqueid <> '' AND (c.uniqueid = cd.uniqueid OR c.uniqueid = cd.linkedid)) AND NOT EXISTS (SELECT 1 FROM {$this->ccCallEntry} ce WHERE ce.uniqueid IS NOT NULL AND ce.uniqueid <> '' AND (ce.uniqueid = cd.uniqueid OR ce.uniqueid = cd.linkedid)) ORDER BY cd.calldate DESC LIMIT " . (int)$limit;
            $rows = array_merge($rows, DB::fetchAll($sql, $params));
        }
        if ($type === '' || $type === 'manual_entrante') {
            $params = array(':from' => $from, ':to' => $to);
            $agentSql = $this->cdrAgentFilter($agentId, $params);
            $sql = "SELECT 'manual_entrante' tipo_llamada, cd.sequence id_origen, cd.uniqueid, cd.linkedid, cd.calldate fecha_inicio, DATE_ADD(cd.calldate, INTERVAL cd.duration SECOND) fecha_fin, cd.src numero_cliente, a.id id_agent, a.number agente, a.name nombre, a.type tipo_agente, cd.billsec tiempo_hablado_seg, cd.duration duracion_total_seg, 0 espera_seg, cd.disposition estado, '' transferencia, '' troncal, NULL cola, 'Manual por extensión' campania, cd.recordingfile grabacion FROM {$this->cdr} cd INNER JOIN {$this->ccAgent} a ON (cd.dst = a.number OR cd.dstchannel LIKE CONCAT('PJSIP/', a.number, '-%') OR cd.dstchannel LIKE CONCAT('SIP/', a.number, '-%') OR cd.dstchannel LIKE CONCAT('IAX2/', a.number, '-%')) WHERE cd.calldate >= :from AND cd.calldate < :to {$agentSql} AND cd.src NOT IN (SELECT number FROM {$this->ccAgent}) AND NOT EXISTS (SELECT 1 FROM {$this->ccCallEntry} ce WHERE ce.uniqueid IS NOT NULL AND ce.uniqueid <> '' AND (ce.uniqueid = cd.uniqueid OR ce.uniqueid = cd.linkedid)) ORDER BY cd.calldate DESC LIMIT " . (int)$limit;
            $rows = array_merge($rows, DB::fetchAll($sql, $params));
        }
        usort($rows, function($a, $b) {
            return strcmp($b['fecha_inicio'], $a['fecha_inicio']);
        });
        if (count($rows) > $limit) $rows = array_slice($rows, 0, $limit);
        foreach ($rows as &$r) {
            $r['tiempo_hablado'] = seconds_to_hms(isset($r['tiempo_hablado_seg']) ? $r['tiempo_hablado_seg'] : 0);
            $r['duracion_total'] = seconds_to_hms(isset($r['duracion_total_seg']) ? $r['duracion_total_seg'] : 0);
            $r['espera'] = seconds_to_hms(isset($r['espera_seg']) ? $r['espera_seg'] : 0);
            $r['transferida'] = !empty($r['transferencia']) ? 'Sí' : 'No';
        }
        return $rows;
    }

    public function getPauses($from, $to, $agentId = null, $breakId = null)
    {
        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->agentFilter('au', $agentId, $params);
        $breakSql = '';
        if ($breakId !== null && $breakId !== '') {
            $params[':break_id'] = (int)$breakId;
            $breakSql = ' AND au.id_break = :break_id ';
        }
        $sql = "SELECT a.id id_agent, a.number agente, a.name nombre, a.type tipo_agente, b.name motivo, COUNT(*) cantidad, SUM(TIMESTAMPDIFF(SECOND, GREATEST(au.datetime_init, :from), LEAST(COALESCE(au.datetime_end, NOW()), :to))) tiempo_seg, MIN(au.datetime_init) primera, MAX(COALESCE(au.datetime_end, au.datetime_init)) ultima FROM {$this->ccAudit} au INNER JOIN {$this->ccAgent} a ON a.id=au.id_agent LEFT JOIN {$this->ccBreak} b ON b.id=au.id_break WHERE au.id_break IS NOT NULL AND au.datetime_init < :to AND COALESCE(au.datetime_end, NOW()) > :from {$agentSql} {$breakSql} GROUP BY a.id, a.number, a.name, a.type, b.name ORDER BY a.number, tiempo_seg DESC";
        $rows = DB::fetchAll($sql, $params);
        foreach ($rows as &$r) {
            $r['tiempo_pausa'] = seconds_to_hms($r['tiempo_seg']);
            $r['promedio_pausa'] = seconds_to_hms($r['cantidad'] > 0 ? $r['tiempo_seg'] / $r['cantidad'] : 0);
        }
        return $rows;
    }

    public function getSessions($from, $to, $agentId = null)
    {
        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->agentFilter('au', $agentId, $params);
        $sql = "SELECT a.id id_agent, a.number agente, a.name nombre, a.type tipo_agente, au.login_extension, COUNT(*) sesiones, SUM(TIMESTAMPDIFF(SECOND, GREATEST(au.datetime_init, :from), LEAST(COALESCE(au.datetime_end, NOW()), :to))) tiempo_seg, MIN(au.datetime_init) primer_login, MAX(COALESCE(au.datetime_end, au.datetime_init)) ultimo_logout FROM {$this->ccAudit} au INNER JOIN {$this->ccAgent} a ON a.id=au.id_agent WHERE au.id_break IS NULL AND au.datetime_init < :to AND COALESCE(au.datetime_end, NOW()) > :from {$agentSql} GROUP BY a.id, a.number, a.name, a.type, au.login_extension ORDER BY a.number";
        $rows = DB::fetchAll($sql, $params);
        foreach ($rows as &$r) {
            $r['tiempo_sesion'] = seconds_to_hms($r['tiempo_seg']);
        }
        return $rows;
    }

    public function getLoggedByHour($from, $to, $agentId = null)
    {
        $hours = array();
        $start = new DateTime($from);
        $end = new DateTime($to);
        $start->setTime((int)$start->format('H'), 0, 0);
        while ($start < $end) {
            $hourStart = $start->format('Y-m-d H:00:00');
            $hourEndObj = clone $start;
            $hourEndObj->modify('+1 hour');
            $hourEnd = $hourEndObj->format('Y-m-d H:00:00');
            $params = array(':hour_start' => $hourStart, ':hour_end' => $hourEnd);
            $agentSql = '';
            if ($agentId !== null && $agentId !== '') {
                $params[':agent_id'] = (int)$agentId;
                $agentSql = ' AND au.id_agent = :agent_id ';
            }
            // Se mide solapamiento con toda la hora, no solo el punto exacto HH:00.
            $sql = "SELECT COUNT(DISTINCT au.id_agent) total, GROUP_CONCAT(DISTINCT CONCAT(a.number, ' - ', a.name) ORDER BY a.number SEPARATOR ', ') agentes FROM {$this->ccAudit} au INNER JOIN {$this->ccAgent} a ON a.id=au.id_agent WHERE au.id_break IS NULL AND au.datetime_init < :hour_end AND COALESCE(au.datetime_end, NOW()) > :hour_start {$agentSql}";
            $row = DB::fetch($sql, $params);
            if (!$row) { $row = array('total' => 0, 'agentes' => ''); }
            $hours[] = array('hora' => $hourStart, 'agentes_logueados' => isset($row['total']) ? (int)$row['total'] : 0, 'detalle_agentes' => isset($row['agentes']) ? (string)$row['agentes'] : '');
            $start->modify('+1 hour');
        }
        return $hours;
    }

    public function getAbandoned($from, $to, $agentId = null, $limit = 5000)
    {
        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->agentFilter('ce', $agentId, $params);
        $sql = "SELECT ce.id, ce.callerid numero_cliente, ce.datetime_entry_queue fecha_abandono, ce.duration_wait espera_seg, ce.status estado, ce.uniqueid, q.queue cola, camp.name campania FROM {$this->ccCallEntry} ce LEFT JOIN {$this->ccQueue} q ON q.id=ce.id_queue_call_entry LEFT JOIN {$this->ccCampaignEntry} camp ON camp.id=ce.id_campaign WHERE ce.datetime_entry_queue >= :from AND ce.datetime_entry_queue < :to {$agentSql} AND (ce.id_agent IS NULL OR ce.status LIKE '%abandon%' OR ce.status LIKE '%ABANDON%' OR ce.status LIKE '%Abandon%') ORDER BY ce.datetime_entry_queue DESC LIMIT " . (int)$limit;
        $rows = DB::fetchAll($sql, $params);
        foreach ($rows as &$r) {
            $r['espera'] = seconds_to_hms($r['espera_seg']);
        }
        return $rows;
    }

    private function getCallbackOutgoingCandidates($from, $to, $agentId = null, $limit = 30000)
    {
        $rows = array();

        // 1) Salientes generadas por campañas del Call Center.
        // Se usa id_agent cuando existe, y como respaldo el campo calls.agent.
        $params = array(':from_cb_out' => $from, ':to_cb_out' => $to);
        $agentWhere = '';
        if ($agentId !== null && $agentId !== '') {
            $params[':agent_cb_out'] = (int)$agentId;
            $agentWhere = " AND (a.id = :agent_cb_out OR a_txt.id = :agent_cb_out) ";
        }
        $fechaCall = "COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue)";
        $sql = "SELECT
                    'Campaña saliente' AS origen_devolucion,
                    'Saliente' AS tipo_devolucion,
                    c.id AS id_origen,
                    {$fechaCall} AS fecha_devolucion,
                    c.phone AS numero_cliente,
                    COALESCE(a.id, a_txt.id) AS id_agent,
                    COALESCE(a.number, a_txt.number, c.agent, '') AS agente_numero,
                    COALESCE(a.name, a_txt.name, '') AS agente_nombre,
                    COALESCE(a.type, a_txt.type, '') AS agente_tipo,
                    COALESCE(
                        NULLIF(c.agent, ''),
                        (
                            SELECT au.login_extension
                            FROM {$this->ccAudit} au
                            WHERE au.id_agent = COALESCE(a.id, a_txt.id)
                              AND au.id_break IS NULL
                              AND au.login_extension IS NOT NULL
                              AND au.login_extension <> ''
                              AND au.datetime_init <= {$fechaCall}
                              AND COALESCE(au.datetime_end, NOW()) >= {$fechaCall}
                            ORDER BY au.datetime_init DESC
                            LIMIT 1
                        ),
                        COALESCE(a.number, a_txt.number, '')
                    ) AS extension_devolvio,
                    c.status AS estado_devolucion,
                    c.uniqueid AS uniqueid_devolucion,
                    c.uniqueid AS linkedid_devolucion,
                    c.duration AS hablado_seg,
                    c.trunk AS troncal,
                    '' AS grabacion
                FROM {$this->ccCalls} c
                LEFT JOIN {$this->ccAgent} a ON a.id = c.id_agent
                LEFT JOIN {$this->ccAgent} a_txt ON a_txt.number = c.agent
                WHERE {$fechaCall} >= :from_cb_out
                  AND {$fechaCall} < :to_cb_out
                  AND c.phone IS NOT NULL
                  AND c.phone <> ''
                  {$agentWhere}
                ORDER BY fecha_devolucion ASC
                LIMIT " . (int)$limit;
        $rows = array_merge($rows, DB::fetchAll($sql, $params));

        // 2) Salientes manuales tomadas directamente desde CDR.
        // Aquí el agente se detecta por la extensión que originó la llamada:
        // cdr.src y/o canal PJSIP/SIP/IAX2, cruzado con audit.login_extension.
        $params = array(':from_cb_cdr' => $from, ':to_cb_cdr' => $to);
        $agentWhere = '';
        if ($agentId !== null && $agentId !== '') {
            $params[':agent_cb_cdr'] = (int)$agentId;
            $agentWhere = " AND COALESCE(a_session.id, a_direct.id) = :agent_cb_cdr ";
        }
        $sql = "SELECT
                    'Manual desde extensión' AS origen_devolucion,
                    'Saliente' AS tipo_devolucion,
                    cd.sequence AS id_origen,
                    cd.calldate AS fecha_devolucion,
                    cd.dst AS numero_cliente,
                    COALESCE(a_session.id, a_direct.id) AS id_agent,
                    COALESCE(a_session.number, a_direct.number, cd.src) AS agente_numero,
                    COALESCE(a_session.name, a_direct.name, 'Extensión sin agente asociado') AS agente_nombre,
                    COALESCE(a_session.type, a_direct.type, '') AS agente_tipo,
                    cd.src AS extension_devolvio,
                    cd.disposition AS estado_devolucion,
                    cd.uniqueid AS uniqueid_devolucion,
                    cd.linkedid AS linkedid_devolucion,
                    cd.billsec AS hablado_seg,
                    '' AS troncal,
                    cd.recordingfile AS grabacion
                FROM {$this->cdr} cd
                LEFT JOIN {$this->ccAudit} au
                    ON au.id_break IS NULL
                   AND au.login_extension IS NOT NULL
                   AND au.login_extension <> ''
                   AND au.login_extension = cd.src
                   AND au.datetime_init <= cd.calldate
                   AND COALESCE(au.datetime_end, NOW()) >= cd.calldate
                LEFT JOIN {$this->ccAgent} a_session ON a_session.id = au.id_agent
                LEFT JOIN {$this->ccAgent} a_direct
                    ON (
                        a_direct.number = cd.src
                        OR cd.channel LIKE CONCAT('PJSIP/', a_direct.number, '-%')
                        OR cd.channel LIKE CONCAT('SIP/', a_direct.number, '-%')
                        OR cd.channel LIKE CONCAT('IAX2/', a_direct.number, '-%')
                    )
                WHERE cd.calldate >= :from_cb_cdr
                  AND cd.calldate < :to_cb_cdr
                  AND cd.dst IS NOT NULL
                  AND cd.dst <> ''
                  AND cd.dst NOT IN (SELECT number FROM {$this->ccAgent})
                  AND NOT EXISTS (
                        SELECT 1
                        FROM {$this->ccCalls} c
                        WHERE c.uniqueid IS NOT NULL
                          AND c.uniqueid <> ''
                          AND (c.uniqueid = cd.uniqueid OR c.uniqueid = cd.linkedid)
                  )
                  AND NOT EXISTS (
                        SELECT 1
                        FROM {$this->ccCallEntry} ce
                        WHERE ce.uniqueid IS NOT NULL
                          AND ce.uniqueid <> ''
                          AND (ce.uniqueid = cd.uniqueid OR ce.uniqueid = cd.linkedid)
                  )
                  {$agentWhere}
                ORDER BY cd.calldate ASC
                LIMIT " . (int)$limit;
        $rows = array_merge($rows, DB::fetchAll($sql, $params));

        usort($rows, function($a, $b) {
            return strcmp($a['fecha_devolucion'], $b['fecha_devolucion']);
        });

        // Evitar duplicados por joins de sesiones superpuestas.
        $seen = array();
        $unique = array();
        foreach ($rows as $r) {
            $key = $r['origen_devolucion'] . '|' . $r['uniqueid_devolucion'] . '|' . $r['linkedid_devolucion'] . '|' . $r['fecha_devolucion'] . '|' . $r['numero_cliente'] . '|' . $r['extension_devolvio'];
            if (isset($seen[$key])) continue;
            $seen[$key] = true;
            $unique[] = $r;
        }
        return $unique;
    }

    public function getCallbacks($from, $to, $agentId = null, $limit = 5000)
    {
        // El abandono siempre se toma del período solicitado.
        // La devolución se busca desde el momento del abandono hasta N días después del fin del rango.
        $abandoned = $this->getAbandoned($from, $to, null, $limit);
        $searchEnd = new DateTime($to);
        $searchEnd->modify('+' . (int)app_config('reports.callback_search_days', 30) . ' days');

        $outgoingOnly = $this->getCallbackOutgoingCandidates($from, $searchEnd->format('Y-m-d H:i:s'), $agentId, (int)app_config('app.max_export_rows', 30000));

        $rows = array();
        foreach ($abandoned as $ab) {
            $found = null;
            foreach ($outgoingOnly as $o) {
                if (empty($o['fecha_devolucion']) || strtotime($o['fecha_devolucion']) <= strtotime($ab['fecha_abandono'])) continue;
                if (phone_matches($ab['numero_cliente'], $o['numero_cliente'])) {
                    $found = $o;
                    break;
                }
            }

            // Si se filtra por agente, el reporte debe representar devoluciones hechas por ese agente.
            // Por eso no se incluyen pendientes sin agente cuando existe filtro de agente.
            if ($agentId !== null && !$found) {
                continue;
            }

            $agenteNumero = $found ? (string)$found['agente_numero'] : '';
            $agenteNombre = $found ? (string)$found['agente_nombre'] : '';
            $extension = $found ? (string)$found['extension_devolvio'] : '';
            $agenteTexto = '';
            if ($found) {
                $agenteTexto = trim($agenteNumero . ($agenteNombre !== '' ? ' - ' . $agenteNombre : ''));
                if ($agenteTexto === '') $agenteTexto = $extension;
            }

            $row = array(
                'numero_cliente' => normalize_phone($ab['numero_cliente']),
                'numero_cliente_original' => $ab['numero_cliente'],
                'fecha_abandono' => $ab['fecha_abandono'],
                'espera' => $ab['espera'],
                'estado_abandono' => $ab['estado'],
                'cola' => $ab['cola'],
                'campania' => $ab['campania'],
                'devuelta' => $found ? 'Sí' : 'No',
                'fecha_devolucion' => $found ? $found['fecha_devolucion'] : '',
                'extension_devolvio' => $extension,
                'agente_devolvio_numero' => $agenteNumero,
                'agente_devolvio_nombre' => $agenteNombre,
                'agente_devolvio' => $agenteTexto,
                'id_agent_devolvio' => ($found && isset($found['id_agent'])) ? (int)$found['id_agent'] : '',
                'tipo_devolucion' => $found ? 'Saliente' : '',
                'origen_devolucion' => $found ? $found['origen_devolucion'] : '',
                'estado_devolucion' => $found ? $found['estado_devolucion'] : '',
                'tiempo_hasta_devolucion' => $found ? seconds_to_hms(strtotime($found['fecha_devolucion']) - strtotime($ab['fecha_abandono'])) : '',
                'uniqueid_abandono' => $ab['uniqueid'],
                'uniqueid_devolucion' => $found ? $found['uniqueid_devolucion'] : '',
                'linkedid_devolucion' => $found ? $found['linkedid_devolucion'] : '',
            );
            $rows[] = $row;
        }
        return $rows;
    }


    public function getManualDirectCalls($from, $to, $agentId = null, $limit = 30000)
    {
        $rows = array();

        // Salientes manuales desde la extensión del agente.
        $params = array(':from_manual_out' => $from, ':to_manual_out' => $to);
        $agentWhere = '';
        if ($agentId !== null && $agentId !== '') {
            $params[':agent_manual_out'] = (int)$agentId;
            $agentWhere = " AND COALESCE(a_session.id, a_direct.id) = :agent_manual_out ";
        }
        $sql = "SELECT
                    'Saliente' AS tipo,
                    'Saliente manual' AS clasificacion,
                    cd.sequence AS id_origen,
                    cd.calldate AS fecha,
                    cd.src AS extension_relacionada,
                    cd.dst AS numero,
                    cd.src AS origen,
                    cd.dst AS destino,
                    COALESCE(a_session.id, a_direct.id) AS id_agent,
                    COALESCE(a_session.number, a_direct.number, cd.src) AS agente,
                    COALESCE(a_session.name, a_direct.name, 'Extensión sin agente asociado') AS nombre,
                    COALESCE(a_session.type, a_direct.type, '') AS tipo_agente,
                    cd.channel,
                    cd.dstchannel,
                    cd.dcontext,
                    cd.did,
                    cd.lastapp,
                    cd.lastdata,
                    cd.disposition AS estado,
                    cd.duration AS duracion_total_seg,
                    cd.billsec AS tiempo_hablado_seg,
                    cd.uniqueid,
                    cd.linkedid,
                    cd.recordingfile AS grabacion,
                    '' AS agente_origen_numero,
                    '' AS agente_origen_nombre
                FROM {$this->cdr} cd
                LEFT JOIN {$this->ccAudit} au
                    ON au.id_break IS NULL
                   AND au.login_extension IS NOT NULL
                   AND au.login_extension <> ''
                   AND au.login_extension = cd.src
                   AND au.datetime_init <= cd.calldate
                   AND COALESCE(au.datetime_end, NOW()) >= cd.calldate
                LEFT JOIN {$this->ccAgent} a_session ON a_session.id = au.id_agent
                LEFT JOIN {$this->ccAgent} a_direct
                    ON (
                        a_direct.number = cd.src
                        OR cd.channel LIKE CONCAT('PJSIP/', a_direct.number, '-%')
                        OR cd.channel LIKE CONCAT('SIP/', a_direct.number, '-%')
                        OR cd.channel LIKE CONCAT('IAX2/', a_direct.number, '-%')
                    )
                WHERE cd.calldate >= :from_manual_out
                  AND cd.calldate < :to_manual_out
                  AND cd.dst IS NOT NULL
                  AND cd.dst <> ''
                  AND cd.dst NOT IN (SELECT number FROM {$this->ccAgent})
                  AND NOT EXISTS (
                        SELECT 1
                        FROM {$this->ccCalls} c
                        WHERE c.uniqueid IS NOT NULL
                          AND c.uniqueid <> ''
                          AND (c.uniqueid = cd.uniqueid OR c.uniqueid = cd.linkedid)
                  )
                  AND NOT EXISTS (
                        SELECT 1
                        FROM {$this->ccCallEntry} ce
                        WHERE ce.uniqueid IS NOT NULL
                          AND ce.uniqueid <> ''
                          AND (ce.uniqueid = cd.uniqueid OR ce.uniqueid = cd.linkedid)
                  )
                  {$agentWhere}
                ORDER BY cd.calldate DESC
                LIMIT " . (int)$limit;
        $rows = array_merge($rows, DB::fetchAll($sql, $params));

        // Entrantes directas recibidas en la extensión del agente.
        $params = array(':from_manual_in' => $from, ':to_manual_in' => $to);
        $agentWhere = '';
        if ($agentId !== null && $agentId !== '') {
            $params[':agent_manual_in'] = (int)$agentId;
            $agentWhere = " AND a_dest.id = :agent_manual_in ";
        }
        $sql = "SELECT
                    'Entrante' AS tipo,
                    'Entrante directa' AS clasificacion,
                    cd.sequence AS id_origen,
                    cd.calldate AS fecha,
                    a_dest.number AS extension_relacionada,
                    cd.src AS numero,
                    cd.src AS origen,
                    cd.dst AS destino,
                    a_dest.id AS id_agent,
                    a_dest.number AS agente,
                    a_dest.name AS nombre,
                    a_dest.type AS tipo_agente,
                    cd.channel,
                    cd.dstchannel,
                    cd.dcontext,
                    cd.did,
                    cd.lastapp,
                    cd.lastdata,
                    cd.disposition AS estado,
                    cd.duration AS duracion_total_seg,
                    cd.billsec AS tiempo_hablado_seg,
                    cd.uniqueid,
                    cd.linkedid,
                    cd.recordingfile AS grabacion,
                    COALESCE(a_src.number, '') AS agente_origen_numero,
                    COALESCE(a_src.name, '') AS agente_origen_nombre
                FROM {$this->cdr} cd
                INNER JOIN {$this->ccAgent} a_dest
                    ON (
                        cd.dst = a_dest.number
                        OR cd.dstchannel LIKE CONCAT('PJSIP/', a_dest.number, '-%')
                        OR cd.dstchannel LIKE CONCAT('SIP/', a_dest.number, '-%')
                        OR cd.dstchannel LIKE CONCAT('IAX2/', a_dest.number, '-%')
                    )
                LEFT JOIN {$this->ccAgent} a_src
                    ON (
                        a_src.number = cd.src
                        OR cd.channel LIKE CONCAT('PJSIP/', a_src.number, '-%')
                        OR cd.channel LIKE CONCAT('SIP/', a_src.number, '-%')
                        OR cd.channel LIKE CONCAT('IAX2/', a_src.number, '-%')
                    )
                WHERE cd.calldate >= :from_manual_in
                  AND cd.calldate < :to_manual_in
                  AND NOT EXISTS (
                        SELECT 1
                        FROM {$this->ccCallEntry} ce
                        WHERE ce.uniqueid IS NOT NULL
                          AND ce.uniqueid <> ''
                          AND (ce.uniqueid = cd.uniqueid OR ce.uniqueid = cd.linkedid)
                  )
                  {$agentWhere}
                ORDER BY cd.calldate DESC
                LIMIT " . (int)$limit;
        $rows = array_merge($rows, DB::fetchAll($sql, $params));

        // Buscar abandonadas previas para marcar salientes manuales que son devolución.
        $searchStart = new DateTime($from);
        $searchStart->modify('-' . (int)app_config('reports.callback_search_days', 30) . ' days');
        $abandoned = $this->getAbandoned($searchStart->format('Y-m-d H:i:s'), $to, null, (int)app_config('app.max_export_rows', 30000));

        foreach ($rows as &$r) {
            $r['devuelta'] = 'No';
            $r['fecha_abandono'] = '';
            $r['espera_abandono'] = '';
            $r['cola_abandono'] = '';
            $r['campania_abandono'] = '';

            if ($r['tipo'] === 'Saliente') {
                $best = null;
                foreach ($abandoned as $ab) {
                    if (empty($ab['fecha_abandono']) || strtotime($ab['fecha_abandono']) >= strtotime($r['fecha'])) continue;
                    if (phone_matches($ab['numero_cliente'], $r['numero'])) {
                        if ($best === null || strtotime($ab['fecha_abandono']) > strtotime($best['fecha_abandono'])) {
                            $best = $ab;
                        }
                    }
                }
                if ($best) {
                    $r['clasificacion'] = 'Devolución de llamada perdida';
                    $r['devuelta'] = 'Sí';
                    $r['fecha_abandono'] = $best['fecha_abandono'];
                    $r['espera_abandono'] = $best['espera'];
                    $r['cola_abandono'] = $best['cola'];
                    $r['campania_abandono'] = $best['campania'];
                } else {
                    $r['clasificacion'] = 'Saliente manual';
                }
            } else {
                $srcDigits = preg_replace('/\D+/', '', (string)$r['origen']);
                $maxExt = (int)app_config('reports.extension_match_max_digits', 6);
                $hasTrunkEvidence = false;
                if (trim((string)$r['did']) !== '') $hasTrunkEvidence = true;
                if (stripos((string)$r['dcontext'], 'trunk') !== false || stripos((string)$r['dcontext'], 'from-pstn') !== false || stripos((string)$r['dcontext'], 'from-did') !== false) $hasTrunkEvidence = true;
                if (trim((string)$r['agente_origen_numero']) !== '' || ($srcDigits !== '' && strlen($srcDigits) <= $maxExt && !$hasTrunkEvidence)) {
                    $r['clasificacion'] = 'Interna directa';
                } else {
                    $r['clasificacion'] = 'Entrante por troncal directa';
                }
            }

            $r['numero_normalizado'] = normalize_phone($r['numero']);
            $r['duracion_total'] = seconds_to_hms(isset($r['duracion_total_seg']) ? $r['duracion_total_seg'] : 0);
            $r['tiempo_hablado'] = seconds_to_hms(isset($r['tiempo_hablado_seg']) ? $r['tiempo_hablado_seg'] : 0);
        }
        unset($r);

        // Evitar duplicados por sesiones superpuestas y ordenar por fecha descendente.
        $seen = array();
        $unique = array();
        foreach ($rows as $r) {
            $key = $r['tipo'] . '|' . $r['uniqueid'] . '|' . $r['linkedid'] . '|' . $r['fecha'] . '|' . $r['extension_relacionada'] . '|' . $r['numero'];
            if (isset($seen[$key])) continue;
            $seen[$key] = true;
            $unique[] = $r;
        }
        usort($unique, function($a, $b) {
            return strcmp($b['fecha'], $a['fecha']);
        });
        if (count($unique) > $limit) $unique = array_slice($unique, 0, $limit);
        return $unique;
    }

    public function getForms($from, $to, $agentId = null, $limit = 5000)
    {
        $rows = array();
        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->agentFilter('c', $agentId, $params);
        $sql = "SELECT 'saliente_campania' tipo_llamada, c.id id_llamada, c.phone numero_cliente, COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue) fecha, a.number agente, a.name nombre, ff.etiqueta campo, f.value valor FROM {$this->ccFormDataOut} f INNER JOIN {$this->ccCalls} c ON c.id=f.id_calls INNER JOIN {$this->ccFormField} ff ON ff.id=f.id_form_field LEFT JOIN {$this->ccAgent} a ON a.id=c.id_agent WHERE COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue) >= :from AND COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue) < :to {$agentSql} ORDER BY fecha DESC, c.id, ff.orden LIMIT " . (int)$limit;
        $rows = array_merge($rows, DB::fetchAll($sql, $params));
        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->agentFilter('ce', $agentId, $params);
        $sql = "SELECT 'entrante_callcenter' tipo_llamada, ce.id id_llamada, ce.callerid numero_cliente, COALESCE(ce.datetime_init, ce.datetime_entry_queue) fecha, a.number agente, a.name nombre, ff.etiqueta campo, f.value valor FROM {$this->ccFormDataIn} f INNER JOIN {$this->ccCallEntry} ce ON ce.id=f.id_call_entry INNER JOIN {$this->ccFormField} ff ON ff.id=f.id_form_field LEFT JOIN {$this->ccAgent} a ON a.id=ce.id_agent WHERE COALESCE(ce.datetime_init, ce.datetime_entry_queue) >= :from AND COALESCE(ce.datetime_init, ce.datetime_entry_queue) < :to {$agentSql} ORDER BY fecha DESC, ce.id, ff.orden LIMIT " . (int)$limit;
        $rows = array_merge($rows, DB::fetchAll($sql, $params));
        usort($rows, function($a, $b) { return strcmp($b['fecha'], $a['fecha']); });
        return $rows;
    }

    public function getTransfers($from, $to, $agentId = null)
    {
        $calls = $this->getUnifiedCalls($from, $to, $agentId, '', 10000);
        $rows = array();
        foreach ($calls as $c) {
            if (!empty($c['transferencia'])) {
                $rows[] = array(
                    'fecha_inicio' => $c['fecha_inicio'],
                    'tipo_llamada' => $c['tipo_llamada'],
                    'numero_cliente' => $c['numero_cliente'],
                    'agente' => $c['agente'],
                    'nombre' => $c['nombre'],
                    'transferencia' => $c['transferencia'],
                    'estado' => $c['estado'],
                    'uniqueid' => $c['uniqueid'],
                    'linkedid' => $c['linkedid'],
                );
            }
        }
        return $rows;
    }

    public function getTrace($uniqueid, $linkedid = '')
    {
        $params = array(':uniqueid' => $uniqueid);
        $where = 'cd.uniqueid = :uniqueid';
        if ($linkedid !== '') {
            $where = '(cd.uniqueid = :uniqueid OR cd.linkedid = :linkedid)';
            $params[':linkedid'] = $linkedid;
        }
        $cdr = DB::fetchAll("SELECT calldate, src, dst, channel, dstchannel, lastapp, lastdata, duration, billsec, disposition, uniqueid, linkedid, recordingfile, sequence FROM {$this->cdr} cd WHERE {$where} ORDER BY linkedid, sequence, calldate", $params);
        $params = array(':uniqueid' => $uniqueid);
        $where = 'ce.uniqueid = :uniqueid';
        if ($linkedid !== '') {
            $where = '(ce.uniqueid = :uniqueid OR ce.linkedid = :linkedid)';
            $params[':linkedid'] = $linkedid;
        }
        $cel = DB::fetchAll("SELECT eventtime, eventtype, cid_num, exten, context, channame, appname, appdata, uniqueid, linkedid, peer, eventextra, userfield FROM {$this->cel} ce WHERE {$where} ORDER BY eventtime, id", $params);
        return array('cdr' => $cdr, 'cel' => $cel);
    }


    private function buildDayMap($from, $to)
    {
        $map = array();
        $start = new DateTime(substr($from, 0, 10) . ' 00:00:00');
        $end = new DateTime(substr($to, 0, 10) . ' 00:00:00');
        if ($end->format('Y-m-d H:i:s') < $to) $end->modify('+1 day');
        while ($start < $end) {
            $d = $start->format('Y-m-d');
            $map[$d] = array(
                'fecha' => $d,
                'recibidas' => 0,
                'realizadas' => 0,
                'campania_saliente' => 0,
                'manuales_salientes' => 0,
                'manuales_entrantes' => 0,
                'abandonadas' => 0,
                'devueltas' => 0,
                'transferidas' => 0,
                'tiempo_hablado_seg' => 0,
                'tiempo_pausa_seg' => 0,
                'tiempo_sesion_seg' => 0,
            );
            $start->modify('+1 day');
        }
        return $map;
    }

    private function addSecondsByDay(&$map, $eventStart, $eventEnd, $from, $to, $field)
    {
        if ($eventStart === null || $eventStart === '') return;
        $s = max(strtotime($eventStart), strtotime($from));
        $e = min(strtotime($eventEnd ? $eventEnd : date('Y-m-d H:i:s')), strtotime($to));
        if ($e <= $s) return;
        $cursor = $s;
        while ($cursor < $e) {
            $day = date('Y-m-d', $cursor);
            $dayEnd = strtotime($day . ' 23:59:59') + 1;
            $chunkEnd = min($e, $dayEnd);
            if (isset($map[$day])) $map[$day][$field] += max(0, $chunkEnd - $cursor);
            $cursor = $chunkEnd;
        }
    }

    public function getDailyTrend($from, $to, $agentId = null)
    {
        $map = $this->buildDayMap($from, $to);

        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->agentFilter('ce', $agentId, $params);
        $rows = DB::fetchAll("SELECT DATE(COALESCE(ce.datetime_init, ce.datetime_entry_queue)) fecha, COUNT(*) total, SUM(IFNULL(ce.duration,0)) talk, SUM(CASE WHEN ce.transfer IS NOT NULL AND ce.transfer<>'' THEN 1 ELSE 0 END) transf FROM {$this->ccCallEntry} ce WHERE COALESCE(ce.datetime_init, ce.datetime_entry_queue) >= :from AND COALESCE(ce.datetime_init, ce.datetime_entry_queue) < :to {$agentSql} GROUP BY DATE(COALESCE(ce.datetime_init, ce.datetime_entry_queue))", $params);
        foreach ($rows as $r) if (isset($map[$r['fecha']])) { $map[$r['fecha']]['recibidas'] += (int)$r['total']; $map[$r['fecha']]['tiempo_hablado_seg'] += (int)$r['talk']; $map[$r['fecha']]['transferidas'] += (int)$r['transf']; }

        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->agentFilter('c', $agentId, $params);
        $rows = DB::fetchAll("SELECT DATE(COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue)) fecha, COUNT(*) total, SUM(IFNULL(c.duration,0)) talk, SUM(CASE WHEN c.transfer IS NOT NULL AND c.transfer<>'' THEN 1 ELSE 0 END) transf FROM {$this->ccCalls} c WHERE COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue) >= :from AND COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue) < :to {$agentSql} GROUP BY DATE(COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue))", $params);
        foreach ($rows as $r) if (isset($map[$r['fecha']])) { $map[$r['fecha']]['realizadas'] += (int)$r['total']; $map[$r['fecha']]['campania_saliente'] += (int)$r['total']; $map[$r['fecha']]['tiempo_hablado_seg'] += (int)$r['talk']; $map[$r['fecha']]['transferidas'] += (int)$r['transf']; }

        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->cdrAgentFilter($agentId, $params);
        $rows = DB::fetchAll("SELECT DATE(cd.calldate) fecha, COUNT(DISTINCT COALESCE(NULLIF(cd.linkedid,''), cd.uniqueid)) total, SUM(cd.billsec) talk FROM {$this->cdr} cd INNER JOIN {$this->ccAgent} a ON (a.number = cd.src OR cd.channel LIKE CONCAT('PJSIP/', a.number, '-%') OR cd.channel LIKE CONCAT('SIP/', a.number, '-%') OR cd.channel LIKE CONCAT('IAX2/', a.number, '-%')) WHERE cd.calldate >= :from AND cd.calldate < :to {$agentSql} AND cd.dst NOT IN (SELECT number FROM {$this->ccAgent}) AND NOT EXISTS (SELECT 1 FROM {$this->ccCalls} c WHERE c.uniqueid IS NOT NULL AND c.uniqueid <> '' AND (c.uniqueid = cd.uniqueid OR c.uniqueid = cd.linkedid)) AND NOT EXISTS (SELECT 1 FROM {$this->ccCallEntry} ce WHERE ce.uniqueid IS NOT NULL AND ce.uniqueid <> '' AND (ce.uniqueid = cd.uniqueid OR ce.uniqueid = cd.linkedid)) GROUP BY DATE(cd.calldate)", $params);
        foreach ($rows as $r) if (isset($map[$r['fecha']])) { $map[$r['fecha']]['realizadas'] += (int)$r['total']; $map[$r['fecha']]['manuales_salientes'] += (int)$r['total']; $map[$r['fecha']]['tiempo_hablado_seg'] += (int)$r['talk']; }

        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->cdrAgentFilter($agentId, $params);
        $rows = DB::fetchAll("SELECT DATE(cd.calldate) fecha, COUNT(DISTINCT COALESCE(NULLIF(cd.linkedid,''), cd.uniqueid)) total, SUM(cd.billsec) talk FROM {$this->cdr} cd INNER JOIN {$this->ccAgent} a ON (cd.dst = a.number OR cd.dstchannel LIKE CONCAT('PJSIP/', a.number, '-%') OR cd.dstchannel LIKE CONCAT('SIP/', a.number, '-%') OR cd.dstchannel LIKE CONCAT('IAX2/', a.number, '-%')) WHERE cd.calldate >= :from AND cd.calldate < :to {$agentSql} AND cd.src NOT IN (SELECT number FROM {$this->ccAgent}) AND NOT EXISTS (SELECT 1 FROM {$this->ccCallEntry} ce WHERE ce.uniqueid IS NOT NULL AND ce.uniqueid <> '' AND (ce.uniqueid = cd.uniqueid OR ce.uniqueid = cd.linkedid)) GROUP BY DATE(cd.calldate)", $params);
        foreach ($rows as $r) if (isset($map[$r['fecha']])) { $map[$r['fecha']]['recibidas'] += (int)$r['total']; $map[$r['fecha']]['manuales_entrantes'] += (int)$r['total']; $map[$r['fecha']]['tiempo_hablado_seg'] += (int)$r['talk']; }

        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->agentFilter('ce', $agentId, $params);
        $rows = DB::fetchAll("SELECT DATE(ce.datetime_entry_queue) fecha, COUNT(*) total FROM {$this->ccCallEntry} ce WHERE ce.datetime_entry_queue >= :from AND ce.datetime_entry_queue < :to {$agentSql} AND (ce.id_agent IS NULL OR ce.status LIKE '%abandon%' OR ce.status LIKE '%ABANDON%' OR ce.status LIKE '%Abandon%') GROUP BY DATE(ce.datetime_entry_queue)", $params);
        foreach ($rows as $r) if (isset($map[$r['fecha']])) $map[$r['fecha']]['abandonadas'] += (int)$r['total'];

        // Devoluciones detectadas de llamadas abandonadas del período.
        // Se cuentan por la fecha del abandono para medir recuperación de pérdidas del día.
        $callbacks = $this->getCallbacks($from, $to, $agentId, (int)app_config('app.max_export_rows', 30000));
        foreach ($callbacks as $cb) {
            if (!isset($cb['devuelta']) || $cb['devuelta'] !== 'Sí') continue;
            $d = substr((string)$cb['fecha_abandono'], 0, 10);
            if (isset($map[$d])) $map[$d]['devueltas']++;
        }

        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->agentFilter('au', $agentId, $params);
        $rows = DB::fetchAll("SELECT au.datetime_init, COALESCE(au.datetime_end, NOW()) datetime_end FROM {$this->ccAudit} au WHERE au.id_break IS NOT NULL AND au.datetime_init < :to AND COALESCE(au.datetime_end, NOW()) > :from {$agentSql}", $params);
        foreach ($rows as $r) $this->addSecondsByDay($map, $r['datetime_init'], $r['datetime_end'], $from, $to, 'tiempo_pausa_seg');

        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->agentFilter('au', $agentId, $params);
        $rows = DB::fetchAll("SELECT au.datetime_init, COALESCE(au.datetime_end, NOW()) datetime_end FROM {$this->ccAudit} au WHERE au.id_break IS NULL AND au.datetime_init < :to AND COALESCE(au.datetime_end, NOW()) > :from {$agentSql}", $params);
        foreach ($rows as $r) $this->addSecondsByDay($map, $r['datetime_init'], $r['datetime_end'], $from, $to, 'tiempo_sesion_seg');

        $out = array_values($map);
        foreach ($out as &$r) {
            $r['tiempo_hablado'] = seconds_to_hms($r['tiempo_hablado_seg']);
            $r['tiempo_pausa'] = seconds_to_hms($r['tiempo_pausa_seg']);
            $r['tiempo_sesion'] = seconds_to_hms($r['tiempo_sesion_seg']);
        }
        return $out;
    }

    public function getHourlyCallVolume($from, $to, $agentId = null)
    {
        $hours = array();
        $start = new DateTime($from);
        $end = new DateTime($to);
        $start->setTime((int)$start->format('H'), 0, 0);
        while ($start < $end) {
            $h = $start->format('Y-m-d H:00:00');
            $hours[$h] = array('hora' => $h, 'recibidas' => 0, 'realizadas' => 0, 'abandonadas' => 0, 'devueltas' => 0);
            $start->modify('+1 hour');
        }
        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->agentFilter('ce', $agentId, $params);
        $rows = DB::fetchAll("SELECT DATE_FORMAT(COALESCE(ce.datetime_init, ce.datetime_entry_queue),'%Y-%m-%d %H:00:00') hora, COUNT(*) total FROM {$this->ccCallEntry} ce WHERE COALESCE(ce.datetime_init, ce.datetime_entry_queue) >= :from AND COALESCE(ce.datetime_init, ce.datetime_entry_queue) < :to {$agentSql} GROUP BY DATE_FORMAT(COALESCE(ce.datetime_init, ce.datetime_entry_queue),'%Y-%m-%d %H')", $params);
        foreach ($rows as $r) if (isset($hours[$r['hora']])) $hours[$r['hora']]['recibidas'] += (int)$r['total'];
        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->agentFilter('c', $agentId, $params);
        $rows = DB::fetchAll("SELECT DATE_FORMAT(COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue),'%Y-%m-%d %H:00:00') hora, COUNT(*) total FROM {$this->ccCalls} c WHERE COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue) >= :from AND COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue) < :to {$agentSql} GROUP BY DATE_FORMAT(COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue),'%Y-%m-%d %H')", $params);
        foreach ($rows as $r) if (isset($hours[$r['hora']])) $hours[$r['hora']]['realizadas'] += (int)$r['total'];
        // Manuales salientes desde CDR. Se agregan al volumen realizado para que el tablero no quede vacío
        // cuando el agente llama directamente desde su extensión.
        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->cdrAgentFilter($agentId, $params);
        $rows = DB::fetchAll("SELECT DATE_FORMAT(cd.calldate,'%Y-%m-%d %H:00:00') hora, COUNT(DISTINCT COALESCE(NULLIF(cd.linkedid,''), cd.uniqueid)) total FROM {$this->cdr} cd INNER JOIN {$this->ccAgent} a ON (a.number = cd.src OR cd.channel LIKE CONCAT('PJSIP/', a.number, '-%') OR cd.channel LIKE CONCAT('SIP/', a.number, '-%') OR cd.channel LIKE CONCAT('IAX2/', a.number, '-%')) WHERE cd.calldate >= :from AND cd.calldate < :to {$agentSql} AND cd.dst NOT IN (SELECT number FROM {$this->ccAgent}) AND NOT EXISTS (SELECT 1 FROM {$this->ccCalls} c WHERE c.uniqueid IS NOT NULL AND c.uniqueid <> '' AND (c.uniqueid = cd.uniqueid OR c.uniqueid = cd.linkedid)) AND NOT EXISTS (SELECT 1 FROM {$this->ccCallEntry} ce WHERE ce.uniqueid IS NOT NULL AND ce.uniqueid <> '' AND (ce.uniqueid = cd.uniqueid OR ce.uniqueid = cd.linkedid)) GROUP BY DATE_FORMAT(cd.calldate,'%Y-%m-%d %H')", $params);
        foreach ($rows as $r) if (isset($hours[$r['hora']])) $hours[$r['hora']]['realizadas'] += (int)$r['total'];

        // Manuales entrantes directas a extensión desde CDR.
        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->cdrAgentFilter($agentId, $params);
        $rows = DB::fetchAll("SELECT DATE_FORMAT(cd.calldate,'%Y-%m-%d %H:00:00') hora, COUNT(DISTINCT COALESCE(NULLIF(cd.linkedid,''), cd.uniqueid)) total FROM {$this->cdr} cd INNER JOIN {$this->ccAgent} a ON (cd.dst = a.number OR cd.dstchannel LIKE CONCAT('PJSIP/', a.number, '-%') OR cd.dstchannel LIKE CONCAT('SIP/', a.number, '-%') OR cd.dstchannel LIKE CONCAT('IAX2/', a.number, '-%')) WHERE cd.calldate >= :from AND cd.calldate < :to {$agentSql} AND cd.src NOT IN (SELECT number FROM {$this->ccAgent}) AND NOT EXISTS (SELECT 1 FROM {$this->ccCallEntry} ce WHERE ce.uniqueid IS NOT NULL AND ce.uniqueid <> '' AND (ce.uniqueid = cd.uniqueid OR ce.uniqueid = cd.linkedid)) GROUP BY DATE_FORMAT(cd.calldate,'%Y-%m-%d %H')", $params);
        foreach ($rows as $r) if (isset($hours[$r['hora']])) $hours[$r['hora']]['recibidas'] += (int)$r['total'];

        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->agentFilter('ce', $agentId, $params);
        $rows = DB::fetchAll("SELECT DATE_FORMAT(ce.datetime_entry_queue,'%Y-%m-%d %H:00:00') hora, COUNT(*) total FROM {$this->ccCallEntry} ce WHERE ce.datetime_entry_queue >= :from AND ce.datetime_entry_queue < :to {$agentSql} AND (ce.id_agent IS NULL OR ce.status LIKE '%abandon%' OR ce.status LIKE '%ABANDON%' OR ce.status LIKE '%Abandon%') GROUP BY DATE_FORMAT(ce.datetime_entry_queue,'%Y-%m-%d %H')", $params);
        foreach ($rows as $r) if (isset($hours[$r['hora']])) $hours[$r['hora']]['abandonadas'] += (int)$r['total'];

        // Devoluciones detectadas de abandonadas, agrupadas por hora del abandono.
        $callbacks = $this->getCallbacks($from, $to, $agentId, (int)app_config('app.max_export_rows', 30000));
        foreach ($callbacks as $cb) {
            if (!isset($cb['devuelta']) || $cb['devuelta'] !== 'Sí') continue;
            $ts = strtotime((string)$cb['fecha_abandono']);
            if (!$ts) continue;
            $h = date('Y-m-d H:00:00', $ts);
            if (isset($hours[$h])) $hours[$h]['devueltas']++;
        }
        return array_values($hours);
    }


    public function getCurrentAgentRuntime()
    {
        $agents = $this->getAgents();
        $map = array();
        foreach ($agents as $a) {
            $map[(int)$a['id']] = array(
                'id_agent' => (int)$a['id'],
                'agente' => $a['number'],
                'nombre' => $a['name'],
                'tipo' => $a['type'],
                'estado_base' => $a['estatus'],
                'logueado' => 'No',
                'en_pausa' => 'No',
                'motivo_pausa' => '',
                'login_extension' => '',
                'inicio_sesion' => '',
                'tiempo_sesion_seg' => 0,
                'tiempo_sesion' => '00:00:00',
                'inicio_pausa' => '',
                'tiempo_pausa_actual_seg' => 0,
                'tiempo_pausa_actual' => '00:00:00',
                'llamada_actual' => '',
                'numero_actual' => '',
                'tipo_llamada_actual' => '',
                'duracion_llamada_actual_seg' => 0,
                'duracion_llamada_actual' => '00:00:00',
                'uniqueid_actual' => '',
                'canal_actual' => '',
                'estado_operativo' => 'Desconectado',
                'estado_css' => 'secondary'
            );
        }

        $sql = "SELECT au.* FROM {$this->ccAudit} au INNER JOIN (SELECT id_agent, MAX(id) id FROM {$this->ccAudit} WHERE id_break IS NULL GROUP BY id_agent) x ON x.id=au.id";
        foreach (DB::fetchAll($sql) as $r) {
            $id = (int)$r['id_agent'];
            if (!isset($map[$id])) continue;
            if (empty($r['datetime_end'])) {
                $map[$id]['logueado'] = 'Sí';
                $map[$id]['inicio_sesion'] = $r['datetime_init'];
                $map[$id]['login_extension'] = $r['login_extension'];
                $sec = time() - strtotime($r['datetime_init']);
                $map[$id]['tiempo_sesion_seg'] = $sec;
                $map[$id]['tiempo_sesion'] = seconds_to_hms($sec);
                $map[$id]['estado_operativo'] = 'Disponible';
                $map[$id]['estado_css'] = 'success';
            }
        }

        $sql = "SELECT au.*, b.name motivo FROM {$this->ccAudit} au LEFT JOIN {$this->ccBreak} b ON b.id=au.id_break INNER JOIN (SELECT id_agent, MAX(id) id FROM {$this->ccAudit} WHERE id_break IS NOT NULL GROUP BY id_agent) x ON x.id=au.id";
        foreach (DB::fetchAll($sql) as $r) {
            $id = (int)$r['id_agent'];
            if (!isset($map[$id])) continue;
            if (empty($r['datetime_end'])) {
                $map[$id]['en_pausa'] = 'Sí';
                $map[$id]['motivo_pausa'] = $r['motivo'];
                $map[$id]['inicio_pausa'] = $r['datetime_init'];
                $sec = time() - strtotime($r['datetime_init']);
                $map[$id]['tiempo_pausa_actual_seg'] = $sec;
                $map[$id]['tiempo_pausa_actual'] = seconds_to_hms($sec);
                $map[$id]['estado_operativo'] = 'En pausa';
                $map[$id]['estado_css'] = 'warning';
            }
        }

        if (DB::tableExists('call_center', 'current_calls')) {
            $sql = "SELECT cc.*, a.id id_agent, a.number agente, a.name nombre FROM {$this->ccCurrentCalls} cc INNER JOIN {$this->ccAgent} a ON a.number=cc.agentnum";
            foreach (DB::fetchAll($sql) as $r) {
                $id = (int)$r['id_agent'];
                if (!isset($map[$id])) continue;
                $sec = time() - strtotime($r['fecha_inicio']);
                $map[$id]['llamada_actual'] = 'Sí';
                $map[$id]['numero_actual'] = isset($r['ChannelClient']) ? $r['ChannelClient'] : '';
                $map[$id]['tipo_llamada_actual'] = 'Saliente campaña';
                $map[$id]['duracion_llamada_actual_seg'] = $sec;
                $map[$id]['duracion_llamada_actual'] = seconds_to_hms($sec);
                $map[$id]['uniqueid_actual'] = $r['uniqueid'];
                $map[$id]['canal_actual'] = $r['Channel'];
                $map[$id]['estado_operativo'] = 'En llamada';
                $map[$id]['estado_css'] = 'primary';
            }
        }

        if (DB::tableExists('call_center', 'current_call_entry')) {
            $sql = "SELECT ce.*, a.id id_agent, a.number agente, a.name nombre FROM {$this->ccCurrentCallEntry} ce INNER JOIN {$this->ccAgent} a ON a.id=ce.id_agent";
            foreach (DB::fetchAll($sql) as $r) {
                $id = (int)$r['id_agent'];
                if (!isset($map[$id])) continue;
                $sec = time() - strtotime($r['datetime_init']);
                $map[$id]['llamada_actual'] = 'Sí';
                $map[$id]['numero_actual'] = $r['callerid'];
                $map[$id]['tipo_llamada_actual'] = 'Entrante cola';
                $map[$id]['duracion_llamada_actual_seg'] = $sec;
                $map[$id]['duracion_llamada_actual'] = seconds_to_hms($sec);
                $map[$id]['uniqueid_actual'] = $r['uniqueid'];
                $map[$id]['canal_actual'] = $r['ChannelClient'];
                $map[$id]['estado_operativo'] = 'En llamada';
                $map[$id]['estado_css'] = 'primary';
            }
        }

        return $map;
    }

    public function getAgentActivityDetail($from, $to, $agentId = null, $limit = 20000)
    {
        $rows = array();
        $calls = $this->getUnifiedCalls($from, $to, $agentId, '', $limit);
        foreach ($calls as $c) {
            $rows[] = array(
                'fecha' => $c['fecha_inicio'],
                'agente' => $c['agente'],
                'nombre' => $c['nombre'],
                'tipo_agente' => $c['tipo_agente'],
                'actividad' => $this->activityLabel($c['tipo_llamada']),
                'detalle' => 'Número: ' . $c['numero_cliente'] . ' | Estado: ' . $c['estado'] . ' | Campaña/cola: ' . trim($c['campania'] . ' ' . $c['cola']),
                'numero_cliente' => $c['numero_cliente'],
                'resultado' => $c['estado'],
                'duracion' => $c['duracion_total'],
                'tiempo_hablado' => $c['tiempo_hablado'],
                'espera' => $c['espera'],
                'transferida' => $c['transferida'],
                'uniqueid' => $c['uniqueid']
            );
        }

        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->agentFilter('au', $agentId, $params);
        $sql = "SELECT au.datetime_init fecha, a.number agente, a.name nombre, a.type tipo_agente, b.name motivo, au.datetime_end, TIMESTAMPDIFF(SECOND, GREATEST(au.datetime_init, :from), LEAST(COALESCE(au.datetime_end, NOW()), :to)) segundos FROM {$this->ccAudit} au INNER JOIN {$this->ccAgent} a ON a.id=au.id_agent LEFT JOIN {$this->ccBreak} b ON b.id=au.id_break WHERE au.id_break IS NOT NULL AND au.datetime_init < :to AND COALESCE(au.datetime_end, NOW()) > :from {$agentSql}";
        foreach (DB::fetchAll($sql, $params) as $p) {
            $rows[] = array(
                'fecha' => $p['fecha'],
                'agente' => $p['agente'],
                'nombre' => $p['nombre'],
                'tipo_agente' => $p['tipo_agente'],
                'actividad' => 'Pausa',
                'detalle' => 'Motivo: ' . $p['motivo'],
                'numero_cliente' => '',
                'resultado' => $p['motivo'],
                'duracion' => seconds_to_hms($p['segundos']),
                'tiempo_hablado' => '00:00:00',
                'espera' => '00:00:00',
                'transferida' => '',
                'uniqueid' => ''
            );
        }

        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->agentFilter('au', $agentId, $params);
        $sql = "SELECT au.datetime_init fecha, a.number agente, a.name nombre, a.type tipo_agente, au.login_extension, au.datetime_end, TIMESTAMPDIFF(SECOND, GREATEST(au.datetime_init, :from), LEAST(COALESCE(au.datetime_end, NOW()), :to)) segundos FROM {$this->ccAudit} au INNER JOIN {$this->ccAgent} a ON a.id=au.id_agent WHERE au.id_break IS NULL AND au.datetime_init < :to AND COALESCE(au.datetime_end, NOW()) > :from {$agentSql}";
        foreach (DB::fetchAll($sql, $params) as $s) {
            $rows[] = array(
                'fecha' => $s['fecha'],
                'agente' => $s['agente'],
                'nombre' => $s['nombre'],
                'tipo_agente' => $s['tipo_agente'],
                'actividad' => 'Sesión',
                'detalle' => 'Login/extensión: ' . $s['login_extension'],
                'numero_cliente' => '',
                'resultado' => empty($s['datetime_end']) ? 'Sesión abierta' : 'Sesión cerrada',
                'duracion' => seconds_to_hms($s['segundos']),
                'tiempo_hablado' => '00:00:00',
                'espera' => '00:00:00',
                'transferida' => '',
                'uniqueid' => ''
            );
        }

        $forms = $this->getForms($from, $to, $agentId, $limit);
        foreach ($forms as $f) {
            $rows[] = array(
                'fecha' => $f['fecha'],
                'agente' => $f['agente'],
                'nombre' => $f['nombre'],
                'tipo_agente' => '',
                'actividad' => 'Formulario',
                'detalle' => $f['campo'] . ': ' . $f['valor'],
                'numero_cliente' => $f['numero_cliente'],
                'resultado' => $f['campo'],
                'duracion' => '',
                'tiempo_hablado' => '',
                'espera' => '',
                'transferida' => '',
                'uniqueid' => ''
            );
        }

        usort($rows, function($a, $b) { return strcmp($b['fecha'], $a['fecha']); });
        if (count($rows) > $limit) $rows = array_slice($rows, 0, $limit);
        return $rows;
    }

    private function activityLabel($type)
    {
        if ($type === 'entrante_callcenter') return 'Llamada entrante';
        if ($type === 'saliente_campania') return 'Llamada saliente campaña';
        if ($type === 'manual_saliente') return 'Llamada manual saliente';
        if ($type === 'manual_entrante') return 'Llamada manual entrante';
        return $type;
    }


    private function getLoginExtensionsMap($from, $to, $agentId = null)
    {
        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->agentFilter('au', $agentId, $params);
        $sql = "SELECT au.id_agent, GROUP_CONCAT(DISTINCT NULLIF(TRIM(au.login_extension),'') ORDER BY au.login_extension SEPARATOR ', ') extensiones, MAX(au.login_extension) ultima_extension FROM {$this->ccAudit} au WHERE au.id_break IS NULL AND au.datetime_init < :to AND COALESCE(au.datetime_end, NOW()) > :from {$agentSql} GROUP BY au.id_agent";
        $map = array();
        foreach (DB::fetchAll($sql, $params) as $r) {
            $map[(int)$r['id_agent']] = array(
                'extensiones' => isset($r['extensiones']) ? $r['extensiones'] : '',
                'ultima_extension' => isset($r['ultima_extension']) ? $r['ultima_extension'] : ''
            );
        }
        return $map;
    }

    public function getAgentTotalReport($from, $to, $agentId = null)
    {
        $agents = $this->getAgents();
        $extMap = $this->getLoginExtensionsMap($from, $to, $agentId);

        // Abandonadas devueltas por agente:
        // se cuenta la llamada abandonada del período cuando fue recuperada por una llamada saliente posterior
        // hecha por el mismo agente/extensión detectada en callbacks.php.
        $returnedAbandonedByAgent = array();
        $returnedAbandonedTotal = 0;
        $callbacksForTotals = $this->getCallbacks($from, $to, null, (int)app_config('app.max_export_rows', 30000));
        foreach ($callbacksForTotals as $cb) {
            if (!isset($cb['devuelta']) || $cb['devuelta'] !== 'Sí') continue;
            $returnedAbandonedTotal++;
            $idDev = isset($cb['id_agent_devolvio']) ? (int)$cb['id_agent_devolvio'] : 0;
            if ($idDev > 0) {
                if (!isset($returnedAbandonedByAgent[$idDev])) $returnedAbandonedByAgent[$idDev] = 0;
                $returnedAbandonedByAgent[$idDev]++;
            }
            $agentDevNumber = isset($cb['agente_devolvio_numero']) ? trim((string)$cb['agente_devolvio_numero']) : '';
            if ($agentDevNumber !== '') {
                if (!isset($returnedAbandonedByAgent[$agentDevNumber])) $returnedAbandonedByAgent[$agentDevNumber] = 0;
                $returnedAbandonedByAgent[$agentDevNumber]++;
            }
        }

        $rows = array();
        $tot = array(
            'incoming_callcenter'=>0,'manual_incoming'=>0,'outgoing_campaign'=>0,'manual_outgoing'=>0,
            'total_recibidas'=>0,'total_realizadas'=>0,'total_llamadas'=>0,'abandoned'=>0,'abandoned_returned'=>0,'transferred'=>0,
            'talk_seconds'=>0,'total_duration_seconds'=>0,'pause_count'=>0,'pause_seconds'=>0,
            'session_count'=>0,'session_seconds'=>0,'forms_count'=>0
        );
        foreach ($agents as $a) {
            if ($agentId !== null && (int)$a['id'] !== (int)$agentId) continue;
            $s = $this->getSummary($from, $to, (int)$a['id'], false);
            $totalRec = $s['incoming'] + $s['manual_incoming'];
            $totalOut = $s['outgoing_campaign'] + $s['manual_outgoing'];
            $totalCalls = $totalRec + $totalOut;
            $occupancy = $s['session_seconds'] > 0 ? round(($s['talk_seconds'] / $s['session_seconds']) * 100, 2) : 0;
            $pauseRate = $s['session_seconds'] > 0 ? round(($s['pause_seconds'] / $s['session_seconds']) * 100, 2) : 0;
            $avgTalk = $totalCalls > 0 ? round($s['talk_seconds'] / $totalCalls) : 0;
            $ext = isset($extMap[(int)$a['id']]) ? $extMap[(int)$a['id']]['extensiones'] : '';
            $abandonedReturned = isset($returnedAbandonedByAgent[(string)$a['number']]) ? (int)$returnedAbandonedByAgent[(string)$a['number']] : 0;
            $rows[] = array(
                'id_agent' => $a['id'],
                'agente' => $a['number'],
                'nombre' => $a['name'],
                'tipo' => $a['type'],
                'extension_login' => $ext,
                'sesiones' => $s['session_count'],
                'tiempo_logueo' => seconds_to_hms($s['session_seconds']),
                'tiempo_logueo_seg' => $s['session_seconds'],
                'pausas' => $s['pause_count'],
                'tiempo_pausa' => seconds_to_hms($s['pause_seconds']),
                'tiempo_pausa_seg' => $s['pause_seconds'],
                'entrantes_callcenter' => $s['incoming'],
                'manuales_entrantes' => $s['manual_incoming'],
                'salientes_campania' => $s['outgoing_campaign'],
                'manuales_salientes' => $s['manual_outgoing'],
                'total_recibidas' => $totalRec,
                'total_realizadas' => $totalOut,
                'total_llamadas' => $totalCalls,
                'abandonadas' => $s['abandoned'],
                'abandonadas_devueltas' => $abandonedReturned,
                'devueltas' => $abandonedReturned,
                'transferidas' => $s['transferred'],
                'formularios' => $s['forms_count'],
                'tiempo_hablado' => seconds_to_hms($s['talk_seconds']),
                'tiempo_hablado_seg' => $s['talk_seconds'],
                'tiempo_total_llamadas' => seconds_to_hms($s['total_duration_seconds']),
                'tiempo_total_llamadas_seg' => $s['total_duration_seconds'],
                'promedio_hablado' => seconds_to_hms($avgTalk),
                'ocupacion_pct' => $occupancy . '%',
                'pausa_pct' => $pauseRate . '%'
            );
            $tot['incoming_callcenter'] += $s['incoming'];
            $tot['manual_incoming'] += $s['manual_incoming'];
            $tot['outgoing_campaign'] += $s['outgoing_campaign'];
            $tot['manual_outgoing'] += $s['manual_outgoing'];
            $tot['total_recibidas'] += $totalRec;
            $tot['total_realizadas'] += $totalOut;
            $tot['total_llamadas'] += $totalCalls;
            $tot['abandoned'] += $s['abandoned'];
            $tot['abandoned_returned'] += $abandonedReturned;
            $tot['transferred'] += $s['transferred'];
            $tot['talk_seconds'] += $s['talk_seconds'];
            $tot['total_duration_seconds'] += $s['total_duration_seconds'];
            $tot['pause_count'] += $s['pause_count'];
            $tot['pause_seconds'] += $s['pause_seconds'];
            $tot['session_count'] += $s['session_count'];
            $tot['session_seconds'] += $s['session_seconds'];
            $tot['forms_count'] += $s['forms_count'];
        }
        if ($agentId === null && count($rows) > 1) {
            $occupancy = $tot['session_seconds'] > 0 ? round(($tot['talk_seconds'] / $tot['session_seconds']) * 100, 2) : 0;
            $pauseRate = $tot['session_seconds'] > 0 ? round(($tot['pause_seconds'] / $tot['session_seconds']) * 100, 2) : 0;
            $avgTalk = $tot['total_llamadas'] > 0 ? round($tot['talk_seconds'] / $tot['total_llamadas']) : 0;
            $rows[] = array(
                'id_agent' => '',
                'agente' => 'TOTAL',
                'nombre' => 'Todos los agentes',
                'tipo' => '',
                'extension_login' => '',
                'sesiones' => $tot['session_count'],
                'tiempo_logueo' => seconds_to_hms($tot['session_seconds']),
                'tiempo_logueo_seg' => $tot['session_seconds'],
                'pausas' => $tot['pause_count'],
                'tiempo_pausa' => seconds_to_hms($tot['pause_seconds']),
                'tiempo_pausa_seg' => $tot['pause_seconds'],
                'entrantes_callcenter' => $tot['incoming_callcenter'],
                'manuales_entrantes' => $tot['manual_incoming'],
                'salientes_campania' => $tot['outgoing_campaign'],
                'manuales_salientes' => $tot['manual_outgoing'],
                'total_recibidas' => $tot['total_recibidas'],
                'total_realizadas' => $tot['total_realizadas'],
                'total_llamadas' => $tot['total_llamadas'],
                'abandonadas' => $tot['abandoned'],
                'abandonadas_devueltas' => $tot['abandoned_returned'],
                'transferidas' => $tot['transferred'],
                'formularios' => $tot['forms_count'],
                'tiempo_hablado' => seconds_to_hms($tot['talk_seconds']),
                'tiempo_hablado_seg' => $tot['talk_seconds'],
                'tiempo_total_llamadas' => seconds_to_hms($tot['total_duration_seconds']),
                'tiempo_total_llamadas_seg' => $tot['total_duration_seconds'],
                'promedio_hablado' => seconds_to_hms($avgTalk),
                'ocupacion_pct' => $occupancy . '%',
                'pausa_pct' => $pauseRate . '%'
            );
        }
        return $rows;
    }

    public function getAgentSessionDetail($from, $to, $agentId = null, $limit = 20000)
    {
        $rows = array();
        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->agentFilter('au', $agentId, $params);
        $sql = "SELECT 'Sesión' tipo_registro, a.number agente, a.name nombre, a.type tipo_agente, au.login_extension extension_login, au.datetime_init inicio, au.datetime_end fin, TIMESTAMPDIFF(SECOND, GREATEST(au.datetime_init, :from), LEAST(COALESCE(au.datetime_end, NOW()), :to)) segundos, '' motivo, CASE WHEN au.datetime_end IS NULL THEN 'Sesión abierta' ELSE 'Sesión cerrada' END estado FROM {$this->ccAudit} au INNER JOIN {$this->ccAgent} a ON a.id=au.id_agent WHERE au.id_break IS NULL AND au.datetime_init < :to AND COALESCE(au.datetime_end, NOW()) > :from {$agentSql} ORDER BY au.datetime_init DESC LIMIT " . (int)$limit;
        foreach (DB::fetchAll($sql, $params) as $r) {
            $r['fin'] = $r['fin'] ? $r['fin'] : 'Actualmente abierta';
            $r['duracion'] = seconds_to_hms($r['segundos']);
            $rows[] = $r;
        }
        $params = array(':from' => $from, ':to' => $to);
        $agentSql = $this->agentFilter('au', $agentId, $params);
        $sql = "SELECT 'Pausa' tipo_registro, a.number agente, a.name nombre, a.type tipo_agente, au.login_extension extension_login, au.datetime_init inicio, au.datetime_end fin, TIMESTAMPDIFF(SECOND, GREATEST(au.datetime_init, :from), LEAST(COALESCE(au.datetime_end, NOW()), :to)) segundos, b.name motivo, CASE WHEN au.datetime_end IS NULL THEN 'Pausa abierta' ELSE 'Pausa cerrada' END estado FROM {$this->ccAudit} au INNER JOIN {$this->ccAgent} a ON a.id=au.id_agent LEFT JOIN {$this->ccBreak} b ON b.id=au.id_break WHERE au.id_break IS NOT NULL AND au.datetime_init < :to AND COALESCE(au.datetime_end, NOW()) > :from {$agentSql} ORDER BY au.datetime_init DESC LIMIT " . (int)$limit;
        foreach (DB::fetchAll($sql, $params) as $r) {
            $r['fin'] = $r['fin'] ? $r['fin'] : 'Actualmente abierta';
            $r['duracion'] = seconds_to_hms($r['segundos']);
            $rows[] = $r;
        }
        usort($rows, function($a, $b) { return strcmp($b['inicio'], $a['inicio']); });
        if (count($rows) > $limit) $rows = array_slice($rows, 0, $limit);
        return $rows;
    }

    public function getStatusCatalog()
    {
        $data = array();
        $data['call_entry_status'] = DB::fetchAll("SELECT status, COUNT(*) total FROM {$this->ccCallEntry} GROUP BY status ORDER BY total DESC");
        $data['calls_status'] = DB::fetchAll("SELECT status, COUNT(*) total FROM {$this->ccCalls} GROUP BY status ORDER BY total DESC");
        $data['progress_status'] = DB::fetchAll("SELECT new_status status, COUNT(*) total FROM {$this->ccProgress} GROUP BY new_status ORDER BY total DESC");
        $data['cdr_disposition'] = DB::fetchAll("SELECT disposition status, COUNT(*) total FROM {$this->cdr} GROUP BY disposition ORDER BY total DESC");
        return $data;
    }
}
