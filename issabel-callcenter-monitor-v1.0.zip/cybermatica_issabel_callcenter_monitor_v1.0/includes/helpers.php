<?php
function e($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function app_config($key = null, $default = null)
{
    global $config;
    if ($key === null) return $config;
    $parts = explode('.', $key);
    $value = $config;
    foreach ($parts as $part) {
        if (!is_array($value) || !array_key_exists($part, $value)) return $default;
        $value = $value[$part];
    }
    return $value;
}

/**
 * Configuración operativa persistida en callcenter_panel.system_settings.
 * Si la tabla todavía no existe, conserva los valores de config.php para
 * compatibilidad con instalaciones anteriores.
 */
function panel_settings_schema_ready()
{
    if (isset($GLOBALS['_panel_settings_schema_ready'])) return (bool)$GLOBALS['_panel_settings_schema_ready'];
    if (!class_exists('DB')) return false;
    try {
        $db = (string)app_config('db.panel', 'callcenter_panel');
        $row = DB::fetch(
            'SELECT 1 FROM information_schema.tables WHERE table_schema = ? AND table_name = ? LIMIT 1',
            array($db, 'system_settings')
        );
        $GLOBALS['_panel_settings_schema_ready'] = (bool)$row;
    } catch (Exception $e) {
        $GLOBALS['_panel_settings_schema_ready'] = false;
    }
    return (bool)$GLOBALS['_panel_settings_schema_ready'];
}

function panel_setting($key, $default = null)
{
    $key = trim((string)$key);
    if ($key === '') return $default;
    if (!isset($GLOBALS['_panel_setting_cache'])) $GLOBALS['_panel_setting_cache'] = array();
    if (array_key_exists($key, $GLOBALS['_panel_setting_cache'])) return $GLOBALS['_panel_setting_cache'][$key];
    if (!panel_settings_schema_ready()) return $default;
    try {
        $value = DB::value('SELECT setting_value FROM ' . DB::q('panel', 'system_settings') . ' WHERE setting_key = ? LIMIT 1', array($key), null);
        if ($value === null) return $default;
        $GLOBALS['_panel_setting_cache'][$key] = $value;
        return $value;
    } catch (Exception $e) {
        return $default;
    }
}

function panel_setting_set($key, $value, $label = '', $description = '', $updatedBy = null)
{
    if (!panel_settings_schema_ready()) throw new RuntimeException('La tabla system_settings no está instalada. Ejecute la migración SQL de SLA.');
    $key = trim((string)$key);
    if ($key === '') throw new InvalidArgumentException('Clave de configuración inválida.');
    DB::execute(
        'INSERT INTO ' . DB::q('panel', 'system_settings') . ' (setting_key, setting_value, label, description, updated_by) VALUES (?,?,?,?,?) '
        . 'ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value), label=VALUES(label), description=VALUES(description), updated_by=VALUES(updated_by), updated_at=CURRENT_TIMESTAMP',
        array($key, (string)$value, substr((string)$label,0,160), substr((string)$description,0,500), $updatedBy ? (int)$updatedBy : null)
    );
    if (!isset($GLOBALS['_panel_setting_cache'])) $GLOBALS['_panel_setting_cache'] = array();
    $GLOBALS['_panel_setting_cache'][$key] = (string)$value;
}

function report_sla_seconds()
{
    $fallback = (int)app_config('reports.sla_seconds', 20);
    $value = (int)panel_setting('sla_seconds', $fallback);
    if ($value < 1 || $value > 600) $value = $fallback > 0 ? $fallback : 20;
    return $value;
}

function report_sla_target_pct()
{
    $fallback = (float)app_config('reports.service_level_target_pct', 80);
    $value = (float)panel_setting('sla_target_pct', $fallback);
    if ($value < 1 || $value > 100) $value = ($fallback >= 1 && $fallback <= 100) ? $fallback : 80;
    return round($value, 2);
}

function report_sla_policy_label()
{
    $target = report_sla_target_pct();
    $targetLabel = rtrim(rtrim(number_format($target, 2, '.', ''), '0'), '.');
    return $targetLabel . '% / ' . report_sla_seconds() . ' seg';
}

function seconds_to_hms($seconds)
{
    $seconds = (int)$seconds;
    if ($seconds < 0) $seconds = 0;
    $h = floor($seconds / 3600);
    $m = floor(($seconds % 3600) / 60);
    $s = $seconds % 60;
    return sprintf('%02d:%02d:%02d', $h, $m, $s);
}

function seconds_to_human($seconds)
{
    $seconds = (int)$seconds;
    if ($seconds < 0) $seconds = 0;
    $h = floor($seconds / 3600);
    $m = floor(($seconds % 3600) / 60);
    $s = $seconds % 60;
    if ($h > 0) return sprintf('%dh %02dm %02ds', $h, $m, $s);
    if ($m > 0) return sprintf('%dm %02ds', $m, $s);
    return sprintf('%ds', $s);
}

function phone_variants($phone)
{
    $digits = preg_replace('/\D+/', '', (string)$phone);
    $variants = array();
    if ($digits === '') return $variants;

    $add = function($v) use (&$variants) {
        $v = preg_replace('/\D+/', '', (string)$v);
        if ($v !== '' && !in_array($v, $variants, true)) $variants[] = $v;
    };

    $add($digits);

    // Extensiones cortas de PBX u otra PBX: no se les debe anteponer cero.
    // Ej.: 1651 debe compararse como 1651, no como 01651.
    $maxExt = (int)app_config('reports.extension_match_max_digits', 6);
    if (strlen($digits) <= $maxExt) {
        $add(ltrim($digits, '0'));
        return array_values(array_filter($variants));
    }

    // Paraguay internacional: 595982197051 -> 982197051 y 0982197051.
    if (substr($digits, 0, 3) === '595' && strlen($digits) >= 11) {
        $local = substr($digits, 3);
        $add($local);
        if (strlen($local) === 9 && $local[0] !== '0') $add('0' . $local);
    }

    // Paraguay local sin cero: 981213858 -> 0981213858.
    if (strlen($digits) === 9 && $digits[0] !== '0') {
        $add('0' . $digits);
    }

    // Paraguay local con cero: 0981213858 -> 981213858.
    if (strlen($digits) === 10 && $digits[0] === '0') {
        $add(substr($digits, 1));
    }

    return array_values(array_filter($variants));
}

function normalize_phone($phone)
{
    $digits = preg_replace('/\D+/', '', (string)$phone);
    $variants = phone_variants($phone);
    if (!$variants) return '';
    $maxExt = (int)app_config('reports.extension_match_max_digits', 6);
    if ($digits !== '' && strlen($digits) <= $maxExt) {
        $ext = ltrim($digits, '0');
        return $ext !== '' ? $ext : $digits;
    }
    // Preferir formato local paraguayo con cero cuando aplique.
    foreach ($variants as $v) {
        if (strlen($v) === 10 && $v[0] === '0') return $v;
    }
    return $variants[0];
}

function phone_matches($a, $b)
{
    $va = phone_variants($a);
    $vb = phone_variants($b);
    if (!$va || !$vb) return false;

    foreach ($va as $pa) {
        foreach ($vb as $pb) {
            if ($pa !== '' && $pb !== '' && $pa === $pb) return true;
        }
    }

    $last = (int)app_config('reports.phone_match_last_digits', 8);
    foreach ($va as $pa) {
        foreach ($vb as $pb) {
            if (strlen($pa) >= $last && strlen($pb) >= $last && substr($pa, -$last) === substr($pb, -$last)) return true;
        }
    }

    return false;
}

function display_phone($phone)
{
    return normalize_phone($phone);
}

function range_from_request()
{
    $period = isset($_GET['period']) ? $_GET['period'] : 'today';
    $now = new DateTime('now');
    $start = new DateTime('today');
    $end = new DateTime('tomorrow');

    if ($period === 'yesterday') {
        $start = new DateTime('yesterday');
        $end = new DateTime('today');
    } elseif ($period === 'week') {
        $start = new DateTime('monday this week');
        $end = clone $start;
        $end->modify('+7 days');
    } elseif ($period === 'month') {
        $start = new DateTime('first day of this month 00:00:00');
        $end = new DateTime('first day of next month 00:00:00');
    } elseif ($period === 'custom') {
        $from = isset($_GET['from']) ? $_GET['from'] : date('Y-m-d');
        $to = isset($_GET['to']) ? $_GET['to'] : date('Y-m-d');
        $start = new DateTime($from . ' 00:00:00');
        $end = new DateTime($to . ' 00:00:00');
        $end->modify('+1 day');
    }

    return array(
        'period' => $period,
        'from' => $start->format('Y-m-d H:i:s'),
        'to' => $end->format('Y-m-d H:i:s'),
        'from_date' => $start->format('Y-m-d'),
        'to_date' => (clone $end)->modify('-1 second')->format('Y-m-d'),
        'label' => $start->format('d/m/Y H:i') . ' al ' . (clone $end)->modify('-1 second')->format('d/m/Y H:i'),
    );
}

function current_agent_filter()
{
    if (isset($_GET['agent_id']) && $_GET['agent_id'] !== '') {
        return (int)$_GET['agent_id'];
    }
    return null;
}

function build_query_string($extra)
{
    $params = $_GET;
    foreach ($extra as $k => $v) {
        if ($v === null) unset($params[$k]); else $params[$k] = $v;
    }
    return http_build_query($params);
}

function redirect($url)
{
    header('Location: ' . $url);
    exit;
}

function json_response($data, $status = 200)
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function download_csv($filename, $headers, $rows)
{
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    $out = fopen('php://output', 'w');
    fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF));
    fputcsv($out, $headers, ';');
    foreach ($rows as $row) {
        $line = array();
        foreach ($headers as $key => $label) {
            $line[] = isset($row[$key]) ? $row[$key] : '';
        }
        fputcsv($out, $line, ';');
    }
    fclose($out);
    exit;
}

function download_pdf($filename, $title, $headers, $rows, $meta = array(), $summary = array())
{
    $pdf = new SimplePdf($title);
    $subtitle = isset($meta['Rango']) ? 'Rango: ' . $meta['Rango'] : '';
    $pdf->addReportHeader($title, $subtitle, $meta);
    if (!isset($summary['Registros'])) $summary['Registros'] = count($rows);
    if (!isset($summary['Generado'])) $summary['Generado'] = date('d/m/Y H:i');
    $pdf->addSummaryCards($summary);
    $pdf->addTable($headers, $rows);
    $content = $pdf->render();
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . strlen($content));
    echo $content;
    exit;
}

function current_page($param = 'page')
{
    $page = isset($_GET[$param]) ? (int)$_GET[$param] : 1;
    return $page > 0 ? $page : 1;
}

function filter_rows_by_query($rows, $query, $fields)
{
    $query = trim((string)$query);
    if ($query === '') return $rows;
    $needle = strtolower($query);
    $out = array();
    foreach ($rows as $row) {
        foreach ($fields as $field) {
            $value = isset($row[$field]) ? strtolower((string)$row[$field]) : '';
            if ($value !== '' && strpos($value, $needle) !== false) {
                $out[] = $row;
                continue 2;
            }
        }
    }
    return $out;
}

function paginate_array($rows, $perPage = 30, $pageParam = 'page')
{
    $perPage = max(1, (int)$perPage);
    $total = count($rows);
    $totalPages = max(1, (int)ceil($total / $perPage));
    $page = current_page($pageParam);
    if ($page > $totalPages) $page = $totalPages;
    $offset = ($page - 1) * $perPage;
    return array(
        'rows' => array_slice($rows, $offset, $perPage),
        'page' => $page,
        'per_page' => $perPage,
        'total' => $total,
        'total_pages' => $totalPages,
        'offset' => $offset,
        'from' => $total > 0 ? $offset + 1 : 0,
        'to' => min($offset + $perPage, $total),
        'param' => $pageParam,
    );
}

function render_pagination($pagination, $pageParam = 'page')
{
    $totalPages = (int)$pagination['total_pages'];
    $page = (int)$pagination['page'];
    $total = (int)$pagination['total'];
    if ($totalPages <= 1 && $total <= (int)$pagination['per_page']) {
        echo '<div class="text-muted small">Mostrando ' . e($total) . ' registro(s).</div>';
        return;
    }
    echo '<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mt-3">';
    echo '<div class="text-muted small">Mostrando ' . e($pagination['from']) . ' a ' . e($pagination['to']) . ' de ' . e($total) . ' registros. Página ' . e($page) . ' de ' . e($totalPages) . '.</div>';
    echo '<nav aria-label="Paginación"><ul class="pagination pagination-sm mb-0">';

    $prev = max(1, $page - 1);
    $next = min($totalPages, $page + 1);
    $disabledPrev = $page <= 1 ? ' disabled' : '';
    $disabledNext = $page >= $totalPages ? ' disabled' : '';
    echo '<li class="page-item' . $disabledPrev . '"><a class="page-link" href="?' . e(build_query_string(array($pageParam => 1))) . '">Primera</a></li>';
    echo '<li class="page-item' . $disabledPrev . '"><a class="page-link" href="?' . e(build_query_string(array($pageParam => $prev))) . '">&laquo;</a></li>';

    $start = max(1, $page - 2);
    $end = min($totalPages, $page + 2);
    if ($start > 1) {
        echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
    }
    for ($i = $start; $i <= $end; $i++) {
        $active = $i === $page ? ' active' : '';
        echo '<li class="page-item' . $active . '"><a class="page-link" href="?' . e(build_query_string(array($pageParam => $i))) . '">' . e($i) . '</a></li>';
    }
    if ($end < $totalPages) {
        echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
    }
    echo '<li class="page-item' . $disabledNext . '"><a class="page-link" href="?' . e(build_query_string(array($pageParam => $next))) . '">&raquo;</a></li>';
    echo '<li class="page-item' . $disabledNext . '"><a class="page-link" href="?' . e(build_query_string(array($pageParam => $totalPages))) . '">Última</a></li>';
    echo '</ul></nav></div>';
}

function recording_source_url($recordingFile)
{
    $recordingFile = trim((string)$recordingFile);
    if ($recordingFile === '') return '';
    return 'recording.php?f=' . rawurlencode($recordingFile);
}

/**
 * URL segura para reproducir grabaciones.
 * Además del nombre guardado en CDR, permite buscar por uniqueid/linkedid cuando
 * Asterisk guarda el archivo en /var/spool/asterisk/monitor pero recordingfile viene vacío
 * o no coincide exactamente con el nombre físico.
 */
function recording_player_url($recordingFile, $uniqueid = '', $linkedid = '', $date = '', $src = '', $dst = '')
{
    $params = array();
    $recordingFile = trim((string)$recordingFile);
    $uniqueid = trim((string)$uniqueid);
    $linkedid = trim((string)$linkedid);
    $date = trim((string)$date);
    $src = trim((string)$src);
    $dst = trim((string)$dst);

    if ($recordingFile !== '') $params['f'] = $recordingFile;
    if ($uniqueid !== '') $params['u'] = $uniqueid;
    if ($linkedid !== '') $params['l'] = $linkedid;
    if ($date !== '') $params['date'] = $date;
    if ($src !== '') $params['src'] = $src;
    if ($dst !== '') $params['dst'] = $dst;

    if (empty($params)) return '';
    return 'recording.php?' . http_build_query($params);
}
