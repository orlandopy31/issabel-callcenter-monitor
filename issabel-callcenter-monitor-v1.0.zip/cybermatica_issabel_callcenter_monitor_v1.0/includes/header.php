<?php
$current = basename($_SERVER['PHP_SELF']);
function nav_active($file, $current) { return $file === $current ? 'active' : ''; }
if (!isset($pageTitle)) $pageTitle = app_config('app.name', 'Panel Issabel');
if (!isset($pageSubtitle)) $pageSubtitle = 'Gestión operativa de agentes, llamadas, pausas y reportes';
$headerUser = current_user();
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($pageTitle); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/css/app.css?v=47" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="assets/js/app.js?v=47"></script>
    <?php if (!has_permission('reports.export')): ?><style>a[href^="export.php"], a[href*="/export.php"]{display:none!important}</style><?php endif; ?>
    <?php if (!has_permission('recordings.view')): ?><style>a[href^="recording.php"], a[href*="/recording.php"]{display:none!important}</style><?php endif; ?>
</head>
<body>
<div class="app-shell">
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-brand d-flex gap-3 align-items-center">
            <div class="brand-badge"><i class="bi bi-headset"></i></div>
            <div>
                <div class="sidebar-title"><?php echo e(app_config('app.company', 'Call Center')); ?></div>
                <div class="sidebar-sub">Panel Ejecutivo Issabel</div>
            </div>
        </div>
        <nav class="sidebar-menu">
            <?php if (has_permission('dashboard.view') || has_permission('live.view') || has_permission('supervision.view') || has_permission('productivity.view') || has_permission('agents.view') || has_permission('outbound.view') || has_permission('calls.view') || has_permission('manual_calls.view')): ?>
                <div class="sidebar-section">Operación</div>
                <?php if (has_permission('dashboard.view')): ?><a class="<?php echo nav_active('index.php',$current); ?>" href="index.php"><i class="bi bi-speedometer2"></i> Dashboard ejecutivo</a><?php endif; ?>
                <?php if (has_permission('live.view')): ?><a class="<?php echo nav_active('live.php',$current); ?>" href="live.php"><i class="bi bi-broadcast-pin"></i> Monitoreo en tiempo real</a><?php endif; ?>
                <?php if (has_permission('supervision.view')): ?><a class="<?php echo nav_active('supervise.php',$current); ?>" href="supervise.php"><i class="bi bi-ear"></i> Escucha y susurro</a><?php endif; ?>
                <?php if (has_permission('productivity.view')): ?><a class="<?php echo nav_active('productivity.php',$current); ?>" href="productivity.php"><i class="bi bi-kanban"></i> Tablero de productividad</a><?php endif; ?>
                <?php if (has_permission('agents.view')): ?><a class="<?php echo nav_active('agents.php',$current); ?>" href="agents.php"><i class="bi bi-people"></i> Actividad por agente</a><?php endif; ?>
                <?php if (has_permission('outbound.view')): ?><a class="<?php echo nav_active('outbound_campaigns.php',$current); ?>" href="outbound_campaigns.php"><i class="bi bi-megaphone"></i> Campañas salientes</a><?php endif; ?>
                <?php if (has_permission('calls.view')): ?><a class="<?php echo nav_active('calls.php',$current); ?>" href="calls.php"><i class="bi bi-telephone-inbound"></i> Seguimiento de llamadas</a><?php endif; ?>
                <?php if (has_permission('manual_calls.view')): ?><a class="<?php echo nav_active('manual_calls.php',$current); ?>" href="manual_calls.php"><i class="bi bi-telephone-plus"></i> Manuales y directas</a><?php endif; ?>
            <?php endif; ?>

            <?php if (has_permission('pauses.view') || has_permission('sessions.view') || has_permission('abandoned.view') || has_permission('callbacks.view') || has_permission('service_level.view') || has_permission('inbound_comparison.view') || has_permission('after_hours.view') || has_permission('forms.view')): ?>
                <div class="sidebar-section">Control de gestión</div>
                <?php if (has_permission('pauses.view')): ?><a class="<?php echo nav_active('pauses.php',$current); ?>" href="pauses.php"><i class="bi bi-pause-circle"></i> Pausas</a><?php endif; ?>
                <?php if (has_permission('sessions.view')): ?><a class="<?php echo nav_active('sessions.php',$current); ?>" href="sessions.php"><i class="bi bi-clock-history"></i> Sesiones</a><?php endif; ?>
                <?php if (has_permission('abandoned.view')): ?><a class="<?php echo nav_active('abandoned.php',$current); ?>" href="abandoned.php"><i class="bi bi-exclamation-triangle"></i> Abandonadas</a><?php endif; ?>
                <?php if (has_permission('callbacks.view')): ?><a class="<?php echo in_array($current, array('callbacks.php','devoluciones.php'), true) ? 'active' : ''; ?>" href="callbacks.php"><i class="bi bi-arrow-repeat"></i> Devoluciones</a><?php endif; ?>
                <?php if (has_permission('service_level.view')): ?><a class="<?php echo nav_active('service_level.php',$current); ?>" href="service_level.php"><i class="bi bi-activity"></i> Nivel de servicio</a><?php endif; ?>
                <?php if (has_permission('inbound_comparison.view')): ?><a class="<?php echo nav_active('inbound_comparison.php',$current); ?>" href="inbound_comparison.php"><i class="bi bi-bar-chart-steps"></i> Comparativo entrantes</a><?php endif; ?>
                <?php if (has_permission('after_hours.view')): ?><a class="<?php echo nav_active('after_hours.php',$current); ?>" href="after_hours.php"><i class="bi bi-moon-stars"></i> Fuera de horario</a><?php endif; ?>
                <?php if (has_permission('forms.view')): ?><a class="<?php echo nav_active('forms.php',$current); ?>" href="forms.php"><i class="bi bi-ui-checks"></i> Formularios</a><?php endif; ?>
            <?php endif; ?>

            <?php if (has_permission('reports.view')): ?>
                <div class="sidebar-section">Reportería</div>
                <a class="<?php echo nav_active('reports.php',$current); ?>" href="reports.php"><i class="bi bi-file-earmark-bar-graph"></i> Centro de reportes</a>
            <?php endif; ?>

            <?php if (has_permission('users.manage') || has_permission('settings.sla.manage')): ?>
                <div class="sidebar-section">Administración</div>
                <?php if (has_permission('users.manage')): ?><a class="<?php echo nav_active('users.php',$current); ?>" href="users.php"><i class="bi bi-person-gear"></i> Usuarios y permisos</a><?php endif; ?>
                <?php if (has_permission('settings.sla.manage')): ?><a class="<?php echo nav_active('sla_settings.php',$current); ?>" href="sla_settings.php"><i class="bi bi-sliders"></i> Configuración SLA</a><?php endif; ?>
            <?php endif; ?>
        </nav>
        <div class="sidebar-footer small">
            <div class="fw-bold text-white mb-1"><i class="bi bi-shield-check"></i> Acceso controlado</div>
            <div>Las opciones visibles dependen de los permisos asignados al usuario.</div>
        </div>
    </aside>
    <div class="main-wrap">
        <header class="topbar">
            <div class="d-flex align-items-center gap-3">
                <button class="btn btn-outline-primary mobile-toggle" type="button" onclick="document.getElementById('sidebar').classList.toggle('show')"><i class="bi bi-list"></i></button>
                <div>
                    <h1 class="page-title h4"><?php echo e($pageTitle); ?></h1>
                    <div class="page-kicker"><?php echo e($pageSubtitle); ?></div>
                </div>
            </div>
            <div class="d-flex gap-2 align-items-center">
                <span class="status-pill d-none d-md-inline-flex"><span class="live-dot"></span> <?php echo e(date('d/m/Y H:i')); ?></span>
                <span class="status-pill"><i class="bi bi-person-circle"></i> <?php echo e($headerUser && $headerUser['full_name'] ? $headerUser['full_name'] : ($headerUser ? $headerUser['username'] : '')); ?></span>
                <a class="btn btn-sm btn-outline-danger" href="logout.php"><i class="bi bi-box-arrow-right"></i> Salir</a>
            </div>
        </header>
        <main class="content">
