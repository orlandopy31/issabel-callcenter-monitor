<?php
/**
 * Métricas ejecutivas y operativas v11.
 * Complementa ReportRepository con indicadores para toma de decisiones:
 * productividad, efectividad, nivel de servicio, pérdida de llamadas y no atendidas.
 */
class AnalyticsRepository extends ReportRepository
{
    private $ccAgent;
    private $ccAudit;
    private $ccBreak;
    private $ccCallEntry;
    private $ccCalls;
    private $ccCampaign;
    private $ccCampaignEntry;
    private $ccQueue;
    private $ccFormDataOut;
    private $ccFormDataIn;
    private $ccFormField;
    private $cdr;

    public function __construct()
    {
        parent::__construct();
        $this->ccAgent = DB::q('call_center', 'agent');
        $this->ccAudit = DB::q('call_center', 'audit');
        $this->ccBreak = DB::q('call_center', 'break');
        $this->ccCallEntry = DB::q('call_center', 'call_entry');
        $this->ccCalls = DB::q('call_center', 'calls');
        $this->ccCampaign = DB::q('call_center', 'campaign');
        $this->ccCampaignEntry = DB::q('call_center', 'campaign_entry');
        $this->ccQueue = DB::q('call_center', 'queue_call_entry');
        $this->ccFormDataOut = DB::q('call_center', 'form_data_recolected');
        $this->ccFormDataIn = DB::q('call_center', 'form_data_recolected_entry');
        $this->ccFormField = DB::q('call_center', 'form_field');
        $this->cdr = DB::q('cdr', 'cdr');
    }

    private function slaSeconds()
    {
        return report_sla_seconds();
    }

    private function slaTargetPct()
    {
        return report_sla_target_pct();
    }

    private function pct($num, $den)
    {
        $den = (float)$den;
        if ($den <= 0) return '0.00%';
        return number_format(((float)$num / $den) * 100, 2, '.', '') . '%';
    }

    private function pctNum($num, $den)
    {
        $den = (float)$den;
        if ($den <= 0) return 0;
        return round(((float)$num / $den) * 100, 2);
    }

    private function agentFilter($alias, $agentId, &$params)
    {
        if ($agentId !== null && $agentId !== '') {
            $params[':agent_id'] = (int)$agentId;
            return " AND {$alias}.id_agent = :agent_id ";
        }
        return '';
    }

    private function cdrAgentFilter($agentId, &$params)
    {
        if ($agentId !== null && $agentId !== '') {
            $params[':cdr_agent_id'] = (int)$agentId;
            return " AND a.id = :cdr_agent_id ";
        }
        return '';
    }

    private function bucketExpr($field, $bucket)
    {
        if ($bucket === 'day') return "DATE({$field})";
        if ($bucket === 'week') return "CONCAT(YEAR({$field}), '-S', LPAD(WEEK({$field}, 3), 2, '0'))";
        if ($bucket === 'month') return "DATE_FORMAT({$field}, '%Y-%m')";
        return "DATE_FORMAT({$field}, '%Y-%m-%d %H:00')";
    }

    private function bucketLabel($bucket)
    {
        if ($bucket === 'day') return 'Día';
        if ($bucket === 'week') return 'Semana';
        if ($bucket === 'month') return 'Mes';
        return 'Hora';
    }


    private function bucketValueFromDate($date, $bucket)
    {
        $ts = strtotime((string)$date);
        if (!$ts) return '';
        if ($bucket === 'day') return date('Y-m-d', $ts);
        if ($bucket === 'week') return date('o', $ts) . '-S' . str_pad((string)date('W', $ts), 2, '0', STR_PAD_LEFT);
        if ($bucket === 'month') return date('Y-m', $ts);
        return date('Y-m-d H:00', $ts);
    }

    private function getCallbackRecoveryMap($from, $to, $agentId = null, $bucket = 'hour')
    {
        $map = array();
        $callbacks = $this->getCallbacks($from, $to, $agentId, (int)app_config('app.max_export_rows', 30000));
        foreach ($callbacks as $cb) {
            $periodo = $this->bucketValueFromDate($cb['fecha_abandono'], $bucket);
            if ($periodo === '') continue;
            $cola = isset($cb['cola']) ? (string)$cb['cola'] : '';
            $key = $periodo . '|' . $cola;
            if (!isset($map[$key])) $map[$key] = array('devueltas'=>0, 'pendientes'=>0, 'total'=>0);
            $map[$key]['total']++;
            if (isset($cb['devuelta']) && $cb['devuelta'] === 'Sí') $map[$key]['devueltas']++;
            else $map[$key]['pendientes']++;
        }
        return $map;
    }

    private function answeredOutgoingCondition($alias)
    {
        return "(({$alias}.duration IS NOT NULL AND {$alias}.duration > 0) OR {$alias}.status LIKE '%ANSWER%' OR {$alias}.status LIKE '%Success%' OR {$alias}.status LIKE '%success%' OR {$alias}.status LIKE '%Completed%' OR {$alias}.status LIKE '%complete%')";
    }



    private function getReturnedCallbackStatsByAgent($from, $to, $agentId = null)
    {
        $stats = array('_total' => array('total' => 0, 'manual' => 0, 'campania' => 0));
        $callbacks = $this->getCallbacks($from, $to, $agentId, (int)app_config('app.max_export_rows', 30000));
        foreach ($callbacks as $cb) {
            if (!isset($cb['devuelta']) || $cb['devuelta'] !== 'Sí') continue;
            $id = isset($cb['id_agent_devolvio']) ? (int)$cb['id_agent_devolvio'] : 0;
            $origin = strtolower((isset($cb['origen_devolucion']) ? $cb['origen_devolucion'] : '') . ' ' . (isset($cb['tipo_devolucion']) ? $cb['tipo_devolucion'] : ''));
            $isManual = (strpos($origin, 'manual') !== false || strpos($origin, 'extension') !== false || strpos($origin, 'extensión') !== false);
            if ($id > 0) {
                if (!isset($stats[$id])) $stats[$id] = array('total' => 0, 'manual' => 0, 'campania' => 0);
                $stats[$id]['total']++;
                if ($isManual) $stats[$id]['manual']++; else $stats[$id]['campania']++;
            }
            $stats['_total']['total']++;
            if ($isManual) $stats['_total']['manual']++; else $stats['_total']['campania']++;
        }
        return $stats;
    }

    public function getAgentDecisionMetrics($from, $to, $agentId = null)
    {
        $base = $this->getAgentTotalReport($from, $to, $agentId);
        $returnedStats = $this->getReturnedCallbackStatsByAgent($from, $to, $agentId);
        $out = array();
        foreach ($base as $row) {
            if ($row['agente'] === 'TOTAL') continue;
            $id = (int)$row['id_agent'];
            $extra = $this->getAgentDecisionExtra($from, $to, $id);
            $ret = isset($returnedStats[$id]) ? $returnedStats[$id] : array('total'=>0, 'manual'=>0, 'campania'=>0);
            $returned = max((int)$row['abandonadas_devueltas'], (int)$ret['total']);
            $manualReturned = min((int)$row['manuales_salientes'], (int)$ret['manual']);
            $campaignReturned = min((int)$row['salientes_campania'], (int)$ret['campania']);
            $totalCalls = (int)$row['total_llamadas'];
            $sessionSec = isset($row['tiempo_logueo_seg']) ? (int)$row['tiempo_logueo_seg'] : 0;
            $pauseSec = isset($row['tiempo_pausa_seg']) ? (int)$row['tiempo_pausa_seg'] : 0;
            $talkSec = isset($row['tiempo_hablado_seg']) ? (int)$row['tiempo_hablado_seg'] : 0;
            $productiveSec = max(0, $sessionSec - $pauseSec);
            $answered = (int)$extra['respondidas'];
            $notAnswered = (int)$extra['no_atendidas'];
            $abandoned = (int)$row['abandonadas'];
            $pendingAbandoned = max(0, $abandoned - $returned);
            $notAnsweredGross = $notAnswered + $abandoned;
            $notAnsweredNet = $notAnswered + $pendingAbandoned;
            $answeredAdjusted = min($totalCalls, $answered + $returned);
            $serviceLevel = $this->pctNum($extra['dentro_sla'], $extra['ofrecidas_cola']);
            $effectiveness = $this->pctNum($answered, $totalCalls > 0 ? $totalCalls : ($answered + $notAnswered));
            $adjustedEffectiveness = $this->pctNum($answeredAdjusted, $totalCalls > 0 ? $totalCalls : ($answered + $notAnswered));
            $callsPerHour = $sessionSec > 0 ? round($totalCalls / ($sessionSec / 3600), 2) : 0;
            $productiveRate = $sessionSec > 0 ? $this->pctNum($productiveSec, $sessionSec) : 0;
            $score = round(($adjustedEffectiveness * 0.40) + ($serviceLevel * 0.20) + ($productiveRate * 0.20) + (min(100, $callsPerHour * 10) * 0.20), 2);
            $row['extension_relacionada'] = $row['extension_login'] !== '' ? $row['extension_login'] : $row['agente'];
            $row['respondidas'] = $answered;
            $row['respondidas_ajustadas'] = $answeredAdjusted;
            $row['no_atendidas'] = $notAnsweredNet;
            $row['no_atendidas_brutas'] = $notAnsweredGross;
            $row['no_atendidas_netas'] = $notAnsweredNet;
            $row['abandonadas_pendientes'] = $pendingAbandoned;
            $row['abandonadas_devueltas'] = $returned;
            $row['devueltas_manual'] = $manualReturned;
            $row['devueltas_campania'] = $campaignReturned;
            $row['salientes_no_devolucion'] = max(0, (int)$row['total_realizadas'] - $returned);
            $row['manuales_salientes_gestion'] = max(0, (int)$row['manuales_salientes'] - $manualReturned);
            $row['campania_salientes_no_devolucion'] = max(0, (int)$row['salientes_campania'] - $campaignReturned);
            $row['efectividad_pct'] = number_format($effectiveness, 2, '.', '') . '%';
            $row['efectividad_ajustada_pct'] = number_format($adjustedEffectiveness, 2, '.', '') . '%';
            $row['nivel_servicio_pct'] = number_format($serviceLevel, 2, '.', '') . '%';
            $row['sla_meta_pct'] = number_format($this->slaTargetPct(), 2, '.', '') . '%';
            $row['cumple_sla'] = $serviceLevel >= $this->slaTargetPct() ? 'CUMPLE' : 'NO CUMPLE';
            $row['sla_objetivo'] = report_sla_policy_label();
            $row['ofrecidas_cola'] = (int)$extra['ofrecidas_cola'];
            $row['dentro_sla'] = (int)$extra['dentro_sla'];
            $row['espera_promedio'] = seconds_to_hms($extra['espera_promedio']);
            $row['espera_maxima'] = seconds_to_hms($extra['espera_maxima']);
            $row['llamadas_por_hora'] = $callsPerHour;
            $row['tiempo_productivo'] = seconds_to_hms($productiveSec);
            $row['productividad_pct'] = number_format($productiveRate, 2, '.', '') . '%';
            $row['score_productividad'] = $score;
            $row['hora_mayor_no_atendida'] = $extra['hora_mayor_no_atendida'];
            $row['perdidas_en_hora_pico'] = $extra['perdidas_en_hora_pico'];
            $out[] = $row;
        }
        usort($out, function($a, $b) {
            if ($a['score_productividad'] == $b['score_productividad']) return strcmp($a['agente'], $b['agente']);
            return ($a['score_productividad'] < $b['score_productividad']) ? 1 : -1;
        });
        if ($agentId === null && count($out) > 1) {
            $out[] = $this->buildDecisionTotalRow($out);
        }
        return $out;
    }

    private function buildDecisionTotalRow($rows)
    {
        $tot = array(
            'id_agent'=>'','agente'=>'TOTAL','nombre'=>'Todos los agentes','tipo'=>'','extension_relacionada'=>'',
            'sesiones'=>0,'tiempo_logueo_seg'=>0,'pausas'=>0,'tiempo_pausa_seg'=>0,
            'entrantes_callcenter'=>0,'manuales_entrantes'=>0,'salientes_campania'=>0,'manuales_salientes'=>0,
            'total_recibidas'=>0,'total_realizadas'=>0,'total_llamadas'=>0,'respondidas'=>0,'respondidas_ajustadas'=>0,
            'no_atendidas'=>0,'no_atendidas_brutas'=>0,'no_atendidas_netas'=>0,
            'abandonadas'=>0,'abandonadas_devueltas'=>0,'abandonadas_pendientes'=>0,
            'devueltas_manual'=>0,'devueltas_campania'=>0,'salientes_no_devolucion'=>0,'manuales_salientes_gestion'=>0,'campania_salientes_no_devolucion'=>0,
            'transferidas'=>0,'formularios'=>0,'tiempo_hablado_seg'=>0,'tiempo_total_llamadas_seg'=>0,
            'ofrecidas_cola'=>0,'dentro_sla'=>0,'perdidas_en_hora_pico'=>0
        );
        foreach ($rows as $r) {
            foreach (array('sesiones','tiempo_logueo_seg','pausas','tiempo_pausa_seg','entrantes_callcenter','manuales_entrantes','salientes_campania','manuales_salientes','total_recibidas','total_realizadas','total_llamadas','respondidas','respondidas_ajustadas','no_atendidas','no_atendidas_brutas','no_atendidas_netas','abandonadas','abandonadas_devueltas','abandonadas_pendientes','devueltas_manual','devueltas_campania','salientes_no_devolucion','manuales_salientes_gestion','campania_salientes_no_devolucion','transferidas','formularios','tiempo_hablado_seg','tiempo_total_llamadas_seg','ofrecidas_cola','dentro_sla','perdidas_en_hora_pico') as $k) {
                $tot[$k] += isset($r[$k]) ? (int)$r[$k] : 0;
            }
        }
        $tot['tiempo_logueo'] = seconds_to_hms($tot['tiempo_logueo_seg']);
        $tot['tiempo_pausa'] = seconds_to_hms($tot['tiempo_pausa_seg']);
        $tot['tiempo_hablado'] = seconds_to_hms($tot['tiempo_hablado_seg']);
        $tot['tiempo_total_llamadas'] = seconds_to_hms($tot['tiempo_total_llamadas_seg']);
        $tot['promedio_hablado'] = seconds_to_hms($tot['total_llamadas'] > 0 ? round($tot['tiempo_hablado_seg'] / $tot['total_llamadas']) : 0);
        $tot['ocupacion_pct'] = $this->pct($tot['tiempo_hablado_seg'], $tot['tiempo_logueo_seg']);
        $tot['pausa_pct'] = $this->pct($tot['tiempo_pausa_seg'], $tot['tiempo_logueo_seg']);
        $tot['efectividad_pct'] = $this->pct($tot['respondidas'], $tot['total_llamadas']);
        $tot['efectividad_ajustada_pct'] = $this->pct($tot['respondidas_ajustadas'], $tot['total_llamadas']);
        $tot['nivel_servicio_pct'] = $this->pct($tot['dentro_sla'], $tot['ofrecidas_cola']);
        $totalSlNum = $this->pctNum($tot['dentro_sla'], $tot['ofrecidas_cola']);
        $tot['sla_meta_pct'] = number_format($this->slaTargetPct(), 2, '.', '') . '%';
        $tot['cumple_sla'] = $totalSlNum >= $this->slaTargetPct() ? 'CUMPLE' : 'NO CUMPLE';
        $tot['sla_objetivo'] = report_sla_policy_label();
        $tot['espera_promedio'] = '';
        $tot['espera_maxima'] = '';
        $tot['llamadas_por_hora'] = $tot['tiempo_logueo_seg'] > 0 ? round($tot['total_llamadas'] / ($tot['tiempo_logueo_seg'] / 3600), 2) : 0;
        $tot['tiempo_productivo'] = seconds_to_hms(max(0, $tot['tiempo_logueo_seg'] - $tot['tiempo_pausa_seg']));
        $tot['productividad_pct'] = $this->pct(max(0, $tot['tiempo_logueo_seg'] - $tot['tiempo_pausa_seg']), $tot['tiempo_logueo_seg']);
        $tot['score_productividad'] = '';
        $tot['hora_mayor_no_atendida'] = '';
        return $tot;
    }

    private function getAgentDecisionExtra($from, $to, $agentId)
    {
        $sla = $this->slaSeconds();
        $params = array(':from'=>$from, ':to'=>$to, ':agent_id'=>(int)$agentId, ':sla'=>$sla);
        $incoming = DB::fetch("SELECT COUNT(*) ofrecidas, SUM(CASE WHEN ce.id_agent IS NOT NULL THEN 1 ELSE 0 END) respondidas, SUM(CASE WHEN ce.id_agent IS NOT NULL AND IFNULL(ce.duration_wait,0) <= :sla THEN 1 ELSE 0 END) dentro_sla, AVG(IFNULL(ce.duration_wait,0)) espera_promedio, MAX(IFNULL(ce.duration_wait,0)) espera_maxima FROM {$this->ccCallEntry} ce WHERE COALESCE(ce.datetime_init, ce.datetime_entry_queue) >= :from AND COALESCE(ce.datetime_init, ce.datetime_entry_queue) < :to AND ce.id_agent = :agent_id", $params);

        $params = array(':from'=>$from, ':to'=>$to, ':agent_id'=>(int)$agentId);
        $outCamp = DB::fetch("SELECT SUM(CASE WHEN {$this->answeredOutgoingCondition('c')} THEN 1 ELSE 0 END) answered, SUM(CASE WHEN NOT {$this->answeredOutgoingCondition('c')} THEN 1 ELSE 0 END) no_answer FROM {$this->ccCalls} c WHERE COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue) >= :from AND COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue) < :to AND c.id_agent = :agent_id", $params);

        $params = array(':from'=>$from, ':to'=>$to, ':agent_id'=>(int)$agentId);
        $manualOut = DB::fetch("SELECT SUM(CASE WHEN cd.disposition='ANSWERED' AND cd.billsec > 0 THEN 1 ELSE 0 END) answered, SUM(CASE WHEN cd.disposition<>'ANSWERED' OR cd.billsec = 0 THEN 1 ELSE 0 END) no_answer FROM {$this->cdr} cd INNER JOIN {$this->ccAgent} a ON (a.number = cd.src OR cd.channel LIKE CONCAT('PJSIP/', a.number, '-%') OR cd.channel LIKE CONCAT('SIP/', a.number, '-%') OR cd.channel LIKE CONCAT('IAX2/', a.number, '-%')) WHERE cd.calldate >= :from AND cd.calldate < :to AND a.id = :agent_id AND cd.dst NOT IN (SELECT number FROM {$this->ccAgent}) AND NOT EXISTS (SELECT 1 FROM {$this->ccCalls} c WHERE c.uniqueid IS NOT NULL AND c.uniqueid <> '' AND (c.uniqueid = cd.uniqueid OR c.uniqueid = cd.linkedid)) AND NOT EXISTS (SELECT 1 FROM {$this->ccCallEntry} ce WHERE ce.uniqueid IS NOT NULL AND ce.uniqueid <> '' AND (ce.uniqueid = cd.uniqueid OR ce.uniqueid = cd.linkedid))", $params);

        $manualIn = DB::fetch("SELECT SUM(CASE WHEN cd.disposition='ANSWERED' AND cd.billsec > 0 THEN 1 ELSE 0 END) answered, SUM(CASE WHEN cd.disposition<>'ANSWERED' OR cd.billsec = 0 THEN 1 ELSE 0 END) no_answer FROM {$this->cdr} cd INNER JOIN {$this->ccAgent} a ON (cd.dst = a.number OR cd.dstchannel LIKE CONCAT('PJSIP/', a.number, '-%') OR cd.dstchannel LIKE CONCAT('SIP/', a.number, '-%') OR cd.dstchannel LIKE CONCAT('IAX2/', a.number, '-%')) WHERE cd.calldate >= :from AND cd.calldate < :to AND a.id = :agent_id AND cd.src NOT IN (SELECT number FROM {$this->ccAgent}) AND NOT EXISTS (SELECT 1 FROM {$this->ccCallEntry} ce WHERE ce.uniqueid IS NOT NULL AND ce.uniqueid <> '' AND (ce.uniqueid = cd.uniqueid OR ce.uniqueid = cd.linkedid))", $params);

        $hour = $this->getAgentPeakMissedHour($from, $to, $agentId);
        $respondidas = (int)$incoming['respondidas'] + (int)$outCamp['answered'] + (int)$manualOut['answered'] + (int)$manualIn['answered'];
        $noAtendidas = (int)$outCamp['no_answer'] + (int)$manualOut['no_answer'] + (int)$manualIn['no_answer'];
        return array(
            'ofrecidas_cola'=>(int)$incoming['ofrecidas'],
            'dentro_sla'=>(int)$incoming['dentro_sla'],
            'respondidas'=>$respondidas,
            'no_atendidas'=>$noAtendidas,
            'espera_promedio'=>(int)$incoming['espera_promedio'],
            'espera_maxima'=>(int)$incoming['espera_maxima'],
            'hora_mayor_no_atendida'=>$hour['hora'],
            'perdidas_en_hora_pico'=>$hour['total']
        );
    }

    private function getAgentPeakMissedHour($from, $to, $agentId)
    {
        $params = array(':from'=>$from, ':to'=>$to, ':agent_id'=>(int)$agentId);
        $rows = array();
        $sql = "SELECT DATE_FORMAT(COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue),'%H:00') hora, COUNT(*) total FROM {$this->ccCalls} c WHERE COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue) >= :from AND COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue) < :to AND c.id_agent = :agent_id AND NOT {$this->answeredOutgoingCondition('c')} GROUP BY DATE_FORMAT(COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue),'%H') ORDER BY total DESC LIMIT 1";
        $r = DB::fetch($sql, $params);
        if ($r) return array('hora'=>$r['hora'], 'total'=>(int)$r['total']);
        return array('hora'=>'', 'total'=>0);
    }

    private function getCallbackServiceStats($from, $to, $agentId = null, $bucket = 'hour')
    {
        $stats = array(
            'returned' => array(),
            'pending' => array(),
            'total_abandoned' => array()
        );

        $callbacks = $this->getCallbacks($from, $to, $agentId, (int)app_config('app.max_export_rows', 30000));
        foreach ($callbacks as $cb) {
            $periodo = $this->bucketValueFromDate(isset($cb['fecha_abandono']) ? $cb['fecha_abandono'] : '', $bucket);
            if ($periodo === '') continue;
            $cola = isset($cb['cola']) ? (string)$cb['cola'] : '';
            $bucketKey = $periodo . '|' . $cola;
            if (!isset($stats['total_abandoned'][$bucketKey])) $stats['total_abandoned'][$bucketKey] = 0;
            $stats['total_abandoned'][$bucketKey]++;

            $isReturned = (isset($cb['devuelta']) && $cb['devuelta'] === 'Sí');
            if ($isReturned) {
                $agentNumber = isset($cb['agente_devolvio_numero']) ? trim((string)$cb['agente_devolvio_numero']) : '';
                $agentName = isset($cb['agente_devolvio_nombre']) ? trim((string)$cb['agente_devolvio_nombre']) : '';
                $agentIdReturn = isset($cb['id_agent_devolvio']) ? (int)$cb['id_agent_devolvio'] : 0;
                $extension = isset($cb['extension_devolvio']) ? trim((string)$cb['extension_devolvio']) : '';

                if ($agentNumber === '' && $extension !== '') $agentNumber = $extension;
                if ($agentNumber === '') $agentNumber = 'SIN AGENTE';
                if ($agentName === '' && $agentNumber === 'SIN AGENTE') $agentName = 'Devolución sin agente identificado';
                if ($agentName === '') $agentName = 'Agente que devolvió';

                $key = $bucketKey . '|' . $agentNumber;
                if (!isset($stats['returned'][$key])) {
                    $stats['returned'][$key] = array(
                        'periodo' => $periodo,
                        'cola' => $cola,
                        'agente' => $agentNumber,
                        'nombre' => $agentName,
                        'id_agent' => $agentIdReturn,
                        'devueltas' => 0
                    );
                }
                $stats['returned'][$key]['devueltas']++;
            } else {
                // Las pendientes no tienen agente que las haya gestionado. Se muestran en una fila operativa propia.
                if ($agentId === null || $agentId === '') {
                    if (!isset($stats['pending'][$bucketKey])) {
                        $stats['pending'][$bucketKey] = array(
                            'periodo' => $periodo,
                            'cola' => $cola,
                            'pendientes' => 0
                        );
                    }
                    $stats['pending'][$bucketKey]['pendientes']++;
                }
            }
        }
        return $stats;
    }



    public function getInboundQueueList($from = null, $to = null)
    {
        $params = array();
        $where = '';
        if ($from !== null && $to !== null) {
            $params[':from'] = $from;
            $params[':to'] = $to;
            $where = " WHERE COALESCE(ce.datetime_entry_queue, ce.datetime_init) >= :from AND COALESCE(ce.datetime_entry_queue, ce.datetime_init) < :to ";
        }
        $sql = "SELECT DISTINCT COALESCE(q.queue, '') queue_number
                FROM {$this->ccCallEntry} ce
                LEFT JOIN {$this->ccQueue} q ON q.id = ce.id_queue_call_entry
                {$where}
                ORDER BY queue_number";
        $rows = DB::fetchAll($sql, $params);
        $out = array();
        foreach ($rows as $r) {
            $q = trim((string)$r['queue_number']);
            if ($q !== '') $out[] = $q;
        }
        return $out;
    }

    public function getInboundQueueComparison($from, $to, $bucket = 'day', $queue = null)
    {
        if (!in_array($bucket, array('hour','day','week','month'), true)) $bucket = 'day';
        $dateField = 'COALESCE(ce.datetime_entry_queue, ce.datetime_init)';
        $bucketSql = $this->bucketExpr($dateField, $bucket);
        $abandonedStatusSql = "(ce.status LIKE '%abandon%' OR ce.status LIKE '%ABANDON%' OR ce.status LIKE '%Abandon%')";
        $params = array(':from'=>$from, ':to'=>$to, ':sla'=>$this->slaSeconds());
        $queueSql = '';
        if ($queue !== null && trim((string)$queue) !== '') {
            $params[':queue'] = trim((string)$queue);
            $queueSql = " AND COALESCE(q.queue, '') = :queue ";
        }

        $sql = "SELECT
                    {$bucketSql} periodo,
                    COALESCE(q.queue, '') cola,
                    COUNT(*) ofrecidas,
                    SUM(CASE WHEN ce.id_agent IS NOT NULL AND NOT {$abandonedStatusSql} THEN 1 ELSE 0 END) contestadas,
                    SUM(CASE WHEN ce.id_agent IS NULL OR {$abandonedStatusSql} THEN 1 ELSE 0 END) abandonadas,
                    SUM(CASE WHEN ce.id_agent IS NOT NULL AND NOT {$abandonedStatusSql} AND IFNULL(ce.duration_wait,0) <= :sla THEN 1 ELSE 0 END) dentro_sla,
                    AVG(IFNULL(ce.duration_wait,0)) espera_promedio_seg,
                    MAX(IFNULL(ce.duration_wait,0)) espera_maxima_seg,
                    SUM(IFNULL(ce.duration,0)) hablado_seg
                FROM {$this->ccCallEntry} ce
                LEFT JOIN {$this->ccQueue} q ON q.id = ce.id_queue_call_entry
                WHERE {$dateField} >= :from
                  AND {$dateField} < :to
                  {$queueSql}
                GROUP BY {$bucketSql}, COALESCE(q.queue, '')
                ORDER BY periodo DESC, cola";
        $baseRows = DB::fetchAll($sql, $params);

        $rowsByKey = array();
        foreach ($baseRows as $r) {
            $cola = trim((string)$r['cola']);
            if ($cola === '') $cola = 'SIN COLA';
            $key = $r['periodo'] . '|' . $cola;
            $rowsByKey[$key] = array(
                'periodo' => $r['periodo'],
                'bucket' => $this->bucketLabel($bucket),
                'cola' => $cola,
                'ofrecidas' => (int)$r['ofrecidas'],
                'contestadas' => (int)$r['contestadas'],
                'abandonadas' => (int)$r['abandonadas'],
                'devueltas' => 0,
                'pendientes' => 0,
                'dentro_sla' => (int)$r['dentro_sla'],
                'espera_promedio_seg' => (int)$r['espera_promedio_seg'],
                'espera_maxima_seg' => (int)$r['espera_maxima_seg'],
                'hablado_seg' => (int)$r['hablado_seg'],
            );
        }

        // La lógica de devolución se basa en el mismo macheo de callbacks/devoluciones.
        $callbacks = $this->getCallbacks($from, $to, null, (int)app_config('app.max_export_rows', 30000));
        $cbStats = array();
        foreach ($callbacks as $cb) {
            $cola = isset($cb['cola']) ? trim((string)$cb['cola']) : '';
            if ($cola === '') $cola = 'SIN COLA';
            if ($queue !== null && trim((string)$queue) !== '' && $cola !== trim((string)$queue)) continue;
            $periodo = $this->bucketValueFromDate(isset($cb['fecha_abandono']) ? $cb['fecha_abandono'] : '', $bucket);
            if ($periodo === '') continue;
            $key = $periodo . '|' . $cola;
            if (!isset($cbStats[$key])) $cbStats[$key] = array('total'=>0, 'devueltas'=>0, 'pendientes'=>0, 'periodo'=>$periodo, 'cola'=>$cola);
            $cbStats[$key]['total']++;
            if (isset($cb['devuelta']) && $cb['devuelta'] === 'Sí') $cbStats[$key]['devueltas']++;
            else $cbStats[$key]['pendientes']++;
        }

        foreach ($cbStats as $key => $st) {
            if (!isset($rowsByKey[$key])) {
                $rowsByKey[$key] = array(
                    'periodo' => $st['periodo'],
                    'bucket' => $this->bucketLabel($bucket),
                    'cola' => $st['cola'],
                    'ofrecidas' => (int)$st['total'],
                    'contestadas' => 0,
                    'abandonadas' => (int)$st['total'],
                    'devueltas' => 0,
                    'pendientes' => 0,
                    'dentro_sla' => 0,
                    'espera_promedio_seg' => 0,
                    'espera_maxima_seg' => 0,
                    'hablado_seg' => 0,
                );
            }
            if ((int)$rowsByKey[$key]['abandonadas'] < (int)$st['total']) {
                $rowsByKey[$key]['abandonadas'] = (int)$st['total'];
            }
            $rowsByKey[$key]['devueltas'] = (int)$st['devueltas'];
        }

        $rows = array_values($rowsByKey);
        usort($rows, function($a, $b) {
            $c = strcmp((string)$b['periodo'], (string)$a['periodo']);
            if ($c !== 0) return $c;
            return strcmp((string)$a['cola'], (string)$b['cola']);
        });

        foreach ($rows as &$r) {
            $r['pendientes'] = max(0, (int)$r['abandonadas'] - (int)$r['devueltas']);
            $r['gestionadas_ajustadas'] = min((int)$r['ofrecidas'], (int)$r['contestadas'] + (int)$r['devueltas']);
            $r['tasa_contestacion_pct'] = $this->pct($r['contestadas'], $r['ofrecidas']);
            $r['tasa_abandono_pct'] = $this->pct($r['abandonadas'], $r['ofrecidas']);
            $r['nivel_devolucion_pct'] = $this->pct($r['devueltas'], $r['abandonadas']);
            $r['tasa_pendiente_pct'] = $this->pct($r['pendientes'], $r['ofrecidas']);
            $r['eficiencia_ajustada_pct'] = $this->pct($r['gestionadas_ajustadas'], $r['ofrecidas']);
            $slaNum = $this->pctNum($r['dentro_sla'], $r['ofrecidas']);
            $r['nivel_servicio_pct'] = number_format($slaNum, 2, '.', '') . '%';
            $r['sla_meta_pct'] = number_format($this->slaTargetPct(), 2, '.', '') . '%';
            $r['cumple_sla'] = $slaNum >= $this->slaTargetPct() ? 'CUMPLE' : 'NO CUMPLE';
            $r['sla_objetivo'] = report_sla_policy_label();
            $r['espera_promedio'] = seconds_to_hms(isset($r['espera_promedio_seg']) ? $r['espera_promedio_seg'] : 0);
            $r['espera_maxima'] = seconds_to_hms(isset($r['espera_maxima_seg']) ? $r['espera_maxima_seg'] : 0);
            $r['tiempo_hablado'] = seconds_to_hms(isset($r['hablado_seg']) ? $r['hablado_seg'] : 0);
        }
        return $rows;
    }


    public function getServiceLevel($from, $to, $agentId = null, $bucket = 'hour')
    {
        $dateField = 'COALESCE(ce.datetime_entry_queue, ce.datetime_init)';
        $bucketSql = $this->bucketExpr($dateField, $bucket);
        $params = array(':from'=>$from, ':to'=>$to, ':sla'=>$this->slaSeconds());
        $agentSql = '';
        if ($agentId !== null && $agentId !== '') {
            $params[':agent_id'] = (int)$agentId;
            $agentSql = ' AND ce.id_agent = :agent_id ';
        }

        // Base: llamadas efectivamente atendidas/asignadas a agente.
        // Las abandonadas se calculan por la misma lógica de callbacks/devoluciones para que no queden en cero.
        $abandonedStatusSql = "(ce.status LIKE '%abandon%' OR ce.status LIKE '%ABANDON%' OR ce.status LIKE '%Abandon%')";
        $sql = "SELECT
                    {$bucketSql} periodo,
                    COALESCE(q.queue, '') cola,
                    COALESCE(a.number, 'SIN AGENTE') agente,
                    COALESCE(a.name, 'No atendida') nombre,
                    COUNT(*) ofrecidas,
                    COUNT(*) atendidas,
                    0 abandonadas,
                    SUM(CASE WHEN IFNULL(ce.duration_wait,0) <= :sla THEN 1 ELSE 0 END) dentro_sla,
                    AVG(IFNULL(ce.duration_wait,0)) espera_promedio_seg,
                    MAX(IFNULL(ce.duration_wait,0)) espera_maxima_seg,
                    AVG(IFNULL(ce.duration,0)) hablado_promedio_seg
                FROM {$this->ccCallEntry} ce
                LEFT JOIN {$this->ccAgent} a ON a.id=ce.id_agent
                LEFT JOIN {$this->ccQueue} q ON q.id=ce.id_queue_call_entry
                WHERE {$dateField} >= :from
                  AND {$dateField} < :to
                  {$agentSql}
                  AND ce.id_agent IS NOT NULL
                  AND NOT {$abandonedStatusSql}
                GROUP BY {$bucketSql}, COALESCE(q.queue, ''), COALESCE(a.number, 'SIN AGENTE'), COALESCE(a.name, 'No atendida')
                ORDER BY periodo DESC, cola, agente";
        $baseRows = DB::fetchAll($sql, $params);

        $rowsByKey = array();
        foreach ($baseRows as $r) {
            $key = $r['periodo'] . '|' . (string)$r['cola'] . '|' . (string)$r['agente'];
            $r['bucket'] = $this->bucketLabel($bucket);
            $r['ofrecidas'] = (int)$r['ofrecidas'];
            $r['atendidas'] = (int)$r['atendidas'];
            $r['abandonadas'] = (int)$r['abandonadas'];
            $r['devueltas'] = 0;
            $r['abandonadas_pendientes'] = 0;
            $r['dentro_sla'] = (int)$r['dentro_sla'];
            $r['espera_promedio_seg'] = (int)$r['espera_promedio_seg'];
            $r['espera_maxima_seg'] = (int)$r['espera_maxima_seg'];
            $r['hablado_promedio_seg'] = (int)$r['hablado_promedio_seg'];
            $rowsByKey[$key] = $r;
        }

        $callbackStats = $this->getCallbackServiceStats($from, $to, $agentId, $bucket);

        // Devueltas: se suman al agente/extensión que recuperó la abandonada.
        foreach ($callbackStats['returned'] as $key => $ret) {
            $dev = (int)$ret['devueltas'];
            if ($dev <= 0) continue;
            if (!isset($rowsByKey[$key])) {
                $rowsByKey[$key] = array(
                    'periodo' => $ret['periodo'],
                    'bucket' => $this->bucketLabel($bucket),
                    'cola' => $ret['cola'],
                    'agente' => $ret['agente'],
                    'nombre' => $ret['nombre'],
                    'ofrecidas' => 0,
                    'atendidas' => 0,
                    'abandonadas' => 0,
                    'devueltas' => 0,
                    'abandonadas_pendientes' => 0,
                    'dentro_sla' => 0,
                    'espera_promedio_seg' => 0,
                    'espera_maxima_seg' => 0,
                    'hablado_promedio_seg' => 0,
                );
            }
            $rowsByKey[$key]['devueltas'] += $dev;
            $rowsByKey[$key]['abandonadas'] += $dev;
            $rowsByKey[$key]['ofrecidas'] += $dev;
        }

        // Pendientes: se muestran como fila separada para que el tablero y PDF no oculten lo no devuelto.
        foreach ($callbackStats['pending'] as $bucketKey => $pen) {
            $pending = (int)$pen['pendientes'];
            if ($pending <= 0) continue;
            $key = $pen['periodo'] . '|' . (string)$pen['cola'] . '|PENDIENTES';
            if (!isset($rowsByKey[$key])) {
                $rowsByKey[$key] = array(
                    'periodo' => $pen['periodo'],
                    'bucket' => $this->bucketLabel($bucket),
                    'cola' => $pen['cola'],
                    'agente' => 'PENDIENTES',
                    'nombre' => 'Abandonadas sin devolución',
                    'ofrecidas' => 0,
                    'atendidas' => 0,
                    'abandonadas' => 0,
                    'devueltas' => 0,
                    'abandonadas_pendientes' => 0,
                    'dentro_sla' => 0,
                    'espera_promedio_seg' => 0,
                    'espera_maxima_seg' => 0,
                    'hablado_promedio_seg' => 0,
                );
            }
            $rowsByKey[$key]['abandonadas'] += $pending;
            $rowsByKey[$key]['abandonadas_pendientes'] += $pending;
            $rowsByKey[$key]['ofrecidas'] += $pending;
        }

        $rows = array_values($rowsByKey);
        usort($rows, function($a, $b) {
            $c = strcmp((string)$b['periodo'], (string)$a['periodo']);
            if ($c !== 0) return $c;
            $c = strcmp((string)$a['cola'], (string)$b['cola']);
            if ($c !== 0) return $c;
            return strcmp((string)$a['agente'], (string)$b['agente']);
        });

        foreach ($rows as &$r) {
            $abandonadas = (int)$r['abandonadas'];
            $devueltas = (int)$r['devueltas'];
            $pendientes = isset($r['abandonadas_pendientes']) ? (int)$r['abandonadas_pendientes'] : max(0, $abandonadas - $devueltas);
            if ($pendientes < 0) $pendientes = 0;
            $r['abandonadas_pendientes'] = $pendientes;
            $r['nivel_devolucion_pct'] = $this->pct($devueltas, $abandonadas);
            $slaNum = $this->pctNum($r['dentro_sla'], $r['ofrecidas']);
            $r['nivel_servicio_pct'] = number_format($slaNum, 2, '.', '') . '%';
            $r['sla_meta_pct'] = number_format($this->slaTargetPct(), 2, '.', '') . '%';
            $r['cumple_sla'] = $slaNum >= $this->slaTargetPct() ? 'CUMPLE' : 'NO CUMPLE';
            $ajustado = min((int)$r['ofrecidas'], ((int)$r['dentro_sla'] + $devueltas));
            $r['nivel_servicio_ajustado_pct'] = $this->pct($ajustado, $r['ofrecidas']);
            $r['tasa_atencion_pct'] = $this->pct($r['atendidas'], $r['ofrecidas']);
            $r['tasa_abandono_pct'] = $this->pct($abandonadas, $r['ofrecidas']);
            $r['tasa_abandono_neta_pct'] = $this->pct($pendientes, $r['ofrecidas']);
            $r['espera_promedio'] = seconds_to_hms(isset($r['espera_promedio_seg']) ? $r['espera_promedio_seg'] : 0);
            $r['espera_maxima'] = seconds_to_hms(isset($r['espera_maxima_seg']) ? $r['espera_maxima_seg'] : 0);
            $r['hablado_promedio'] = seconds_to_hms(isset($r['hablado_promedio_seg']) ? $r['hablado_promedio_seg'] : 0);
            $r['sla_objetivo'] = report_sla_policy_label();
        }
        return $rows;
    }

    public function getLostCallsByHour($from, $to, $agentId = null)
    {
        $params = array(':from'=>$from, ':to'=>$to);
        $agentSql = '';
        if ($agentId !== null && $agentId !== '') {
            $params[':agent_id'] = (int)$agentId;
            $agentSql = ' AND ce.id_agent = :agent_id ';
        }
        $sql = "SELECT DATE_FORMAT(ce.datetime_entry_queue, '%H:00') hora, q.queue cola, COUNT(*) abandonadas, AVG(IFNULL(ce.duration_wait,0)) espera_promedio_seg, MAX(IFNULL(ce.duration_wait,0)) espera_maxima_seg FROM {$this->ccCallEntry} ce LEFT JOIN {$this->ccQueue} q ON q.id=ce.id_queue_call_entry WHERE ce.datetime_entry_queue >= :from AND ce.datetime_entry_queue < :to {$agentSql} AND (ce.id_agent IS NULL OR ce.status LIKE '%abandon%' OR ce.status LIKE '%ABANDON%' OR ce.status LIKE '%Abandon%') GROUP BY DATE_FORMAT(ce.datetime_entry_queue, '%H'), q.queue ORDER BY abandonadas DESC, hora ASC";
        $rows = DB::fetchAll($sql, $params);
        foreach ($rows as &$r) {
            $r['espera_promedio'] = seconds_to_hms($r['espera_promedio_seg']);
            $r['espera_maxima'] = seconds_to_hms($r['espera_maxima_seg']);
        }
        return $rows;
    }

    public function getNotAnsweredCalls($from, $to, $agentId = null, $limit = 20000)
    {
        $rows = array();
        $params = array(':from'=>$from, ':to'=>$to);
        $agentSql = $this->agentFilter('ce', $agentId, $params);
        $sql = "SELECT ce.datetime_entry_queue fecha, 'Abandonada en cola' fuente, COALESCE(a.number,'') agente, COALESCE(a.name,'Sin agente') nombre, COALESCE(au.login_extension,'') extension_login, ce.callerid numero, 'Entrante cola' tipo_llamada, ce.status estado, IFNULL(ce.duration_wait,0) espera_seg, 0 duracion_seg, q.queue cola, camp.name campania, ce.uniqueid FROM {$this->ccCallEntry} ce LEFT JOIN {$this->ccAgent} a ON a.id=ce.id_agent LEFT JOIN {$this->ccAudit} au ON au.id_agent=ce.id_agent AND au.id_break IS NULL AND ce.datetime_entry_queue BETWEEN au.datetime_init AND COALESCE(au.datetime_end, NOW()) LEFT JOIN {$this->ccQueue} q ON q.id=ce.id_queue_call_entry LEFT JOIN {$this->ccCampaignEntry} camp ON camp.id=ce.id_campaign WHERE ce.datetime_entry_queue >= :from AND ce.datetime_entry_queue < :to {$agentSql} AND (ce.id_agent IS NULL OR ce.status LIKE '%abandon%' OR ce.status LIKE '%ABANDON%' OR ce.status LIKE '%Abandon%') ORDER BY ce.datetime_entry_queue DESC LIMIT " . (int)$limit;
        $rows = array_merge($rows, DB::fetchAll($sql, $params));

        $params = array(':from'=>$from, ':to'=>$to);
        $agentSql = $this->agentFilter('c', $agentId, $params);
        $sql = "SELECT COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue) fecha, 'No contestada campaña' fuente, a.number agente, a.name nombre, COALESCE(au.login_extension,'') extension_login, c.phone numero, 'Saliente campaña' tipo_llamada, c.status estado, IFNULL(c.duration_wait,0) espera_seg, IFNULL(c.duration,0) duracion_seg, '' cola, camp.name campania, c.uniqueid FROM {$this->ccCalls} c LEFT JOIN {$this->ccAgent} a ON a.id=c.id_agent LEFT JOIN {$this->ccCampaign} camp ON camp.id=c.id_campaign LEFT JOIN {$this->ccAudit} au ON au.id_agent=c.id_agent AND au.id_break IS NULL AND COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue) BETWEEN au.datetime_init AND COALESCE(au.datetime_end, NOW()) WHERE COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue) >= :from AND COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue) < :to {$agentSql} AND NOT {$this->answeredOutgoingCondition('c')} ORDER BY fecha DESC LIMIT " . (int)$limit;
        $rows = array_merge($rows, DB::fetchAll($sql, $params));

        $params = array(':from'=>$from, ':to'=>$to);
        $agentSql = $this->cdrAgentFilter($agentId, $params);
        $sql = "SELECT cd.calldate fecha, 'Manual no atendida' fuente, a.number agente, a.name nombre, COALESCE(au.login_extension,'') extension_login, cd.dst numero, 'Manual saliente' tipo_llamada, cd.disposition estado, 0 espera_seg, cd.duration duracion_seg, '' cola, 'Manual desde extensión' campania, cd.uniqueid FROM {$this->cdr} cd INNER JOIN {$this->ccAgent} a ON (a.number = cd.src OR cd.channel LIKE CONCAT('PJSIP/', a.number, '-%') OR cd.channel LIKE CONCAT('SIP/', a.number, '-%') OR cd.channel LIKE CONCAT('IAX2/', a.number, '-%')) LEFT JOIN {$this->ccAudit} au ON au.id_agent=a.id AND au.id_break IS NULL AND cd.calldate BETWEEN au.datetime_init AND COALESCE(au.datetime_end, NOW()) WHERE cd.calldate >= :from AND cd.calldate < :to {$agentSql} AND (cd.disposition <> 'ANSWERED' OR cd.billsec = 0) AND cd.dst NOT IN (SELECT number FROM {$this->ccAgent}) AND NOT EXISTS (SELECT 1 FROM {$this->ccCalls} c WHERE c.uniqueid IS NOT NULL AND c.uniqueid <> '' AND (c.uniqueid = cd.uniqueid OR c.uniqueid = cd.linkedid)) AND NOT EXISTS (SELECT 1 FROM {$this->ccCallEntry} ce WHERE ce.uniqueid IS NOT NULL AND ce.uniqueid <> '' AND (ce.uniqueid = cd.uniqueid OR ce.uniqueid = cd.linkedid)) ORDER BY cd.calldate DESC LIMIT " . (int)$limit;
        $rows = array_merge($rows, DB::fetchAll($sql, $params));

        usort($rows, function($a, $b) { return strcmp($b['fecha'], $a['fecha']); });
        if (count($rows) > $limit) $rows = array_slice($rows, 0, $limit);
        foreach ($rows as &$r) {
            $r['espera'] = seconds_to_hms(isset($r['espera_seg']) ? $r['espera_seg'] : 0);
            $r['duracion'] = seconds_to_hms(isset($r['duracion_seg']) ? $r['duracion_seg'] : 0);
            $r['detalle'] = trim(($r['cola'] ? 'Cola: '.$r['cola'].' | ' : '') . ($r['campania'] ? 'Campaña: '.$r['campania'] : ''));
        }
        return $rows;
    }

    public function getAgentDailyDecision($from, $to, $agentId = null)
    {
        $days = array();
        $start = new DateTime(substr($from, 0, 10) . ' 00:00:00');
        $end = new DateTime(substr($to, 0, 10) . ' 00:00:00');
        if ($end->format('Y-m-d H:i:s') < $to) $end->modify('+1 day');
        $agents = $this->getAgents();
        foreach ($agents as $a) {
            if ($agentId !== null && (int)$a['id'] !== (int)$agentId) continue;
            $cursor = clone $start;
            while ($cursor < $end) {
                $dFrom = $cursor->format('Y-m-d 00:00:00');
                $dToObj = clone $cursor;
                $dToObj->modify('+1 day');
                $dTo = $dToObj->format('Y-m-d 00:00:00');
                $s = $this->getSummary($dFrom, $dTo, (int)$a['id'], false);
                $extra = $this->getAgentDecisionExtra($dFrom, $dTo, (int)$a['id']);
                $totalRec = $s['incoming'] + $s['manual_incoming'];
                $totalOut = $s['outgoing_campaign'] + $s['manual_outgoing'];
                $totalCalls = $totalRec + $totalOut;
                $retStats = $this->getReturnedCallbackStatsByAgent($dFrom, $dTo, (int)$a['id']);
                $ret = isset($retStats[(int)$a['id']]) ? $retStats[(int)$a['id']] : array('total'=>0, 'manual'=>0, 'campania'=>0);
                $returned = (int)$ret['total'];
                $pendingAbandoned = max(0, (int)$s['abandoned'] - $returned);
                $noAnsweredNet = (int)$extra['no_atendidas'] + $pendingAbandoned;
                $answeredAdjusted = min($totalCalls, (int)$extra['respondidas'] + $returned);
                $days[] = array(
                    'fecha'=>$cursor->format('Y-m-d'),
                    'agente'=>$a['number'],
                    'nombre'=>$a['name'],
                    'tipo'=>$a['type'],
                    'recibidas'=>$totalRec,
                    'realizadas'=>$totalOut,
                    'salientes_no_devolucion'=>max(0, $totalOut - $returned),
                    'manuales'=>$s['manual_incoming'] + $s['manual_outgoing'],
                    'manuales_gestion'=>max(0, (int)$s['manual_outgoing'] - (int)$ret['manual']),
                    'total_llamadas'=>$totalCalls,
                    'respondidas'=>$extra['respondidas'],
                    'devueltas'=>$returned,
                    'no_atendidas'=>$noAnsweredNet,
                    'no_atendidas_brutas'=>((int)$extra['no_atendidas'] + (int)$s['abandoned']),
                    'abandonadas_pendientes'=>$pendingAbandoned,
                    'efectividad_pct'=>$this->pct($extra['respondidas'], $totalCalls),
                    'efectividad_ajustada_pct'=>$this->pct($answeredAdjusted, $totalCalls),
                    'nivel_servicio_pct'=>$this->pct($extra['dentro_sla'], $extra['ofrecidas_cola']),
                    'sla_meta_pct'=>number_format($this->slaTargetPct(), 2, '.', '') . '%',
                    'cumple_sla'=>$this->pctNum($extra['dentro_sla'], $extra['ofrecidas_cola']) >= $this->slaTargetPct() ? 'CUMPLE' : 'NO CUMPLE',
                    'sla_objetivo'=>report_sla_policy_label(),
                    'pausas'=>$s['pause_count'],
                    'tiempo_pausa'=>seconds_to_hms($s['pause_seconds']),
                    'tiempo_logueo'=>seconds_to_hms($s['session_seconds']),
                    'tiempo_hablado'=>seconds_to_hms($s['talk_seconds']),
                    'formularios'=>$s['forms_count']
                );
                $cursor->modify('+1 day');
            }
        }
        usort($days, function($a, $b) { $c = strcmp($b['fecha'], $a['fecha']); return $c !== 0 ? $c : strcmp($a['agente'], $b['agente']); });
        return $days;
    }

    private function guardNumberVariants($phone)
    {
        $digits = preg_replace('/\D+/', '', (string)$phone);
        $variants = phone_variants($digits);
        $add = function($v) use (&$variants) {
            $v = preg_replace('/\D+/', '', (string)$v);
            if ($v !== '' && !in_array($v, $variants, true)) $variants[] = $v;
        };
        if ($digits !== '') $add($digits);
        if (strlen($digits) === 10 && substr($digits, 0, 1) === '0') {
            $add(substr($digits, 1));
            $add('595' . substr($digits, 1));
        }
        if (strlen($digits) === 9 && substr($digits, 0, 1) !== '0') {
            $add('0' . $digits);
            $add('595' . $digits);
        }
        if (strlen($digits) > 8) $add(substr($digits, -8));
        return array_values(array_filter($variants));
    }

    private function getGuardNumberFromInput($guardNumber)
    {
        $guardNumber = trim((string)$guardNumber);
        if ($guardNumber === '') $guardNumber = (string)app_config('after_hours.guard_number', '');
        return $guardNumber;
    }

    private function classifyAfterHoursDate($date)
    {
        $ts = strtotime((string)$date);
        if (!$ts) return 'Fuera de horario';
        $dow = (int)date('N', $ts); // 1 lunes, 7 domingo
        $time = date('H:i:s', $ts);
        $businessDays = app_config('after_hours.business_days', array(1,2,3,4,5));
        $start = app_config('after_hours.start_time', '06:00:00');
        $end = app_config('after_hours.end_time', '20:00:00');
        if (!in_array($dow, $businessDays, true)) return 'Fin de semana';
        if ($time < $start) return 'Antes de apertura';
        if ($time >= $end) return 'Después del cierre';
        return 'Dentro de horario';
    }

    public function getAfterHoursGuardCalls($from, $to, $guardNumber = '', $limit = 30000)
    {
        $guardNumber = $this->getGuardNumberFromInput($guardNumber);
        $variants = $this->guardNumberVariants($guardNumber);
        if (empty($variants)) return array();

        $params = array(
            ':from' => $from,
            ':to' => $to,
            ':start_time' => app_config('after_hours.start_time', '06:00:00'),
            ':end_time' => app_config('after_hours.end_time', '20:00:00'),
        );

        $matchParts = array();
        foreach ($variants as $i => $v) {
            $exact = ':guard_exact_' . $i;
            $like = ':guard_like_' . $i;
            $params[$exact] = $v;
            $params[$like] = '%' . $v . '%';
            $matchParts[] = "REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cd.dst,'+',''),'-',''),' ',''),'(',''),')','') = {$exact}";
            $matchParts[] = "REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cd.lastdata,'+',''),'-',''),' ',''),'(',''),')','') LIKE {$like}";
            $matchParts[] = "REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cd.dstchannel,'+',''),'-',''),' ',''),'(',''),')','') LIKE {$like}";
            $matchParts[] = "REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cd.userfield,'+',''),'-',''),' ',''),'(',''),')','') LIKE {$like}";
        }

        $sql = "SELECT cd.calldate AS fecha, cd.clid, cd.src, cd.cnum, cd.cnam, cd.dst, cd.dcontext, cd.channel, cd.dstchannel, cd.lastapp, cd.lastdata, cd.duration, cd.billsec, cd.disposition, cd.uniqueid, cd.linkedid, cd.did, cd.recordingfile, cd.sequence, cd.userfield
                FROM {$this->cdr} cd
                WHERE cd.calldate >= :from
                  AND cd.calldate < :to
                  AND (
                        DAYOFWEEK(cd.calldate) IN (1,7)
                        OR TIME(cd.calldate) < :start_time
                        OR TIME(cd.calldate) >= :end_time
                  )
                  AND (" . implode(' OR ', $matchParts) . ")
                ORDER BY cd.calldate DESC
                LIMIT " . (int)$limit;

        $raw = DB::fetchAll($sql, $params);
        $dedup = array();
        foreach ($raw as $r) {
            $key = trim((string)$r['linkedid']);
            if ($key === '') $key = trim((string)$r['uniqueid']);
            if ($key === '') $key = $r['fecha'] . '|' . $r['src'] . '|' . $r['dst'] . '|' . $r['sequence'];

            if (!isset($dedup[$key])) {
                $caller = trim((string)$r['cnum']);
                if ($caller === '') $caller = trim((string)$r['src']);
                $callerNorm = normalize_phone($caller);
                $guardNorm = normalize_phone($guardNumber);
                $dedup[$key] = array(
                    'fecha' => $r['fecha'],
                    'hora' => date('H:00', strtotime($r['fecha'])),
                    'dia_semana' => ucfirst(strftime('%A', strtotime($r['fecha']))),
                    'tipo_fuera_horario' => $this->classifyAfterHoursDate($r['fecha']),
                    'numero_llamante' => $callerNorm !== '' ? $callerNorm : $caller,
                    'numero_llamante_original' => $caller,
                    'numero_guardia' => $guardNorm !== '' ? $guardNorm : $guardNumber,
                    'numero_guardia_configurado' => $guardNumber,
                    'destino_cdr' => $r['dst'],
                    'did' => $r['did'],
                    'estado' => $r['disposition'],
                    'duracion_seg' => (int)$r['duration'],
                    'hablado_seg' => (int)$r['billsec'],
                    'duracion' => seconds_to_hms($r['duration']),
                    'hablado' => seconds_to_hms($r['billsec']),
                    'channel' => $r['channel'],
                    'dstchannel' => $r['dstchannel'],
                    'lastapp' => $r['lastapp'],
                    'lastdata' => $r['lastdata'],
                    'dcontext' => $r['dcontext'],
                    'uniqueid' => $r['uniqueid'],
                    'linkedid' => $r['linkedid'],
                    'recordingfile' => $r['recordingfile'],
                    'tramos' => 1,
                    'recorrido' => trim($r['src'] . ' -> ' . $r['dst'] . ' | ' . $r['lastapp'] . ' ' . $r['lastdata']),
                );
            } else {
                $dedup[$key]['tramos']++;
                if ($dedup[$key]['recordingfile'] === '' && $r['recordingfile'] !== '') $dedup[$key]['recordingfile'] = $r['recordingfile'];
                $dedup[$key]['duracion_seg'] = max((int)$dedup[$key]['duracion_seg'], (int)$r['duration']);
                $dedup[$key]['hablado_seg'] = max((int)$dedup[$key]['hablado_seg'], (int)$r['billsec']);
                $dedup[$key]['duracion'] = seconds_to_hms($dedup[$key]['duracion_seg']);
                $dedup[$key]['hablado'] = seconds_to_hms($dedup[$key]['hablado_seg']);
                if (strpos((string)$dedup[$key]['recorrido'], (string)$r['uniqueid']) === false) {
                    $dedup[$key]['recorrido'] .= ' / ' . trim($r['src'] . ' -> ' . $r['dst'] . ' | ' . $r['lastapp'] . ' ' . $r['lastdata']);
                }
            }
        }

        $rows = array_values($dedup);
        usort($rows, function($a, $b) { return strcmp($b['fecha'], $a['fecha']); });
        return $rows;
    }

    public function getAfterHoursGuardHourly($from, $to, $guardNumber = '')
    {
        $rows = $this->getAfterHoursGuardCalls($from, $to, $guardNumber, (int)app_config('app.max_export_rows', 30000));
        $hours = array();
        for ($i = 0; $i < 24; $i++) {
            $h = str_pad((string)$i, 2, '0', STR_PAD_LEFT) . ':00';
            $hours[$h] = array('hora' => $h, 'llamadas' => 0, 'contestadas_guardia' => 0, 'no_contestadas' => 0, 'duracion_seg' => 0, 'hablado_seg' => 0);
        }
        foreach ($rows as $r) {
            $h = isset($r['hora']) ? $r['hora'] : date('H:00', strtotime($r['fecha']));
            if (!isset($hours[$h])) $hours[$h] = array('hora'=>$h, 'llamadas'=>0, 'contestadas_guardia'=>0, 'no_contestadas'=>0, 'duracion_seg'=>0, 'hablado_seg'=>0);
            $hours[$h]['llamadas']++;
            if (strtoupper((string)$r['estado']) === 'ANSWERED' || (int)$r['hablado_seg'] > 0) $hours[$h]['contestadas_guardia']++;
            else $hours[$h]['no_contestadas']++;
            $hours[$h]['duracion_seg'] += (int)$r['duracion_seg'];
            $hours[$h]['hablado_seg'] += (int)$r['hablado_seg'];
        }
        foreach ($hours as &$h) {
            $h['duracion'] = seconds_to_hms($h['duracion_seg']);
            $h['hablado'] = seconds_to_hms($h['hablado_seg']);
        }
        return array_values($hours);
    }



    private function outboundAnsweredCondition($alias)
    {
        return "(({$alias}.duration IS NOT NULL AND {$alias}.duration > 0) OR {$alias}.status LIKE '%ANSWER%' OR {$alias}.status LIKE '%Success%' OR {$alias}.status LIKE '%success%' OR {$alias}.status LIKE '%Completed%' OR {$alias}.status LIKE '%complete%')";
    }

    private function outboundEffectiveCondition($alias)
    {
        return "({$this->outboundAnsweredCondition($alias)} AND {$alias}.id_agent IS NOT NULL AND IFNULL({$alias}.duration,0) > 0)";
    }

    public function getOutboundCampaignList($from = null, $to = null)
    {
        $params = array();
        $where = '';
        if ($from !== null && $to !== null) {
            $params = array(':from'=>$from, ':to'=>$to);
            $where = " WHERE EXISTS (SELECT 1 FROM {$this->ccCalls} c WHERE c.id_campaign = ca.id AND COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue) >= :from AND COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue) < :to) ";
        }
        $sql = "SELECT ca.id, ca.name, ca.estatus, ca.queue, ca.trunk, ca.max_canales FROM {$this->ccCampaign} ca {$where} ORDER BY ca.name";
        return DB::fetchAll($sql, $params);
    }

    private function outboundCampaignFilter($campaignId, &$params, $alias = 'c')
    {
        if ($campaignId !== null && $campaignId !== '') {
            $params[':campaign_id'] = (int)$campaignId;
            return " AND {$alias}.id_campaign = :campaign_id ";
        }
        return '';
    }

    public function getOutboundCampaignSummary($from, $to, $agentId = null, $campaignId = null)
    {
        $params = array(':from'=>$from, ':to'=>$to);
        $agentSql = $this->agentFilter('c', $agentId, $params);
        $campaignSql = $this->outboundCampaignFilter($campaignId, $params, 'c');
        $answered = $this->outboundAnsweredCondition('c');
        $effective = $this->outboundEffectiveCondition('c');
        $dateExpr = "COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue)";

        $sql = "
            SELECT
                ca.id AS id_campaign,
                ca.name AS campania,
                ca.estatus AS estado_campania,
                ca.queue AS cola,
                ca.trunk AS troncal_campania,
                ca.max_canales,
                ca.retries AS reintentos_configurados,
                COUNT(c.id) AS registros,
                COUNT(DISTINCT c.phone) AS numeros_unicos,
                SUM(CASE WHEN {$effective} THEN 1 ELSE 0 END) AS efectivas,
                SUM(CASE WHEN {$answered} THEN 1 ELSE 0 END) AS atendidas,
                SUM(CASE WHEN NOT ({$answered}) THEN 1 ELSE 0 END) AS no_atendidas_registros,
                SUM(CASE WHEN c.id_agent IS NOT NULL THEN 1 ELSE 0 END) AS conectadas_agente,
                SUM(CASE WHEN c.id_agent IS NULL THEN 1 ELSE 0 END) AS sin_agente,
                SUM(CASE WHEN c.transfer IS NOT NULL AND c.transfer <> '' THEN 1 ELSE 0 END) AS transferidas,
                SUM(CASE WHEN IFNULL(c.scheduled,0) = 1 THEN 1 ELSE 0 END) AS agendadas,
                SUM(CASE WHEN IFNULL(c.dnc,0) = 1 THEN 1 ELSE 0 END) AS dnc,
                SUM(IFNULL(c.duration,0)) AS hablado_seg,
                AVG(NULLIF(c.duration,0)) AS hablado_promedio_seg,
                SUM(IFNULL(c.duration_wait,0)) AS espera_seg,
                AVG(NULLIF(c.duration_wait,0)) AS espera_promedio_seg,
                SUM(IFNULL(c.retries,0)) AS reintentos_usados,
                MIN({$dateExpr}) AS primera_marcacion,
                MAX({$dateExpr}) AS ultima_marcacion,
                SUM(CASE WHEN IFNULL(pl.marcaciones_log,0) > 0 THEN pl.marcaciones_log ELSE GREATEST(IFNULL(c.retries,0)+1,1) END) AS marcaciones_dialer,
                SUM(CASE WHEN IFNULL(pl.no_answer_log,0) > 0 THEN pl.no_answer_log ELSE 0 END) AS no_answer_log,
                SUM(CASE WHEN IFNULL(pl.answer_log,0) > 0 THEN pl.answer_log ELSE 0 END) AS answer_log,
                SUM(CASE WHEN IFNULL(pl.busy_log,0) > 0 THEN pl.busy_log ELSE 0 END) AS busy_log,
                SUM(CASE WHEN IFNULL(pl.failed_log,0) > 0 THEN pl.failed_log ELSE 0 END) AS failed_log
            FROM {$this->ccCalls} c
            LEFT JOIN {$this->ccCampaign} ca ON ca.id = c.id_campaign
            LEFT JOIN (
                SELECT
                    id_call_outgoing,
                    COUNT(*) AS marcaciones_log,
                    SUM(CASE WHEN UPPER(new_status) LIKE '%ANSWER%' OR UPPER(new_status) LIKE '%SUCCESS%' OR UPPER(new_status) LIKE '%COMPLETE%' THEN 1 ELSE 0 END) AS answer_log,
                    SUM(CASE WHEN UPPER(new_status) LIKE '%NO ANSWER%' OR UPPER(new_status) LIKE '%NOANSWER%' OR UPPER(new_status) LIKE '%NO_ANSWER%' THEN 1 ELSE 0 END) AS no_answer_log,
                    SUM(CASE WHEN UPPER(new_status) LIKE '%BUSY%' THEN 1 ELSE 0 END) AS busy_log,
                    SUM(CASE WHEN UPPER(new_status) LIKE '%FAIL%' OR UPPER(new_status) LIKE '%ERROR%' OR UPPER(new_status) LIKE '%CONGESTION%' THEN 1 ELSE 0 END) AS failed_log
                FROM {$this->ccProgress}
                WHERE id_call_outgoing IS NOT NULL
                GROUP BY id_call_outgoing
            ) pl ON pl.id_call_outgoing = c.id
            WHERE {$dateExpr} >= :from AND {$dateExpr} < :to {$agentSql} {$campaignSql}
            GROUP BY ca.id, ca.name, ca.estatus, ca.queue, ca.trunk, ca.max_canales, ca.retries
            ORDER BY registros DESC, campania
        ";
        $rows = DB::fetchAll($sql, $params);
        foreach ($rows as &$r) {
            $registros = (int)$r['registros'];
            $marcaciones = (int)$r['marcaciones_dialer'];
            $atendidas = (int)$r['atendidas'];
            $efectivas = (int)$r['efectivas'];
            $noAtendidas = max(0, $marcaciones - $atendidas);
            $r['campania'] = $r['campania'] !== null && $r['campania'] !== '' ? $r['campania'] : 'Sin campaña';
            $r['marcaciones_dialer'] = $marcaciones;
            $r['no_atendidas'] = $noAtendidas;
            $r['tasa_atencion_pct'] = $this->pct($atendidas, $marcaciones > 0 ? $marcaciones : $registros);
            $r['tasa_efectividad_pct'] = $this->pct($efectivas, $marcaciones > 0 ? $marcaciones : $registros);
            $r['tasa_no_atendida_pct'] = $this->pct($noAtendidas, $marcaciones > 0 ? $marcaciones : $registros);
            $r['hablado'] = seconds_to_hms($r['hablado_seg']);
            $r['hablado_promedio'] = seconds_to_hms($r['hablado_promedio_seg']);
            $r['espera'] = seconds_to_hms($r['espera_seg']);
            $r['espera_promedio'] = seconds_to_hms($r['espera_promedio_seg']);
            $r['primera_marcacion'] = $r['primera_marcacion'] ? $r['primera_marcacion'] : '';
            $r['ultima_marcacion'] = $r['ultima_marcacion'] ? $r['ultima_marcacion'] : '';
        }
        unset($r);
        return $rows;
    }

    public function getOutboundCampaignDetails($from, $to, $agentId = null, $campaignId = null, $limit = 30000)
    {
        $params = array(':from'=>$from, ':to'=>$to);
        $agentSql = $this->agentFilter('c', $agentId, $params);
        $campaignSql = $this->outboundCampaignFilter($campaignId, $params, 'c');
        $answered = $this->outboundAnsweredCondition('c');
        $effective = $this->outboundEffectiveCondition('c');
        $dateExpr = "COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue)";
        $limit = max(1, (int)$limit);
        $sql = "
            SELECT
                c.id,
                c.id_campaign,
                ca.name AS campania,
                ca.queue AS cola,
                ca.trunk AS troncal_campania,
                c.phone,
                {$dateExpr} AS fecha,
                c.start_time,
                c.end_time,
                c.status,
                c.id_agent,
                a.number AS agente,
                a.name AS nombre,
                a.type AS tipo_agente,
                c.duration,
                c.duration_wait,
                c.retries,
                c.transfer,
                c.failure_cause,
                c.failure_cause_txt,
                c.datetime_originate,
                c.datetime_entry_queue,
                c.trunk,
                c.scheduled,
                c.dnc,
                c.uniqueid,
                cr.recordingfile,
                IFNULL(pl.marcaciones_log,0) AS marcaciones_log,
                pl.estados_log,
                pl.ultimo_estado_log,
                pl.ultimo_log
            FROM {$this->ccCalls} c
            LEFT JOIN {$this->ccCampaign} ca ON ca.id = c.id_campaign
            LEFT JOIN {$this->ccAgent} a ON a.id = c.id_agent
            LEFT JOIN (
                SELECT id_call_outgoing, MAX(recordingfile) AS recordingfile
                FROM {$this->ccRecording}
                WHERE id_call_outgoing IS NOT NULL
                GROUP BY id_call_outgoing
            ) cr ON cr.id_call_outgoing = c.id
            LEFT JOIN (
                SELECT
                    id_call_outgoing,
                    COUNT(*) AS marcaciones_log,
                    GROUP_CONCAT(CONCAT(DATE_FORMAT(datetime_entry, '%d/%m/%Y %H:%i:%s'), ' ', new_status) ORDER BY datetime_entry SEPARATOR ' | ') AS estados_log,
                    SUBSTRING_INDEX(GROUP_CONCAT(new_status ORDER BY datetime_entry DESC SEPARATOR '||'), '||', 1) AS ultimo_estado_log,
                    MAX(datetime_entry) AS ultimo_log
                FROM {$this->ccProgress}
                WHERE id_call_outgoing IS NOT NULL
                GROUP BY id_call_outgoing
            ) pl ON pl.id_call_outgoing = c.id
            WHERE {$dateExpr} >= :from AND {$dateExpr} < :to {$agentSql} {$campaignSql}
            ORDER BY fecha DESC, c.id DESC
            LIMIT {$limit}
        ";
        $rows = DB::fetchAll($sql, $params);
        foreach ($rows as &$r) {
            $answeredBool = ((int)$r['duration'] > 0) || stripos((string)$r['status'], 'ANSWER') !== false || stripos((string)$r['status'], 'Success') !== false || stripos((string)$r['status'], 'complete') !== false;
            $effectiveBool = $answeredBool && (int)$r['id_agent'] > 0 && (int)$r['duration'] > 0;
            $r['numero'] = display_phone($r['phone']);
            $r['numero_original'] = $r['phone'];
            $r['campania'] = $r['campania'] !== null && $r['campania'] !== '' ? $r['campania'] : 'Sin campaña';
            $r['marcaciones_dialer'] = (int)$r['marcaciones_log'] > 0 ? (int)$r['marcaciones_log'] : max(1, (int)$r['retries'] + 1);
            $r['resultado_final'] = $effectiveBool ? 'EFECTIVA' : ($answeredBool ? 'ATENDIDA' : 'NO ATENDIDA');
            $r['efectiva'] = $effectiveBool ? 'Sí' : 'No';
            $r['atendida'] = $answeredBool ? 'Sí' : 'No';
            $r['no_atendida'] = $answeredBool ? 'No' : 'Sí';
            $r['estado'] = $r['status'] !== null && $r['status'] !== '' ? $r['status'] : ($r['ultimo_estado_log'] ? $r['ultimo_estado_log'] : 'Sin estado');
            $r['duracion'] = seconds_to_hms($r['duration']);
            $r['espera'] = seconds_to_hms($r['duration_wait']);
            $r['transferida'] = ($r['transfer'] !== null && $r['transfer'] !== '') ? 'Sí' : 'No';
            $r['agendada'] = ((int)$r['scheduled'] === 1) ? 'Sí' : 'No';
            $r['dnc_texto'] = ((int)$r['dnc'] === 1) ? 'Sí' : 'No';
            $r['agente'] = $r['agente'] ? $r['agente'] : '';
            $r['nombre'] = $r['nombre'] ? $r['nombre'] : '';
            $r['grabacion'] = $r['recordingfile'] ? $r['recordingfile'] : '';
        }
        unset($r);
        return $rows;
    }

    public function getOutboundCampaignByHour($from, $to, $agentId = null, $campaignId = null)
    {
        $rows = $this->getOutboundCampaignDetails($from, $to, $agentId, $campaignId, (int)app_config('app.max_export_rows', 30000));
        $hours = array();
        for ($i = 0; $i < 24; $i++) {
            $h = str_pad((string)$i, 2, '0', STR_PAD_LEFT) . ':00';
            $hours[$h] = array('hora'=>$h, 'marcaciones'=>0, 'efectivas'=>0, 'atendidas'=>0, 'no_atendidas'=>0, 'hablado_seg'=>0);
        }
        foreach ($rows as $r) {
            $ts = strtotime((string)$r['fecha']);
            $h = $ts ? date('H:00', $ts) : '00:00';
            if (!isset($hours[$h])) $hours[$h] = array('hora'=>$h, 'marcaciones'=>0, 'efectivas'=>0, 'atendidas'=>0, 'no_atendidas'=>0, 'hablado_seg'=>0);
            $hours[$h]['marcaciones'] += (int)$r['marcaciones_dialer'];
            if ($r['efectiva'] === 'Sí') $hours[$h]['efectivas']++;
            if ($r['atendida'] === 'Sí') $hours[$h]['atendidas']++;
            if ($r['no_atendida'] === 'Sí') $hours[$h]['no_atendidas']++;
            $hours[$h]['hablado_seg'] += isset($r['duration']) ? (int)$r['duration'] : 0;
        }
        foreach ($hours as &$h) {
            $h['tasa_efectividad_pct'] = $this->pct($h['efectivas'], $h['marcaciones']);
            $h['hablado'] = seconds_to_hms($h['hablado_seg']);
        }
        unset($h);
        return array_values($hours);
    }

    public function getOutboundCampaignStatusBreakdown($from, $to, $agentId = null, $campaignId = null)
    {
        $rows = $this->getOutboundCampaignDetails($from, $to, $agentId, $campaignId, (int)app_config('app.max_export_rows', 30000));
        $map = array();
        foreach ($rows as $r) {
            $k = trim((string)$r['estado']);
            if ($k === '') $k = 'Sin estado';
            if (!isset($map[$k])) $map[$k] = array('estado'=>$k, 'total'=>0, 'efectivas'=>0, 'atendidas'=>0, 'no_atendidas'=>0);
            $map[$k]['total']++;
            if ($r['efectiva'] === 'Sí') $map[$k]['efectivas']++;
            if ($r['atendida'] === 'Sí') $map[$k]['atendidas']++;
            if ($r['no_atendida'] === 'Sí') $map[$k]['no_atendidas']++;
        }
        usort($map, function($a,$b){ return (int)$b['total'] - (int)$a['total']; });
        return array_values($map);
    }

}
