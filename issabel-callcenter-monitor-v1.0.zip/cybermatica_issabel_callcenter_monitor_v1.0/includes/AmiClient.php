<?php
/**
 * Cliente AMI rápido para monitoreo operativo.
 * Optimización v10:
 * - Usa una sola acción AMI: CoreShowChannels.
 * - No ejecuta comandos pesados de CLI como pjsip show endpoints, sip show peers, iax2 show peers o queue show.
 * - Aplica cache corto para que varios navegadores no saturen AMI.
 * - El estado de login/pausa/campaña se toma desde BD; AMI solo complementa llamada/canal actual.
 */
class AmiClient
{
    private $host;
    private $port;
    private $username;
    private $secret;
    private $timeout;
    private $socket = null;
    private $lastError = '';

    public function __construct()
    {
        $cfg = app_config('ami', array());
        $this->host = isset($cfg['host']) ? $cfg['host'] : '127.0.0.1';
        $this->port = isset($cfg['port']) ? (int)$cfg['port'] : 5038;
        $this->username = isset($cfg['username']) ? $cfg['username'] : '';
        $this->secret = isset($cfg['secret']) ? $cfg['secret'] : '';
        $this->timeout = isset($cfg['timeout']) ? (float)$cfg['timeout'] : 2;
        if ($this->timeout <= 0) $this->timeout = 2;
    }

    public function lastError()
    {
        return $this->lastError;
    }

    private function cacheFile()
    {
        return dirname(__DIR__) . '/cache/ami_agents_snapshot.json';
    }

    private function readCache($maxAge)
    {
        $file = $this->cacheFile();
        if (!is_file($file)) return null;
        if ((time() - filemtime($file)) > $maxAge) return null;
        $raw = @file_get_contents($file);
        if ($raw === false || trim($raw) === '') return null;
        $data = json_decode($raw, true);
        return is_array($data) ? $data : null;
    }

    private function writeCache($data)
    {
        $dir = dirname($this->cacheFile());
        if (!is_dir($dir)) @mkdir($dir, 0755, true);
        if (!is_writable($dir)) return;
        @file_put_contents($this->cacheFile(), json_encode($data, JSON_UNESCAPED_UNICODE));
    }

    public function connect()
    {
        if (!app_config('ami.enabled', false)) {
            $this->lastError = 'AMI deshabilitado en config.php';
            return false;
        }
        $errno = 0;
        $errstr = '';
        $this->socket = @fsockopen($this->host, $this->port, $errno, $errstr, $this->timeout);
        if (!$this->socket) {
            $this->lastError = 'No se pudo conectar a AMI ' . $this->host . ':' . $this->port . ' - ' . $errstr;
            return false;
        }
        stream_set_timeout($this->socket, (int)ceil($this->timeout));
        $this->readPacket(); // banner
        $response = $this->sendAction(array(
            'Action' => 'Login',
            'Username' => $this->username,
            'Secret' => $this->secret,
            'Events' => 'off'
        ));
        if (stripos($response, 'Response: Success') === false) {
            $this->lastError = trim($response) !== '' ? trim($response) : 'AMI rechazó el login';
            $this->close();
            return false;
        }
        return true;
    }

    public function close()
    {
        if ($this->socket) {
            @fwrite($this->socket, "Action: Logoff\r\n\r\n");
            @fclose($this->socket);
            $this->socket = null;
        }
    }

    private function sendAction($pairs)
    {
        if (!$this->socket) return '';
        $payload = '';
        foreach ($pairs as $k => $v) {
            $payload .= $k . ': ' . $v . "\r\n";
        }
        $payload .= "\r\n";
        @fwrite($this->socket, $payload);
        return $this->readPacket(true);
    }

    private function readPacket($allowOutput = false)
    {
        if (!$this->socket) return '';
        $buffer = '';
        $started = microtime(true);
        while (!feof($this->socket)) {
            $line = fgets($this->socket, 4096);
            if ($line === false) break;
            $buffer .= $line;
            if (trim($line) === '') {
                if (!$allowOutput) break;
                if ((microtime(true) - $started) > $this->timeout) break;
                if (stripos($buffer, 'Response: Error') !== false) break;
                continue;
            }
            if ((microtime(true) - $started) > $this->timeout) break;
        }
        return $buffer;
    }

    private function sendActionReadUntil($pairs, $completeEvent)
    {
        if (!$this->socket) return '';
        $payload = '';
        foreach ($pairs as $k => $v) {
            $payload .= $k . ': ' . $v . "\r\n";
        }
        $payload .= "\r\n";
        @fwrite($this->socket, $payload);

        $buffer = '';
        $started = microtime(true);
        while (!feof($this->socket)) {
            $line = fgets($this->socket, 4096);
            if ($line === false) break;
            $buffer .= $line;
            if (stripos($buffer, 'Response: Error') !== false) break;
            if (stripos($buffer, 'Event: ' . $completeEvent) !== false) {
                // Leer el cierre del bloque completo.
                while (!feof($this->socket)) {
                    $l2 = fgets($this->socket, 4096);
                    if ($l2 === false) break;
                    $buffer .= $l2;
                    if (trim($l2) === '') break;
                }
                break;
            }
            if ((microtime(true) - $started) > $this->timeout) break;
        }
        return $buffer;
    }

    public function fastSnapshot()
    {
        if (!$this->connect()) {
            return array('connected' => false, 'error' => $this->lastError(), 'channels' => array(), 'summary' => array('total_channels'=>0));
        }
        $raw = $this->sendActionReadUntil(array(
            'Action' => 'CoreShowChannels',
            'ActionID' => 'ccpanel_' . time()
        ), 'CoreShowChannelsComplete');
        $this->close();
        if (stripos($raw, 'Response: Error') !== false) {
            return array('connected' => false, 'error' => trim($raw), 'channels' => array(), 'summary' => array('total_channels'=>0));
        }
        $channels = $this->parseCoreShowChannels($raw);
        return array(
            'connected' => true,
            'error' => '',
            'channels' => $channels,
            'summary' => $this->summarizeChannels($channels)
        );
    }

    /** Compatibilidad con versiones anteriores. */
    public function snapshot()
    {
        return $this->fastSnapshot();
    }

    public function cachedAgentOperationalSnapshot($runtimeMap)
    {
        $ttl = (int)app_config('ami.cache_ttl', 3);
        if ($ttl < 1) $ttl = 1;
        $cached = $this->readCache($ttl);
        if ($cached !== null) {
            $cached['cache_status'] = 'cache';
            return $cached;
        }
        $data = $this->agentOperationalSnapshot($runtimeMap);
        $data['cache_status'] = 'live';
        $this->writeCache($data);
        return $data;
    }

    public function agentOperationalSnapshot($runtimeMap)
    {
        $snapshot = $this->fastSnapshot();
        $agents = array_values($runtimeMap);

        if (!$snapshot['connected']) {
            $summary = $this->summarizeAgents($agents, 0);
            return array(
                'connected' => false,
                'error' => $snapshot['error'],
                'agents' => $agents,
                'summary' => $summary,
                'updated_at' => date('d/m/Y H:i:s'),
                'mode' => 'BD sin AMI'
            );
        }

        $byNumber = array();
        foreach ($agents as $i => $a) {
            if (isset($a['agente']) && $a['agente'] !== '') $byNumber[(string)$a['agente']] = $i;
            if (!empty($a['login_extension'])) $byNumber[(string)$a['login_extension']] = $i;
        }

        $bridgeGroups = $this->groupChannelsByBridge($snapshot['channels']);

        foreach ($snapshot['channels'] as $ch) {
            // Importante: para supervisión NO debemos asignar el canal de troncal al agente.
            // Antes se podía resolver por ConnectedLine/CallerID y terminar en ChanSpy(SIP/Trunk,...),
            // lo que impide susurro correcto. Solo tomamos el canal propio del endpoint del agente:
            // PJSIP/1001-..., SIP/1001-..., IAX2/1001-..., Agent/1001-... o Local/1001@...
            $ext = $this->agentExtensionFromOwnChannel(isset($ch['channel']) ? $ch['channel'] : '', $byNumber);
            if ($ext === '' || !isset($byNumber[$ext])) continue;
            $i = $byNumber[$ext];
            $state = strtoupper(isset($ch['state']) ? $ch['state'] : '');
            $agents[$i]['canal_actual'] = isset($ch['channel']) ? $ch['channel'] : '';
            $agents[$i]['canal_supervision'] = isset($ch['channel']) ? $ch['channel'] : '';
            $agents[$i]['uniqueid_actual'] = isset($ch['uniqueid']) ? $ch['uniqueid'] : '';
            $agents[$i]['linkedid_actual'] = isset($ch['linkedid']) ? $ch['linkedid'] : '';
            $number = $this->remoteNumberForAgentFromBridge($ch, $ext, $bridgeGroups);
            if ($number === '') $number = $this->remoteNumberForAgent($ch, $ext);
            if ($number !== '') $agents[$i]['numero_actual'] = $number;
            if (!empty($ch['duration'])) $agents[$i]['duracion_llamada_actual'] = $this->normalizeDuration($ch['duration']);
            if (!empty($ch['duration_seconds'])) $agents[$i]['duracion_llamada_actual_seg'] = (int)$ch['duration_seconds'];
            if (strpos($state, 'RING') !== false) {
                $agents[$i]['estado_operativo'] = 'Timbrando';
                $agents[$i]['estado_css'] = 'info';
                $agents[$i]['llamada_actual'] = 'Sí';
                $agents[$i]['tipo_llamada_actual'] = 'Canal del agente';
            } elseif ($state === 'UP' || !empty($ch['bridgeid'])) {
                $agents[$i]['estado_operativo'] = 'En llamada';
                $agents[$i]['estado_css'] = 'primary';
                $agents[$i]['llamada_actual'] = 'Sí';
                $agents[$i]['tipo_llamada_actual'] = 'Canal del agente';
            } elseif (isset($agents[$i]['estado_operativo']) && $agents[$i]['estado_operativo'] === 'Desconectado') {
                $agents[$i]['estado_operativo'] = 'Con actividad';
                $agents[$i]['estado_css'] = 'info';
            }
        }

        $summary = $this->summarizeAgents($agents, count($snapshot['channels']));
        return array(
            'connected' => true,
            'error' => '',
            'agents' => $agents,
            'summary' => $summary,
            'updated_at' => date('d/m/Y H:i:s'),
            'mode' => 'AMI rápido + BD'
        );
    }

    private function summarizeAgents($agents, $channelCount)
    {
        $summary = array(
            'total' => count($agents),
            'logueados' => 0,
            'disponibles' => 0,
            'en_pausa' => 0,
            'en_llamada' => 0,
            'timbrando' => 0,
            'desconectados' => 0,
            'canales_activos' => (int)$channelCount
        );
        foreach ($agents as $a) {
            if (isset($a['logueado']) && $a['logueado'] === 'Sí') $summary['logueados']++;
            if (isset($a['en_pausa']) && $a['en_pausa'] === 'Sí') $summary['en_pausa']++;
            if (isset($a['estado_operativo']) && $a['estado_operativo'] === 'En llamada') $summary['en_llamada']++;
            elseif (isset($a['estado_operativo']) && $a['estado_operativo'] === 'Timbrando') $summary['timbrando']++;
            elseif (isset($a['estado_operativo']) && $a['estado_operativo'] === 'Disponible') $summary['disponibles']++;
            elseif (isset($a['estado_operativo']) && $a['estado_operativo'] === 'Desconectado') $summary['desconectados']++;
        }
        return $summary;
    }

    private function parseCoreShowChannels($raw)
    {
        $events = preg_split('/\r?\n\r?\n/', trim($raw));
        $rows = array();
        foreach ($events as $event) {
            if (stripos($event, 'Event: CoreShowChannel') === false) continue;
            if (stripos($event, 'Event: CoreShowChannelsComplete') !== false) continue;
            $data = array();
            foreach (preg_split('/\r?\n/', $event) as $line) {
                $pos = strpos($line, ':');
                if ($pos === false) continue;
                $key = strtolower(trim(substr($line, 0, $pos)));
                $val = trim(substr($line, $pos + 1));
                $data[$key] = $val;
            }
            $duration = isset($data['duration']) ? $data['duration'] : '';
            $rows[] = array(
                'channel' => isset($data['channel']) ? $data['channel'] : '',
                'state' => isset($data['channelstatedesc']) ? $data['channelstatedesc'] : (isset($data['state']) ? $data['state'] : ''),
                'callerid' => isset($data['calleridnum']) ? $data['calleridnum'] : '',
                'calleridname' => isset($data['calleridname']) ? $data['calleridname'] : '',
                'connectedline' => isset($data['connectedlinenum']) ? $data['connectedlinenum'] : '',
                'connectedlinename' => isset($data['connectedlinename']) ? $data['connectedlinename'] : '',
                'context' => isset($data['context']) ? $data['context'] : '',
                'extension' => isset($data['exten']) ? $data['exten'] : '',
                'application' => isset($data['application']) ? $data['application'] : '',
                'applicationdata' => isset($data['applicationdata']) ? $data['applicationdata'] : '',
                'duration' => $this->normalizeDuration($duration),
                'duration_seconds' => $this->durationToSeconds($duration),
                'bridgeid' => isset($data['bridgeid']) ? $data['bridgeid'] : '',
                'uniqueid' => isset($data['uniqueid']) ? $data['uniqueid'] : '',
                'linkedid' => isset($data['linkedid']) ? $data['linkedid'] : '',
            );
        }
        return $rows;
    }

    private function groupChannelsByBridge($channels)
    {
        $groups = array();
        foreach ($channels as $ch) {
            $bridge = isset($ch['bridgeid']) ? trim((string)$ch['bridgeid']) : '';
            if ($bridge === '') continue;
            if (!isset($groups[$bridge])) $groups[$bridge] = array();
            $groups[$bridge][] = $ch;
        }
        return $groups;
    }

    private function agentExtensionFromOwnChannel($channel, $byNumber)
    {
        $channel = (string)$channel;
        $ext = $this->extensionFromChannel($channel);
        if ($ext !== '' && isset($byNumber[$ext])) return $ext;
        return '';
    }

    private function remoteNumberForAgentFromBridge($ch, $agentExt, $bridgeGroups)
    {
        $bridge = isset($ch['bridgeid']) ? trim((string)$ch['bridgeid']) : '';
        if ($bridge === '' || !isset($bridgeGroups[$bridge])) return '';
        $own = isset($ch['channel']) ? (string)$ch['channel'] : '';
        foreach ($bridgeGroups[$bridge] as $peer) {
            $peerChannel = isset($peer['channel']) ? (string)$peer['channel'] : '';
            if ($peerChannel === '' || $peerChannel === $own) continue;
            $values = array(
                isset($peer['callerid']) ? $peer['callerid'] : '',
                isset($peer['connectedline']) ? $peer['connectedline'] : '',
                isset($peer['extension']) ? $peer['extension'] : '',
                $this->extensionFromChannel($peerChannel)
            );
            foreach ($values as $v) {
                $digits = preg_replace('/\D+/', '', (string)$v);
                if ($digits !== '' && $digits !== (string)$agentExt) return $digits;
            }
        }
        return '';
    }

    private function resolveAgentExtensionFromChannel($ch, $byNumber)
    {
        $candidates = array();
        $candidates[] = $this->extensionFromChannel(isset($ch['channel']) ? $ch['channel'] : '');
        $candidates[] = isset($ch['callerid']) ? $ch['callerid'] : '';
        $candidates[] = isset($ch['connectedline']) ? $ch['connectedline'] : '';
        $candidates[] = isset($ch['extension']) ? $ch['extension'] : '';
        foreach ($candidates as $c) {
            $c = preg_replace('/\D+/', '', (string)$c);
            if ($c !== '' && isset($byNumber[$c])) return $c;
        }
        return '';
    }

    private function remoteNumberForAgent($ch, $agentExt)
    {
        $values = array(
            isset($ch['callerid']) ? $ch['callerid'] : '',
            isset($ch['connectedline']) ? $ch['connectedline'] : '',
            isset($ch['extension']) ? $ch['extension'] : '',
        );
        foreach ($values as $v) {
            $digits = preg_replace('/\D+/', '', (string)$v);
            if ($digits !== '' && $digits !== (string)$agentExt) return $digits;
        }
        return '';
    }

    private function normalizeDuration($value)
    {
        $value = trim((string)$value);
        if ($value === '') return '00:00:00';
        if (preg_match('/^\d+$/', $value)) return seconds_to_hms((int)$value);
        if (preg_match('/^\d{1,2}:\d{2}:\d{2}$/', $value)) return $value;
        return $value;
    }

    private function durationToSeconds($value)
    {
        $value = trim((string)$value);
        if ($value === '') return 0;
        if (preg_match('/^\d+$/', $value)) return (int)$value;
        if (preg_match('/^(\d{1,2}):(\d{2}):(\d{2})$/', $value, $m)) return ((int)$m[1] * 3600) + ((int)$m[2] * 60) + (int)$m[3];
        return 0;
    }

    private function extensionFromChannel($channel)
    {
        $channel = (string)$channel;
        if (preg_match('/^(PJSIP|SIP|IAX2)\/([^\-\s\/]+)/i', $channel, $m)) {
            $ext = $m[2];
            $ext = preg_replace('/@.*$/', '', $ext);
            return preg_replace('/\D+/', '', $ext);
        }
        if (preg_match('/Local\/([^@\-]+)/i', $channel, $m)) return preg_replace('/\D+/', '', $m[1]);
        if (preg_match('/Agent\/([^\-\s]+)/i', $channel, $m)) return preg_replace('/\D+/', '', $m[1]);
        return '';
    }

    private function summarizeChannels($rows)
    {
        $s = array('total_channels' => count($rows), 'up' => 0, 'ring' => 0, 'busy' => 0, 'pjsip' => 0, 'sip' => 0, 'iax2' => 0);
        foreach ($rows as $r) {
            $state = strtoupper(isset($r['state']) ? $r['state'] : '');
            if ($state === 'UP') $s['up']++;
            if (strpos($state, 'RING') !== false) $s['ring']++;
            if ($state === 'BUSY') $s['busy']++;
            if (stripos($r['channel'], 'PJSIP/') === 0) $s['pjsip']++;
            if (stripos($r['channel'], 'SIP/') === 0) $s['sip']++;
            if (stripos($r['channel'], 'IAX2/') === 0) $s['iax2']++;
        }
        return $s;
    }

    /**
     * Origina una llamada al supervisor y lo conecta a ChanSpy sobre el canal del agente.
     * Modos:
     * - listen: solo escucha.
     * - whisper: escucha y puede hablarle al agente, sin que el cliente lo oiga.
     * - barge: conferencia/barge, participa en ambos lados.
     */
    public function originateChanSpy($supervisorTech, $supervisorExtension, $targetPrefix, $mode, $label = '')
    {
        if (!app_config('supervision.enabled', false)) {
            return array('ok' => false, 'message' => 'El módulo de supervisión está deshabilitado en config.php.');
        }

        $supervisorTech = strtoupper(trim((string)$supervisorTech));
        $allowed = app_config('supervision.allowed_supervisor_techs', array('PJSIP','SIP','IAX2','LOCAL'));
        if (!in_array($supervisorTech, $allowed, true)) {
            return array('ok' => false, 'message' => 'Tecnología de extensión supervisora no permitida. Use PJSIP, SIP, IAX2 o LOCAL.');
        }
        $supervisorExtension = preg_replace('/[^0-9A-Za-z_\-]/', '', (string)$supervisorExtension);
        if ($supervisorExtension === '') {
            return array('ok' => false, 'message' => 'Debe indicar la extensión que escuchará.');
        }

        $targetPrefix = $this->sanitizeSpyTargetPrefix($targetPrefix);
        if ($targetPrefix === '') {
            return array('ok' => false, 'message' => 'No se pudo determinar el canal del agente a supervisar.');
        }

        $mode = strtolower(trim((string)$mode));
        $isExactChannel = $this->isFullyQualifiedChannel($targetPrefix);

        // v32: opciones estilo call center/VICIdial.
        // En instalaciones Issabel/Asterisk el método más compatible es usar ChanSpy
        // contra el prefijo del endpoint/agente, por ejemplo PJSIP/102 o SIP/102.
        // Se eliminan opciones agresivas como E/l/u por defecto, porque en algunas
        // instalaciones impiden escuchar/susurrar correctamente o hacen que Asterisk
        // enganche un canal de forma no esperada.
        $quietPrefix = (bool)app_config('supervision.quiet', true) ? 'q' : '';
        if ($mode === 'whisper') {
            $options = app_config('supervision.spy_options_whisper', $quietPrefix . 'dw');
            $modeLabel = 'Susurro';
        } elseif ($mode === 'barge') {
            $options = app_config('supervision.spy_options_barge', $quietPrefix . 'dB');
            $modeLabel = 'Barge / conferencia';
        } else {
            $options = app_config('supervision.spy_options_listen', $quietPrefix . 'd');
            $modeLabel = 'Solo escucha';
        }

        $options = preg_replace('/[^A-Za-z0-9()_,-]/', '', (string)$options);
        if ($options === '') $options = $quietPrefix;

        if ($supervisorTech === 'LOCAL') {
            $context = app_config('supervision.local_context', 'from-internal');
            $channel = 'Local/' . $supervisorExtension . '@' . $context;
        } else {
            $channel = $supervisorTech . '/' . $supervisorExtension;
        }
        $timeout = (int)app_config('supervision.originate_timeout_ms', 7000);
        // El Originate es asíncrono; no conviene dejar una espera larga en el panel.
        // Usamos mínimo razonable, pero no forzamos 12s como versiones anteriores.
        if ($timeout < 1000) $timeout = 3000;
        if ($timeout > 15000) $timeout = 15000;

        if (!$this->connect()) {
            return array('ok' => false, 'message' => $this->lastError());
        }
        $actionId = 'ccspy_' . date('YmdHis') . '_' . mt_rand(1000,9999);
        $raw = $this->sendAction(array(
            'Action' => 'Originate',
            'ActionID' => $actionId,
            'Channel' => $channel,
            'Application' => 'ChanSpy',
            'Data' => $targetPrefix . ',' . $options,
            'CallerID' => 'Supervisor ' . $supervisorExtension . ' <' . $supervisorExtension . '>',
            'Timeout' => $timeout,
            'Async' => 'true'
        ));
        $this->close();

        $ok = stripos($raw, 'Response: Success') !== false;
        $message = $ok
            ? 'Solicitud enviada a AMI. La extensión ' . $supervisorExtension . ' debe timbrar inmediatamente; al contestar entrará en modo ' . $modeLabel . '. Destino: ' . $targetPrefix . '.'
            : 'AMI no aceptó la solicitud: ' . trim($raw);

        $this->writeSupervisionAudit(array(
            'when' => date('Y-m-d H:i:s'),
            'supervisor_channel' => $channel,
            'target_prefix' => $targetPrefix,
            'mode' => $modeLabel,
            'label' => $label,
            'ok' => $ok ? 'yes' : 'no',
            'response' => preg_replace('/\s+/', ' ', trim($raw))
        ));

        return array('ok' => $ok, 'message' => $message, 'target' => $targetPrefix, 'supervisor' => $channel, 'mode' => $modeLabel, 'raw' => $raw);
    }

    /**
     * Devuelve un prefijo de supervisión por extensión, que es más estable que el canal exacto.
     * Ejemplo: PJSIP/102 en vez de PJSIP/102-0000c7a8.
     * Si la tecnología del agente no está clara, se infiere del canal actual.
     */
    public function spyTargetByExtension($channel, $fallbackTech = '', $fallbackExtension = '')
    {
        $tech = strtoupper(trim((string)$fallbackTech));
        $channel = trim((string)$channel);
        $fallbackExtension = trim((string)$fallbackExtension);

        if (preg_match('/^(PJSIP|SIP|IAX2|Agent|Local)\//i', $channel, $m)) {
            $tech = strtoupper($m[1]);
            if ($tech === 'AGENT') $tech = 'Agent';
            if ($tech === 'LOCAL') $tech = 'Local';
        }

        // Acepta errores comunes de formulario: PJSIP102, PJSIP/102, SIP102, IAX2102.
        $parsed = $this->parseEndpointInput($fallbackExtension, $tech);
        $tech = $parsed['tech'];
        $fallbackExtension = $parsed['extension'];

        if (!in_array($tech, array('PJSIP','SIP','IAX2','Agent','Local','LOCAL'), true)) {
            $tech = 'PJSIP';
        }
        if ($tech === 'LOCAL') $tech = 'Local';

        if ($fallbackExtension === '') {
            $fallbackExtension = $this->extensionFromChannel($channel);
        }

        if ($fallbackExtension === '') return '';
        if ($tech === 'Local') {
            $context = app_config('supervision.local_context', 'from-internal');
            return 'Local/' . $fallbackExtension . '@' . $context;
        }
        return $tech . '/' . $fallbackExtension;
    }

    /** Canal exacto para pruebas/diagnóstico: PJSIP/102-0000abcd. */
    public function spyTargetExactChannel($channel)
    {
        return $this->sanitizeSpyTargetPrefix($channel);
    }

    private function isFullyQualifiedChannel($value)
    {
        $value = trim((string)$value);
        return (bool)preg_match('/^(PJSIP|SIP|IAX2)\/[^\s,]+-[0-9a-f]+$/i', $value);
    }

    public function spyTargetPrefixFromChannel($channel, $fallbackTech = '', $fallbackExtension = '')
    {
        $prefix = $this->sanitizeSpyTargetPrefix($channel);
        if ($prefix !== '') return $prefix;
        $fallbackTech = strtoupper(trim((string)$fallbackTech));
        $fallbackExtension = preg_replace('/[^0-9A-Za-z_\-]/', '', (string)$fallbackExtension);
        if (in_array($fallbackTech, array('PJSIP','SIP','IAX2'), true) && $fallbackExtension !== '') {
            return $fallbackTech . '/' . $fallbackExtension;
        }
        if ($fallbackExtension !== '') {
            return 'PJSIP/' . $fallbackExtension;
        }
        return '';
    }

    private function sanitizeSpyTargetPrefix($value)
    {
        $value = trim((string)$value);
        if ($value === '') return '';
        if (preg_match('/^(PJSIP|SIP|IAX2)\/([^\s,]+)/i', $value, $m)) {
            $tech = strtoupper($m[1]);
            $rest = preg_replace('/@.*$/', '', $m[2]);
            $rest = preg_replace('/[^0-9A-Za-z_\-]/', '', $rest);
            // Si viene el canal exacto, mantenerlo completo: SIP/1001-0000abcd.
            // Esto evita que ChanSpy elija otro canal parecido y mejora el susurro.
            if ($rest !== '' && strpos($rest, '-') !== false) return $tech . '/' . $rest;
            $ext = preg_replace('/-.*/', '', $rest);
            return $ext !== '' ? ($tech . '/' . $ext) : '';
        }
        if (preg_match('/^(PJSIP|SIP|IAX2)\/([^\s\/]+)/i', $value, $m)) {
            $tech = strtoupper($m[1]);
            $ext = preg_replace('/[^0-9A-Za-z_\-]/', '', preg_replace('/@.*$/', '', $m[2]));
            return $ext !== '' ? ($tech . '/' . $ext) : '';
        }
        if (preg_match('/^Local\/([^@\-]+)/i', $value, $m)) {
            $ext = preg_replace('/[^0-9A-Za-z_\-]/', '', $m[1]);
            return $ext !== '' ? ('Local/' . $ext) : '';
        }
        if (preg_match('/^Agent\/([^\-\s]+)/i', $value, $m)) {
            $ext = preg_replace('/[^0-9A-Za-z_\-]/', '', $m[1]);
            return $ext !== '' ? ('Agent/' . $ext) : '';
        }
        return '';
    }


    private function parseEndpointInput($value, $selectedTech = '')
    {
        $raw = trim((string)$value);
        $tech = strtoupper(trim((string)$selectedTech));
        if ($tech === 'AGENT') $tech = 'Agent';
        if ($tech === 'LOCAL') $tech = 'Local';
        if (!in_array($tech, array('PJSIP','SIP','IAX2','Agent','Local'), true)) {
            $tech = 'PJSIP';
        }

        $patterns = array(
            '/^(PJSIP|SIP|IAX2|AGENT|LOCAL)\s*[\\\/\:\-_ ]+\s*(.+)$/i',
            '/^(PJSIP|SIP)(\d.*)$/i',
            '/^(IAX2)(\d.*)$/i',
            '/^(AGENT)(\d.*)$/i',
            '/^(LOCAL)(\d.*)$/i'
        );
        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $raw, $m)) {
                $detected = strtoupper($m[1]);
                if ($detected === 'AGENT') $detected = 'Agent';
                if ($detected === 'LOCAL') $detected = 'Local';
                $tech = $detected;
                $raw = isset($m[2]) ? $m[2] : '';
                break;
            }
        }

        $ext = preg_replace('/@.*$/', '', $raw);
        $ext = preg_replace('/[^0-9A-Za-z_\-]/', '', (string)$ext);
        $ext = preg_replace('/^(PJSIP|SIP|IAX2|Agent|LOCAL|Local)(?=\d)/i', '', $ext);
        return array('tech' => $tech, 'extension' => $ext);
    }


    /**
     * Devuelve las supervisiones ChanSpy activas. Se usa para cambiar entre
     * escuchar / susurrar / barge sin colgar la llamada del supervisor.
     */
    public function activeSpySessions()
    {
        $snapshot = $this->fastSnapshot();
        if (empty($snapshot['connected'])) {
            return array('ok' => false, 'message' => isset($snapshot['error']) ? $snapshot['error'] : 'AMI no disponible', 'rows' => array());
        }
        $lastModes = $this->readSupervisionModeState();
        $rows = array();
        $showWaiting = (bool)app_config('supervision.show_waiting_spies', false);
        foreach ($snapshot['channels'] as $ch) {
            $app = isset($ch['application']) ? strtolower((string)$ch['application']) : '';
            $appData = isset($ch['applicationdata']) ? (string)$ch['applicationdata'] : '';
            if ($app !== 'chanspy' && stripos($appData, 'ChanSpy') === false) continue;
            $channel = isset($ch['channel']) ? (string)$ch['channel'] : '';
            if ($channel === '') continue;
            $parts = explode(',', $appData, 2);
            $target = trim(isset($parts[0]) ? $parts[0] : '');
            $opts = trim(isset($parts[1]) ? $parts[1] : '');

            // v41: no mostrar supervisiones huérfanas. Cuando la llamada del agente
            // se corta, ChanSpy puede quedar esperando otro canal con el mismo prefijo.
            // Para el tablero operativo solo deben quedar visibles las supervisiones
            // cuyo agente/destino aún tiene un canal real activo.
            $targetActive = $this->spyTargetHasActiveCall($snapshot['channels'], $target, $channel);
            if (!$showWaiting && !$targetActive) continue;

            $listenerExt = $this->extensionFromChannel($channel);
            $targetExt = $this->extensionFromChannel($target);
            $mode = 'Escucha';
            if (isset($lastModes[$channel]) && is_array($lastModes[$channel]) && !empty($lastModes[$channel]['mode_label'])) {
                $mode = $lastModes[$channel]['mode_label'];
            } elseif (strpos($opts, 'B') !== false) {
                $mode = 'Barge / conferencia';
            } elseif (strpos($opts, 'w') !== false || strpos($opts, 'W') !== false) {
                $mode = 'Susurro';
            }
            $rows[] = array(
                'channel' => $channel,
                'listener_extension' => $listenerExt,
                'target' => $target,
                'target_extension' => $targetExt,
                'options' => $opts,
                'mode_label' => $mode,
                'duration' => isset($ch['duration']) ? $ch['duration'] : '',
                'duration_seconds' => isset($ch['duration_seconds']) ? (int)$ch['duration_seconds'] : 0,
                'uniqueid' => isset($ch['uniqueid']) ? $ch['uniqueid'] : '',
                'linkedid' => isset($ch['linkedid']) ? $ch['linkedid'] : '',
                'target_active' => $targetActive ? 'Sí' : 'No'
            );
        }
        return array('ok' => true, 'message' => '', 'rows' => $rows);
    }

    private function spyTargetHasActiveCall($channels, $target, $spyChannel)
    {
        $target = $this->sanitizeSpyTargetPrefix($target);
        if ($target === '') return false;

        $targetNoSuffix = $target;
        if (preg_match('/^(PJSIP|SIP|IAX2)\/([^\-]+)-/i', $target, $m)) {
            $targetNoSuffix = strtoupper($m[1]) . '/' . $m[2];
        }

        foreach ((array)$channels as $peer) {
            $channel = isset($peer['channel']) ? (string)$peer['channel'] : '';
            if ($channel === '' || $channel === $spyChannel) continue;
            $app = isset($peer['application']) ? strtolower((string)$peer['application']) : '';
            $appData = isset($peer['applicationdata']) ? (string)$peer['applicationdata'] : '';
            if ($app === 'chanspy' || stripos($appData, 'ChanSpy') !== false) continue;

            $matches = false;
            if (stripos($channel, $target . '-') === 0 || strcasecmp($channel, $target) === 0) {
                $matches = true;
            } elseif ($targetNoSuffix !== '' && (stripos($channel, $targetNoSuffix . '-') === 0 || strcasecmp($channel, $targetNoSuffix) === 0)) {
                $matches = true;
            }
            if (!$matches) continue;

            $state = strtoupper(isset($peer['state']) ? (string)$peer['state'] : '');
            $bridge = isset($peer['bridgeid']) ? trim((string)$peer['bridgeid']) : '';
            if ($bridge !== '' || $state === 'UP' || strpos($state, 'RING') !== false) {
                return true;
            }
        }
        return false;
    }

    /**
     * Cambia el modo de un ChanSpy activo enviando DTMF al canal del supervisor.
     * Requiere que ChanSpy haya iniciado con la opción d.
     * DTMF: 4=escucha, 5=susurro, 6=barge.
     */
    public function switchChanSpyMode($spyChannel, $mode)
    {
        $spyChannel = trim((string)$spyChannel);
        $mode = strtolower(trim((string)$mode));
        $map = array(
            'listen' => array('digit' => '4', 'label' => 'Escucha'),
            'whisper' => array('digit' => '5', 'label' => 'Susurro'),
            'barge' => array('digit' => '6', 'label' => 'Barge / conferencia')
        );
        if ($spyChannel === '') {
            return array('ok' => false, 'message' => 'No se recibió el canal de supervisión activo.');
        }
        if (!isset($map[$mode])) {
            return array('ok' => false, 'message' => 'Modo no válido.');
        }
        // Validar que el canal siga activo en ChanSpy antes de enviar DTMF.
        $active = $this->activeSpySessions();
        $found = null;
        if (!empty($active['ok'])) {
            foreach ($active['rows'] as $row) {
                if ((string)$row['channel'] === $spyChannel) { $found = $row; break; }
            }
        }
        if ($found === null) {
            return array('ok' => false, 'message' => 'No se encontró una supervisión activa sobre el canal indicado.');
        }
        if (!$this->connect()) {
            return array('ok' => false, 'message' => $this->lastError());
        }
        $raw = $this->sendAction(array(
            'Action' => 'PlayDTMF',
            'ActionID' => 'ccspy_mode_' . date('YmdHis') . '_' . mt_rand(1000,9999),
            'Channel' => $spyChannel,
            'Digit' => $map[$mode]['digit'],
            'Duration' => '120',
            'Receive' => 'true'
        ));
        $this->close();
        $ok = stripos($raw, 'Response: Success') !== false;
        if ($ok) {
            $this->writeSupervisionModeState($spyChannel, array(
                'mode' => $mode,
                'mode_label' => $map[$mode]['label'],
                'updated_at' => date('Y-m-d H:i:s')
            ));
        }
        $message = $ok
            ? 'Modo cambiado a ' . $map[$mode]['label'] . ' sin cortar la llamada del supervisor.'
            : 'AMI no aceptó el cambio de modo: ' . trim($raw);
        return array('ok' => $ok, 'message' => $message, 'raw' => $raw, 'mode_label' => $map[$mode]['label'], 'channel' => $spyChannel);
    }

    private function supervisionModeStateFile()
    {
        return dirname(__DIR__) . '/cache/supervision_modes.json';
    }

    private function readSupervisionModeState()
    {
        $file = $this->supervisionModeStateFile();
        if (!is_file($file)) return array();
        $raw = @file_get_contents($file);
        $data = json_decode((string)$raw, true);
        if (!is_array($data)) return array();
        // Limpiar canales muy viejos.
        $cut = time() - 86400;
        foreach ($data as $channel => $row) {
            $ts = isset($row['updated_at']) ? strtotime($row['updated_at']) : 0;
            if ($ts && $ts < $cut) unset($data[$channel]);
        }
        return $data;
    }

    private function writeSupervisionModeState($channel, $row)
    {
        $file = $this->supervisionModeStateFile();
        $dir = dirname($file);
        if (!is_dir($dir)) @mkdir($dir, 0755, true);
        $data = $this->readSupervisionModeState();
        $data[(string)$channel] = $row;
        @file_put_contents($file, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
    }

    private function writeSupervisionAudit($row)
    {
        $file = app_config('supervision.audit_file', dirname(__DIR__) . '/cache/supervision_audit.log');
        $dir = dirname($file);
        if (!is_dir($dir)) @mkdir($dir, 0755, true);
        $line = json_encode($row, JSON_UNESCAPED_UNICODE) . PHP_EOL;
        @file_put_contents($file, $line, FILE_APPEND | LOCK_EX);
    }

}
