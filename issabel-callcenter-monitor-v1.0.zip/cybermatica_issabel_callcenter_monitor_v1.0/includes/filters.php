<?php
function render_filters($agents, $range, $agentId, $extra = array())
{
    $action = isset($extra['action']) ? $extra['action'] : basename($_SERVER['PHP_SELF']);
    ?>
    <form method="get" action="<?php echo e($action); ?>" class="card filter-card shadow-sm border-0 mb-4">
        <?php if (!empty($extra['hidden']) && is_array($extra['hidden'])): ?>
            <?php foreach ($extra['hidden'] as $hk => $hv): ?>
                <input type="hidden" name="<?php echo e($hk); ?>" value="<?php echo e($hv); ?>">
            <?php endforeach; ?>
        <?php endif; ?>
        <div class="card-body">
            <div class="row g-3 align-items-end">
                <div class="col-12 col-md-2">
                    <label class="form-label">Periodo</label>
                    <select name="period" class="form-select" onchange="toggleCustomDates(this.value)">
                        <option value="today" <?php echo $range['period']==='today'?'selected':''; ?>>Hoy</option>
                        <option value="yesterday" <?php echo $range['period']==='yesterday'?'selected':''; ?>>Ayer</option>
                        <option value="week" <?php echo $range['period']==='week'?'selected':''; ?>>Semana actual</option>
                        <option value="month" <?php echo $range['period']==='month'?'selected':''; ?>>Mes actual</option>
                        <option value="custom" <?php echo $range['period']==='custom'?'selected':''; ?>>Personalizado</option>
                    </select>
                </div>
                <div class="col-6 col-md-2 custom-date">
                    <label class="form-label">Desde</label>
                    <input type="date" name="from" class="form-control" value="<?php echo e($range['from_date']); ?>">
                </div>
                <div class="col-6 col-md-2 custom-date">
                    <label class="form-label">Hasta</label>
                    <input type="date" name="to" class="form-control" value="<?php echo e($range['to_date']); ?>">
                </div>
                <div class="col-12 col-md-3">
                    <label class="form-label">Agente</label>
                    <select name="agent_id" class="form-select">
                        <option value="">Todos los agentes</option>
                        <?php foreach ($agents as $a): ?>
                            <option value="<?php echo e($a['id']); ?>" <?php echo ((string)$agentId === (string)$a['id'])?'selected':''; ?>><?php echo e($a['number'] . ' - ' . $a['name'] . ' (' . $a['type'] . ')'); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php if (!empty($extra['break_filter']) && !empty($extra['breaks']) && is_array($extra['breaks'])): ?>
                <div class="col-12 col-md-2">
                    <label class="form-label">Tipo de pausa</label>
                    <?php $breakId = isset($_GET['break_id']) ? (string)$_GET['break_id'] : ''; ?>
                    <select name="break_id" class="form-select">
                        <option value="" <?php echo $breakId===''?'selected':''; ?>>Todas las pausas</option>
                        <?php foreach ($extra['breaks'] as $br): ?>
                            <option value="<?php echo e($br['id']); ?>" <?php echo ($breakId === (string)$br['id'])?'selected':''; ?>><?php echo e($br['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php endif; ?>

                <?php if (!empty($extra['type_filter'])): ?>
                <div class="col-12 col-md-2">
                    <label class="form-label">Tipo llamada</label>
                    <select name="type" class="form-select">
                        <?php $type = isset($_GET['type']) ? $_GET['type'] : ''; ?>
                        <option value="" <?php echo $type===''?'selected':''; ?>>Todas</option>
                        <option value="entrante_callcenter" <?php echo $type==='entrante_callcenter'?'selected':''; ?>>Entrante Call Center</option>
                        <option value="saliente_campania" <?php echo $type==='saliente_campania'?'selected':''; ?>>Saliente campaña</option>
                        <option value="manual_saliente" <?php echo $type==='manual_saliente'?'selected':''; ?>>Manual saliente</option>
                        <option value="manual_entrante" <?php echo $type==='manual_entrante'?'selected':''; ?>>Manual entrante</option>
                    </select>
                </div>
                <?php endif; ?>

                <?php if (!empty($extra['q_filter'])): ?>
                <div class="col-12 col-md-3">
                    <label class="form-label">Buscar</label>
                    <input type="text" name="q" class="form-control" placeholder="Número, agente, nombre o ID" value="<?php echo e(isset($_GET['q']) ? $_GET['q'] : ''); ?>">
                </div>
                <?php endif; ?>
                <div class="col-12 col-md-1 d-grid">
                    <button class="btn btn-primary"><i class="bi bi-search"></i> Aplicar</button>
                </div>
            </div>
            <div class="text-muted small mt-2"><i class="bi bi-calendar2-week"></i> Rango consultado: <?php echo e($range['label']); ?></div>
        </div>
    </form>
    <script>document.addEventListener('DOMContentLoaded', function(){ toggleCustomDates('<?php echo e($range['period']); ?>'); });</script>
    <?php
}
?>
