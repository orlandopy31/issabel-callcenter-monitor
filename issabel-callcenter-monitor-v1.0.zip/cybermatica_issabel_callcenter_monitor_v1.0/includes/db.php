<?php
class DB
{
    private static $pdo = null;

    public static function pdo()
    {
        if (self::$pdo instanceof PDO) return self::$pdo;
        $db = app_config('db');
        $dsn = 'mysql:host=' . $db['host'] . ';port=' . $db['port'] . ';charset=' . $db['charset'];
        try {
            self::$pdo = new PDO($dsn, $db['user'], $db['pass'], array(
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => true,
            ));
            self::$pdo->exec("SET time_zone = '-03:00'");
            return self::$pdo;
        } catch (Exception $e) {
            if (app_config('app.debug', false)) {
                die('Error de conexión MySQL: ' . e($e->getMessage()));
            }
            die('No se pudo conectar a la base de datos. Revise config.php, permisos del usuario MySQL y extensión php-mysqlnd.');
        }
    }

    public static function dbName($key)
    {
        return app_config('db.' . $key);
    }

    public static function q($dbKey, $table)
    {
        $db = self::dbName($dbKey);
        return '`' . str_replace('`', '``', $db) . '`.`' . str_replace('`', '``', $table) . '`';
    }

    public static function fetchAll($sql, $params = array())
    {
        $stmt = self::pdo()->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public static function fetch($sql, $params = array())
    {
        $stmt = self::pdo()->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetch();
    }

    public static function value($sql, $params = array(), $default = null)
    {
        $row = self::fetch($sql, $params);
        if (!$row) return $default;
        $values = array_values($row);
        return isset($values[0]) ? $values[0] : $default;
    }


    public static function execute($sql, $params = array())
    {
        $stmt = self::pdo()->prepare($sql);
        return $stmt->execute($params);
    }

    public static function lastInsertId()
    {
        return self::pdo()->lastInsertId();
    }

    public static function beginTransaction()
    {
        if (!self::pdo()->inTransaction()) self::pdo()->beginTransaction();
    }

    public static function commit()
    {
        if (self::pdo()->inTransaction()) self::pdo()->commit();
    }

    public static function rollBack()
    {
        if (self::pdo()->inTransaction()) self::pdo()->rollBack();
    }

    public static function tableExists($dbKey, $table)
    {
        $db = self::dbName($dbKey);
        $sql = "SHOW TABLES FROM `" . str_replace('`', '``', $db) . "` LIKE ?";
        $row = self::fetch($sql, array($table));
        return (bool)$row;
    }
}
