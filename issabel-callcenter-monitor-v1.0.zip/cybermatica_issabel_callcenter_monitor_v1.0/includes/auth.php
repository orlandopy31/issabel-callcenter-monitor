<?php
/**
 * Autenticación y autorización por usuario.
 *
 * Compatibilidad de instalación:
 * - Si la base callcenter_panel todavía no existe, se mantiene temporalmente
 *   el usuario legado de config.php.
 * - Una vez creadas las tablas, si users está vacío, el primer login válido
 *   con las credenciales legadas crea automáticamente el superadministrador
 *   en la base de datos. Desde ese momento ya no existe bypass por config.php.
 */

function auth_schema_ready()
{
    static $ready = null;
    if ($ready !== null) return $ready;

    try {
        $db = (string)app_config('db.panel', 'callcenter_panel');
        $row = DB::fetch(
            'SELECT 1 FROM information_schema.tables WHERE table_schema = ? AND table_name = ? LIMIT 1',
            array($db, 'users')
        );
        $ready = (bool)$row;
    } catch (Exception $e) {
        $ready = false;
    }
    return $ready;
}

function auth_table($table)
{
    return DB::q('panel', $table);
}

function auth_client_ip()
{
    $ip = isset($_SERVER['REMOTE_ADDR']) ? trim((string)$_SERVER['REMOTE_ADDR']) : '';
    return substr($ip, 0, 64);
}

function auth_audit($action, $detail = '', $userId = null, $username = null)
{
    if (!auth_schema_ready()) return;
    try {
        if ($userId === null && !empty($_SESSION['ccpanel_user_id'])) $userId = (int)$_SESSION['ccpanel_user_id'];
        if ($username === null && !empty($_SESSION['ccpanel_user'])) $username = (string)$_SESSION['ccpanel_user'];
        DB::execute(
            'INSERT INTO ' . auth_table('audit_log') . ' (user_id, username, action, detail, ip_address) VALUES (?,?,?,?,?)',
            array($userId ?: null, $username ?: null, substr((string)$action,0,100), substr((string)$detail,0,500), auth_client_ip())
        );
    } catch (Exception $e) {
        // La auditoría nunca debe impedir el uso del panel.
    }
}

function auth_permissions_for_user($userId)
{
    if (!auth_schema_ready()) return array('*');
    $rows = DB::fetchAll(
        'SELECT p.code
           FROM ' . auth_table('user_permissions') . ' up
           JOIN ' . auth_table('permissions') . ' p ON p.id = up.permission_id
          WHERE up.user_id = ? AND up.allowed = 1
          ORDER BY p.sort_order, p.code',
        array((int)$userId)
    );
    $out = array();
    foreach ($rows as $r) {
        if (!empty($r['code'])) $out[] = (string)$r['code'];
    }
    return $out;
}

function auth_load_db_user($userId)
{
    if (!auth_schema_ready() || !$userId) return null;
    $row = DB::fetch(
        'SELECT id, username, full_name, active, is_superadmin, must_change_password, last_login_at
           FROM ' . auth_table('users') . ' WHERE id = ? LIMIT 1',
        array((int)$userId)
    );
    if (!$row || empty($row['active'])) return null;
    return $row;
}

function auth_apply_session_user($row)
{
    $_SESSION['ccpanel_logged'] = true;
    $_SESSION['ccpanel_user_id'] = isset($row['id']) ? (int)$row['id'] : 0;
    $_SESSION['ccpanel_user'] = isset($row['username']) ? (string)$row['username'] : '';
    $_SESSION['ccpanel_full_name'] = isset($row['full_name']) ? (string)$row['full_name'] : $_SESSION['ccpanel_user'];
    $_SESSION['ccpanel_is_superadmin'] = !empty($row['is_superadmin']);
    $_SESSION['ccpanel_must_change_password'] = !empty($row['must_change_password']);
    $_SESSION['ccpanel_permissions'] = !empty($row['is_superadmin']) ? array('*') : auth_permissions_for_user((int)$row['id']);
    $_SESSION['ccpanel_login_at'] = time();
    $_SESSION['ccpanel_auth_source'] = 'database';
}

function auth_refresh_session_user()
{
    static $done = false;
    if ($done) return !empty($_SESSION['ccpanel_logged']);
    $done = true;

    if (empty($_SESSION['ccpanel_logged'])) return false;

    // Si la base se instaló mientras seguía abierta una sesión legada,
    // migra inmediatamente el administrador antes de crear otros usuarios.
    if (empty($_SESSION['ccpanel_user_id']) && auth_schema_ready() && isset($_SESSION['ccpanel_auth_source']) && $_SESSION['ccpanel_auth_source'] === 'legacy_config') {
        $legacyRow = auth_migrate_legacy_admin((string)app_config('auth.username', ''), (string)app_config('auth.password', ''));
        if ($legacyRow) auth_apply_session_user($legacyRow);
    }

    if (!empty($_SESSION['ccpanel_user_id']) && auth_schema_ready()) {
        $row = auth_load_db_user((int)$_SESSION['ccpanel_user_id']);
        if (!$row) {
            $_SESSION = array();
            return false;
        }
        $_SESSION['ccpanel_user'] = (string)$row['username'];
        $_SESSION['ccpanel_full_name'] = (string)$row['full_name'];
        $_SESSION['ccpanel_is_superadmin'] = !empty($row['is_superadmin']);
        $_SESSION['ccpanel_must_change_password'] = !empty($row['must_change_password']);
        $_SESSION['ccpanel_permissions'] = !empty($row['is_superadmin']) ? array('*') : auth_permissions_for_user((int)$row['id']);
    }
    return true;
}

function is_logged_in()
{
    return auth_refresh_session_user();
}

function require_login()
{
    if (!is_logged_in()) {
        redirect('login.php');
    }
}

function auth_legacy_credentials_valid($username, $password)
{
    $u = (string)app_config('auth.username', '');
    $p = (string)app_config('auth.password', '');
    return $u !== '' && hash_equals($u, (string)$username) && hash_equals($p, (string)$password);
}

function auth_migrate_legacy_admin($username, $password)
{
    if (!auth_schema_ready()) return null;
    $count = (int)DB::value('SELECT COUNT(*) FROM ' . auth_table('users'), array(), 0);
    if ($count !== 0 || !auth_legacy_credentials_valid($username, $password)) return null;

    $hash = password_hash((string)$password, PASSWORD_DEFAULT);
    DB::execute(
        'INSERT INTO ' . auth_table('users') . ' (username, full_name, password_hash, active, is_superadmin, must_change_password) VALUES (?,?,?,?,?,?)',
        array((string)$username, 'Administrador', $hash, 1, 1, 0)
    );
    $id = (int)DB::lastInsertId();
    auth_audit('auth.bootstrap_admin', 'Superadministrador inicial migrado desde config.php.', $id, (string)$username);
    return DB::fetch('SELECT * FROM ' . auth_table('users') . ' WHERE id = ?', array($id));
}

function attempt_login($username, $password)
{
    $username = trim((string)$username);
    $password = (string)$password;

    if (auth_schema_ready()) {
        $row = DB::fetch('SELECT * FROM ' . auth_table('users') . ' WHERE username = ? LIMIT 1', array($username));
        if (!$row) $row = auth_migrate_legacy_admin($username, $password);

        if ($row && !empty($row['active']) && password_verify($password, (string)$row['password_hash'])) {
            if (password_needs_rehash((string)$row['password_hash'], PASSWORD_DEFAULT)) {
                DB::execute('UPDATE ' . auth_table('users') . ' SET password_hash = ? WHERE id = ?', array(password_hash($password, PASSWORD_DEFAULT), (int)$row['id']));
            }
            session_regenerate_id(true);
            auth_apply_session_user($row);
            DB::execute('UPDATE ' . auth_table('users') . ' SET last_login_at = NOW() WHERE id = ?', array((int)$row['id']));
            auth_audit('auth.login', 'Inicio de sesión correcto.', (int)$row['id'], (string)$row['username']);
            return true;
        }
        auth_audit('auth.login_failed', 'Intento fallido para usuario: ' . $username, null, $username);
        return false;
    }

    // Modo de compatibilidad temporal antes de instalar la base de usuarios.
    if (auth_legacy_credentials_valid($username, $password)) {
        session_regenerate_id(true);
        $_SESSION['ccpanel_logged'] = true;
        $_SESSION['ccpanel_user_id'] = 0;
        $_SESSION['ccpanel_user'] = $username;
        $_SESSION['ccpanel_full_name'] = 'Administrador';
        $_SESSION['ccpanel_is_superadmin'] = true;
        $_SESSION['ccpanel_permissions'] = array('*');
        $_SESSION['ccpanel_login_at'] = time();
        $_SESSION['ccpanel_auth_source'] = 'legacy_config';
        return true;
    }
    return false;
}

function current_user()
{
    if (!is_logged_in()) return null;
    return array(
        'id' => !empty($_SESSION['ccpanel_user_id']) ? (int)$_SESSION['ccpanel_user_id'] : 0,
        'username' => isset($_SESSION['ccpanel_user']) ? (string)$_SESSION['ccpanel_user'] : '',
        'full_name' => isset($_SESSION['ccpanel_full_name']) ? (string)$_SESSION['ccpanel_full_name'] : '',
        'is_superadmin' => !empty($_SESSION['ccpanel_is_superadmin']),
        'permissions' => isset($_SESSION['ccpanel_permissions']) && is_array($_SESSION['ccpanel_permissions']) ? $_SESSION['ccpanel_permissions'] : array(),
    );
}

function has_permission($code)
{
    if (!is_logged_in()) return false;
    if (!empty($_SESSION['ccpanel_is_superadmin'])) return true;
    $perms = isset($_SESSION['ccpanel_permissions']) && is_array($_SESSION['ccpanel_permissions']) ? $_SESSION['ccpanel_permissions'] : array();
    return in_array('*', $perms, true) || in_array((string)$code, $perms, true);
}

function deny_access($message = 'No tiene permisos para acceder a esta opción.')
{
    http_response_code(403);
    $safe = e($message);
    echo '<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Acceso denegado</title>';
    echo '<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"></head>';
    echo '<body class="bg-light"><div class="container py-5"><div class="card shadow-sm border-0 mx-auto" style="max-width:620px"><div class="card-body p-5 text-center">';
    echo '<h1 class="h3 mb-3">Acceso denegado</h1><p class="text-muted">'.$safe.'</p><a class="btn btn-primary" href="'.e(first_allowed_page()).'">Volver al panel</a></div></div></div></body></html>';
    exit;
}

function require_permission($code, $message = null)
{
    require_login();
    if (!has_permission($code)) {
        deny_access($message ?: 'Su usuario no tiene habilitada esta opción.');
    }
}

function has_any_permission($codes)
{
    foreach ((array)$codes as $code) {
        if (has_permission($code)) return true;
    }
    return false;
}

function require_any_permission($codes, $message = null)
{
    require_login();
    if (!has_any_permission($codes)) {
        deny_access($message ?: 'Su usuario no tiene habilitada esta opción.');
    }
}

function require_api_permission($code)
{
    if (!is_logged_in()) {
        json_response(array('ok' => false, 'message' => 'Sesión no válida o vencida.'), 401);
    }
    if (!has_permission($code)) {
        json_response(array('ok' => false, 'message' => 'Su usuario no tiene permiso para esta operación.'), 403);
    }
}

function first_allowed_page()
{
    $routes = array(
        'dashboard.view' => 'index.php',
        'live.view' => 'live.php',
        'supervision.view' => 'supervise.php',
        'productivity.view' => 'productivity.php',
        'agents.view' => 'agents.php',
        'outbound.view' => 'outbound_campaigns.php',
        'calls.view' => 'calls.php',
        'manual_calls.view' => 'manual_calls.php',
        'pauses.view' => 'pauses.php',
        'sessions.view' => 'sessions.php',
        'abandoned.view' => 'abandoned.php',
        'callbacks.view' => 'callbacks.php',
        'service_level.view' => 'service_level.php',
        'inbound_comparison.view' => 'inbound_comparison.php',
        'after_hours.view' => 'after_hours.php',
        'forms.view' => 'forms.php',
        'reports.view' => 'reports.php',
        'users.manage' => 'users.php',
        'settings.sla.manage' => 'sla_settings.php',
    );
    foreach ($routes as $perm => $page) {
        if (has_permission($perm)) return $page;
    }
    return 'logout.php';
}

function report_required_permission($report)
{
    $report = (string)$report;
    if (strpos($report, 'service_level_') === 0) return 'service_level.view';

    $map = array(
        'executive_summary' => 'dashboard.view',
        'trend_daily' => 'dashboard.view',
        'agent_decision_total' => 'productivity.view',
        'agent_daily_decision' => 'productivity.view',
        'agent_total' => 'agents.view',
        'agent_performance' => 'agents.view',
        'agent_activity' => 'agents.view',
        'agent_session_detail' => 'agents.view',
        'inbound_queue_comparison' => 'inbound_comparison.view',
        'outbound_campaigns_summary' => 'outbound.view',
        'outbound_campaigns_detail' => 'outbound.view',
        'after_hours_guard' => 'after_hours.view',
        'not_answered' => 'service_level.view',
        'lost_calls_by_hour' => 'service_level.view',
        'calls' => 'calls.view',
        'transfers' => 'calls.view',
        'manual_direct_calls' => 'manual_calls.view',
        'pauses' => 'pauses.view',
        'sessions' => 'sessions.view',
        'logged_by_hour' => 'sessions.view',
        'abandoned' => 'abandoned.view',
        'callbacks' => 'callbacks.view',
        'forms' => 'forms.view',
    );
    return isset($map[$report]) ? $map[$report] : 'reports.view';
}

function can_export_report($report)
{
    if (!has_permission('reports.export')) return false;
    $required = report_required_permission($report);
    return $required ? has_permission($required) : true;
}

function csrf_token()
{
    if (empty($_SESSION['ccpanel_csrf'])) {
        try {
            $_SESSION['ccpanel_csrf'] = bin2hex(random_bytes(32));
        } catch (Exception $e) {
            $_SESSION['ccpanel_csrf'] = sha1(uniqid('', true) . mt_rand());
        }
    }
    return $_SESSION['ccpanel_csrf'];
}

function csrf_check($token)
{
    $expected = isset($_SESSION['ccpanel_csrf']) ? (string)$_SESSION['ccpanel_csrf'] : '';
    return $expected !== '' && hash_equals($expected, (string)$token);
}

function logout_user()
{
    if (!empty($_SESSION['ccpanel_logged'])) auth_audit('auth.logout', 'Cierre de sesión.');
    $_SESSION = array();
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}
