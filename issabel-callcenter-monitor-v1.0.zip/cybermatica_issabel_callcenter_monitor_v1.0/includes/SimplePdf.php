<?php
/**
 * PDF profesional liviano sin Composer.
 * Diseñado para reportes ejecutivos de call center: encabezado, resumen, tablas paginadas.
 */
class SimplePdf
{
    private $title;
    private $pages = array();
    private $current = '';
    private $width = 842;   // A4 landscape
    private $height = 595;
    private $margin = 36;
    private $y = 0;
    private $font = 'F1';
    private $pageNo = 0;
    private $subtitle = '';

    public function __construct($title = 'Reporte')
    {
        $this->title = $title;
        $this->newPage();
    }

    public function addLine($text)
    {
        $this->ensureSpace(14);
        $this->text($this->margin, $this->y, (string)$text, 9, 'F1', 40, 40, 40);
        $this->y -= 13;
    }

    public function addReportHeader($title, $subtitle = '', $meta = array())
    {
        $this->title = $title;
        $this->subtitle = $subtitle;
        $this->rect(0, $this->height - 82, $this->width, 82, 15, 118, 110, true);
        $this->text($this->margin, $this->height - 35, app_config('app.company', 'Call Center'), 12, 'F2', 230, 255, 252);
        $this->text($this->margin, $this->height - 58, $title, 18, 'F2', 255, 255, 255);
        if ($subtitle !== '') {
            $this->text($this->margin, $this->height - 76, $subtitle, 9, 'F1', 220, 252, 247);
        }
        $x = 520;
        $i = 0;
        foreach ($meta as $k => $v) {
            $this->text($x, $this->height - 32 - ($i * 15), $k . ': ' . $v, 8, 'F1', 235, 255, 252);
            $i++;
            if ($i > 3) break;
        }
        $this->y = $this->height - 110;
    }

    public function addSummaryCards($items)
    {
        if (empty($items)) return;
        $this->ensureSpace(80);
        $cols = min(4, max(1, count($items)));
        $gap = 10;
        $cardW = ($this->width - ($this->margin * 2) - ($gap * ($cols - 1))) / $cols;
        $cardH = 50;
        $x = $this->margin;
        $col = 0;
        foreach ($items as $label => $value) {
            if ($col >= $cols) {
                $this->y -= ($cardH + 10);
                $x = $this->margin;
                $col = 0;
                $this->ensureSpace(70);
            }
            $this->rect($x, $this->y - $cardH + 12, $cardW, $cardH, 245, 248, 250, true);
            $this->rect($x, $this->y - $cardH + 12, $cardW, $cardH, 226, 232, 240, false);
            $this->text($x + 12, $this->y - 8, strtoupper($label), 7, 'F2', 91, 108, 125);
            $this->text($x + 12, $this->y - 30, (string)$value, 15, 'F2', 15, 23, 42);
            $x += $cardW + $gap;
            $col++;
        }
        $this->y -= 72;
    }

    public function addSectionTitle($title)
    {
        $this->ensureSpace(28);
        $this->text($this->margin, $this->y, $title, 12, 'F2', 15, 118, 110);
        $this->line($this->margin, $this->y - 7, $this->width - $this->margin, $this->y - 7, 203, 213, 225);
        $this->y -= 24;
    }

    public function addTable($headers, $rows)
    {
        $this->addSectionTitle('Detalle del reporte');
        if (empty($rows)) {
            $this->addLine('Sin registros para el rango seleccionado.');
            return;
        }
        $keys = array_keys($headers);
        $labels = array_values($headers);
        $count = count($keys);
        if ($count === 0) return;
        $usable = $this->width - ($this->margin * 2);
        $widths = $this->calculateWidths($keys, $headers, $usable);
        $this->drawTableHeader($labels, $widths);
        $rowNo = 0;
        foreach ($rows as $row) {
            $this->ensureSpace(24);
            if ($this->y < 60) {
                $this->newPage();
                $this->drawTableHeader($labels, $widths);
            }
            $x = $this->margin;
            $h = 22;
            if ($rowNo % 2 === 0) $this->rect($x, $this->y - $h + 6, $usable, $h, 248, 250, 252, true);
            foreach ($keys as $idx => $key) {
                $value = isset($row[$key]) ? $row[$key] : '';
                $value = preg_replace('/\s+/', ' ', (string)$value);
                $maxChars = max(8, floor($widths[$idx] / 4.8));
                if (strlen($value) > $maxChars) $value = substr($value, 0, $maxChars - 3) . '...';
                $color = $this->cellTextColor($key, $value);
                $this->text($x + 3, $this->y - 8, $value, 7, 'F1', $color[0], $color[1], $color[2]);
                $x += $widths[$idx];
            }
            $this->line($this->margin, $this->y - $h + 4, $this->width - $this->margin, $this->y - $h + 4, 226, 232, 240);
            $this->y -= $h;
            $rowNo++;
        }
    }

    private function calculateWidths($keys, $headers, $usable)
    {
        $weights = array();
        foreach ($keys as $k) {
            $w = 1;
            if (in_array($k, array('fecha_inicio','fecha_abandono','fecha_devolucion','hora','fecha'))) $w = 1.35;
            if (in_array($k, array('numero_cliente','agente','agente_devolvio','nombre'))) $w = 1.2;
            if (in_array($k, array('campania','cola','detalle_agentes','valor','grabacion'))) $w = 1.55;
            if (in_array($k, array('uniqueid','linkedid','uniqueid_abandono','uniqueid_devolucion'))) $w = 1.1;
            $weights[] = $w;
        }
        $sum = array_sum($weights);
        $widths = array();
        foreach ($weights as $w) $widths[] = $usable * ($w / $sum);
        return $widths;
    }

    private function cellTextColor($key, $value)
    {
        $k = strtolower((string)$key);
        $v = strtoupper(trim((string)$value));
        if ($v === '') return array(51, 65, 85);

        // Colorea estados operativos en reportes PDF.
        // NO ANSWER debe evaluarse antes de ANSWERED porque contiene la palabra ANSWER.
        if (strpos($k, 'estado') !== false || strpos($k, 'resultado') !== false || strpos($k, 'disposition') !== false) {
            if ($v === 'NO ANSWER' || strpos($v, 'NO ANSWER') !== false || $v === 'NOANSWER') return array(185, 28, 28);
            if (strpos($v, 'ABAND') !== false || strpos($v, 'BUSY') !== false || strpos($v, 'FAIL') !== false || strpos($v, 'CANCEL') !== false || strpos($v, 'CHANUNAVAIL') !== false || strpos($v, 'CONGESTION') !== false) return array(185, 28, 28);
            if ($v === 'ANSWERED' || strpos($v, 'ANSWERED') !== false || strpos($v, 'SUCCESS') !== false) return array(22, 101, 52);
        }
        return array(51, 65, 85);
    }

    private function drawTableHeader($labels, $widths)
    {
        $this->ensureSpace(26);
        $x = $this->margin;
        $h = 24;
        $this->rect($x, $this->y - $h + 8, $this->width - $this->margin * 2, $h, 15, 118, 110, true);
        foreach ($labels as $i => $label) {
            $maxChars = max(8, floor($widths[$i] / 4.8));
            if (strlen($label) > $maxChars) $label = substr($label, 0, $maxChars - 2) . '..';
            $this->text($x + 3, $this->y - 8, $label, 7, 'F2', 255, 255, 255);
            $x += $widths[$i];
        }
        $this->y -= $h;
    }

    private function newPage()
    {
        if ($this->current !== '') $this->pages[] = $this->current;
        $this->current = '';
        $this->pageNo++;
        $this->y = $this->height - $this->margin;
        if ($this->pageNo > 1) {
            $this->text($this->margin, $this->height - 26, $this->title, 10, 'F2', 15, 118, 110);
            $this->line($this->margin, $this->height - 34, $this->width - $this->margin, $this->height - 34, 203, 213, 225);
            $this->y = $this->height - 55;
        }
    }

    private function ensureSpace($h)
    {
        if ($this->y - $h < 50) $this->newPage();
    }

    private function text($x, $y, $text, $size = 9, $font = 'F1', $r = 0, $g = 0, $b = 0)
    {
        $this->current .= sprintf("BT /%s %0.2f Tf %0.3f %0.3f %0.3f rg %0.2f %0.2f Td (%s) Tj ET\n", $font, $size, $r/255, $g/255, $b/255, $x, $y, $this->pdfText($text));
    }

    private function rect($x, $y, $w, $h, $r, $g, $b, $fill = true)
    {
        $op = $fill ? 'f' : 'S';
        $colorOp = $fill ? 'rg' : 'RG';
        $this->current .= sprintf("%0.3f %0.3f %0.3f %s %0.2f %0.2f %0.2f %0.2f re %s\n", $r/255, $g/255, $b/255, $colorOp, $x, $y, $w, $h, $op);
    }

    private function line($x1, $y1, $x2, $y2, $r, $g, $b)
    {
        $this->current .= sprintf("%0.3f %0.3f %0.3f RG %0.2f %0.2f m %0.2f %0.2f l S\n", $r/255, $g/255, $b/255, $x1, $y1, $x2, $y2);
    }

    private function pdfText($text)
    {
        $text = str_replace(array("\\", "(", ")"), array("\\\\", "\\(", "\\)"), (string)$text);
        $text = @iconv('UTF-8', 'ISO-8859-1//TRANSLIT', $text);
        if ($text === false) $text = '';
        return $text;
    }

    public function render()
    {
        if ($this->current !== '') $this->pages[] = $this->current;
        $objects = array();
        $objects[1] = "<< /Type /Catalog /Pages 2 0 R >>";
        $objects[2] = '';
        $objects[3] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>";
        $objects[4] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>";
        $pageRefs = array();
        $objIndex = 5;
        $totalPages = count($this->pages);
        foreach ($this->pages as $i => $streamBase) {
            $pageNum = $i + 1;
            $footer = '';
            $footer .= sprintf("0.420 0.447 0.502 rg BT /F1 7 Tf %0.2f 22 Td (%s) Tj ET\n", $this->margin, $this->pdfText('Generado por Panel Ejecutivo Issabel Call Center'));
            $footer .= sprintf("0.420 0.447 0.502 rg BT /F1 7 Tf %0.2f 22 Td (%s) Tj ET\n", $this->width - 100, $this->pdfText('Página ' . $pageNum . '/' . $totalPages));
            $stream = $streamBase . $footer;
            $contentObj = $objIndex++;
            $pageObj = $objIndex++;
            $objects[$contentObj] = "<< /Length " . strlen($stream) . " >>\nstream\n" . $stream . "endstream";
            $objects[$pageObj] = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {$this->width} {$this->height}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents {$contentObj} 0 R >>";
            $pageRefs[] = $pageObj . ' 0 R';
        }
        $objects[2] = "<< /Type /Pages /Kids [" . implode(' ', $pageRefs) . "] /Count " . count($pageRefs) . " >>";
        ksort($objects);
        $pdf = "%PDF-1.4\n";
        $offsets = array(0);
        foreach ($objects as $num => $obj) {
            $offsets[$num] = strlen($pdf);
            $pdf .= $num . " 0 obj\n" . $obj . "\nendobj\n";
        }
        $xref = strlen($pdf);
        $pdf .= "xref\n0 " . (count($objects) + 1) . "\n";
        $pdf .= "0000000000 65535 f \n";
        for ($i = 1; $i <= count($objects); $i++) {
            $pdf .= sprintf('%010d 00000 n ', isset($offsets[$i]) ? $offsets[$i] : 0) . "\n";
        }
        $pdf .= "trailer\n<< /Size " . (count($objects) + 1) . " /Root 1 0 R >>\nstartxref\n" . $xref . "\n%%EOF";
        return $pdf;
    }
}
