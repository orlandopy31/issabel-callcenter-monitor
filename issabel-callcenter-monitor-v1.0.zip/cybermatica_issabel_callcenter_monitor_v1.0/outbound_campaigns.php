<?php
require_once __DIR__ . '/includes/bootstrap.php'; require_permission('outbound.view');
$repo = new AnalyticsRepository();
$range = range_from_request();
$agentId = current_agent_filter();
$agents = $repo->getAgents();
$campaignId = (isset($_GET['campaign_id']) && $_GET['campaign_id'] !== '') ? (int)$_GET['campaign_id'] : null;
$q = isset($_GET['q']) ? trim($_GET['q']) : '';
$perPage = (int)app_config('app.records_per_page', 30);
$campaigns = $repo->getOutboundCampaignList($range['from'], $range['to']);
$summaryRows = $repo->getOutboundCampaignSummary($range['from'], $range['to'], $agentId, $campaignId);
$detailAll = $repo->getOutboundCampaignDetails($range['from'], $range['to'], $agentId, $campaignId, (int)app_config('app.max_export_rows', 30000));
$detailAll = filter_rows_by_query($detailAll, $q, array('numero','numero_original','campania','agente','nombre','estado','resultado_final','uniqueid','failure_cause_txt','estados_log'));
$pagination = paginate_array($detailAll, $perPage, 'page');
$detailRows = $pagination['rows'];
$hourly = $repo->getOutboundCampaignByHour($range['from'], $range['to'], $agentId, $campaignId);
$statusBreakdown = $repo->getOutboundCampaignStatusBreakdown($range['from'], $range['to'], $agentId, $campaignId);

$totalMarcaciones = 0; $totalEfectivas = 0; $totalAtendidas = 0; $totalNoAtendidas = 0; $totalRegistros = 0; $totalTalk = 0; $totalTransfer = 0; $uniqueNumbers = array();
foreach ($summaryRows as $r) {
    $totalMarcaciones += (int)$r['marcaciones_dialer'];
    $totalEfectivas += (int)$r['efectivas'];
    $totalAtendidas += (int)$r['atendidas'];
    $totalNoAtendidas += (int)$r['no_atendidas'];
    $totalRegistros += (int)$r['registros'];
    $totalTalk += (int)$r['hablado_seg'];
    $totalTransfer += (int)$r['transferidas'];
}
foreach ($detailAll as $r) { if (!empty($r['numero'])) $uniqueNumbers[$r['numero']] = true; }
$effRate = $totalMarcaciones > 0 ? round(($totalEfectivas / $totalMarcaciones) * 100, 2) : 0;
$attRate = $totalMarcaciones > 0 ? round(($totalAtendidas / $totalMarcaciones) * 100, 2) : 0;
$noRate = $totalMarcaciones > 0 ? round(($totalNoAtendidas / $totalMarcaciones) * 100, 2) : 0;

$pageTitle='Campañas salientes';
$pageSubtitle='Marcaciones del dialer, llamadas efectivas, atendidas, no atendidas y detalle por campaña/agente';
include __DIR__ . '/includes/header.php';
?>
<form method="get" class="card filter-card shadow-sm border-0 mb-4">
    <div class="card-body">
        <div class="row g-3 align-items-end">
            <div class="col-12 col-md-2">
                <label class="form-label" for="period">Periodo</label>
                <select id="period" name="period" class="form-select" onchange="toggleCustomDates(this.value)">
                    <option value="today" <?php echo $range['period']==='today'?'selected':''; ?>>Hoy</option>
                    <option value="yesterday" <?php echo $range['period']==='yesterday'?'selected':''; ?>>Ayer</option>
                    <option value="week" <?php echo $range['period']==='week'?'selected':''; ?>>Semana actual</option>
                    <option value="month" <?php echo $range['period']==='month'?'selected':''; ?>>Mes actual</option>
                    <option value="custom" <?php echo $range['period']==='custom'?'selected':''; ?>>Personalizado</option>
                </select>
            </div>
            <div class="col-6 col-md-2 custom-date">
                <label class="form-label" for="from">Desde</label>
                <input id="from" type="date" name="from" class="form-control" value="<?php echo e($range['from_date']); ?>">
            </div>
            <div class="col-6 col-md-2 custom-date">
                <label class="form-label" for="to">Hasta</label>
                <input id="to" type="date" name="to" class="form-control" value="<?php echo e($range['to_date']); ?>">
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label" for="agent_id">Agente</label>
                <select id="agent_id" name="agent_id" class="form-select">
                    <option value="">Todos los agentes</option>
                    <?php foreach ($agents as $a): ?>
                        <option value="<?php echo e($a['id']); ?>" <?php echo ((string)$agentId === (string)$a['id'])?'selected':''; ?>><?php echo e($a['number'].' - '.$a['name'].' ('.$a['type'].')'); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label" for="campaign_id">Campaña</label>
                <select id="campaign_id" name="campaign_id" class="form-select">
                    <option value="">Todas las campañas</option>
                    <?php foreach ($campaigns as $c): ?>
                        <option value="<?php echo e($c['id']); ?>" <?php echo ((string)$campaignId === (string)$c['id'])?'selected':''; ?>><?php echo e($c['name'].' · Cola '.$c['queue']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-12 col-md-4">
                <label class="form-label" for="q">Buscar</label>
                <input id="q" type="text" name="q" class="form-control" value="<?php echo e($q); ?>" placeholder="Número, agente, estado, uniqueid o campaña">
            </div>
            <div class="col-12 col-md-2 d-grid">
                <button class="btn btn-primary"><i class="bi bi-search"></i> Aplicar</button>
            </div>
        </div>
        <div class="text-muted small mt-2"><i class="bi bi-calendar2-week"></i> Rango: <?php echo e($range['label']); ?>. La métrica “marcaciones” usa `call_progress_log`; si no hay log, estima con `retries + 1`.</div>
    </div>
</form>
<script>document.addEventListener('DOMContentLoaded', function(){ toggleCustomDates('<?php echo e($range['period']); ?>'); });</script>

<div class="row g-3 mb-4">
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 info"><span class="metric-title">Marcaciones dialer</span><strong><?php echo e($totalMarcaciones); ?></strong><small>Total de intentos de marcación</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 success"><span class="metric-title">Efectivas</span><strong><?php echo e($totalEfectivas); ?></strong><small><?php echo e($effRate); ?>% sobre marcaciones</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 neutral"><span class="metric-title">Atendidas</span><strong><?php echo e($totalAtendidas); ?></strong><small><?php echo e($attRate); ?>% contestadas/conectadas</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 warning"><span class="metric-title">No atendidas</span><strong><?php echo e($totalNoAtendidas); ?></strong><small><?php echo e($noRate); ?>% sin atención</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 dark"><span class="metric-title">Registros campaña</span><strong><?php echo e($totalRegistros); ?></strong><small>Contactos procesados en calls</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 info"><span class="metric-title">Números únicos</span><strong><?php echo e(count($uniqueNumbers)); ?></strong><small>Contactos distintos</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 success"><span class="metric-title">Tiempo hablado</span><strong><?php echo e(seconds_to_hms($totalTalk)); ?></strong><small>Total conversación</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 neutral"><span class="metric-title">Transferidas</span><strong><?php echo e($totalTransfer); ?></strong><small>Derivaciones registradas</small></div></div>
</div>

<div class="row g-4 mb-4">
    <div class="col-xxl-8">
        <div class="card h-100">
            <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-2">
                <span><i class="bi bi-graph-up-arrow"></i> Marcaciones y efectividad por hora</span>
                <div class="btn-group">
                    <a class="btn btn-outline-success btn-sm" href="export.php?report=outbound_campaigns_summary&format=csv&<?php echo e(build_query_string(array('page'=>null))); ?>"><i class="bi bi-filetype-csv"></i> CSV resumen</a>
                    <a class="btn btn-outline-danger btn-sm" href="export.php?report=outbound_campaigns_summary&format=pdf&<?php echo e(build_query_string(array('page'=>null))); ?>"><i class="bi bi-filetype-pdf"></i> PDF resumen</a>
                    <a class="btn btn-outline-success btn-sm" href="export.php?report=outbound_campaigns_detail&format=csv&<?php echo e(build_query_string(array('page'=>null))); ?>"><i class="bi bi-filetype-csv"></i> CSV detalle</a>
                    <a class="btn btn-outline-danger btn-sm" href="export.php?report=outbound_campaigns_detail&format=pdf&<?php echo e(build_query_string(array('page'=>null))); ?>"><i class="bi bi-filetype-pdf"></i> PDF detalle</a>
                </div>
            </div>
            <div class="card-body"><div style="height:320px"><canvas id="outboundHourlyChart"></canvas></div></div>
        </div>
    </div>
    <div class="col-xxl-4">
        <div class="card h-100">
            <div class="card-header"><i class="bi bi-pie-chart"></i> Estados/resultados</div>
            <div class="card-body p-0">
                <div class="table-responsive"><table class="table table-sm table-hover mb-0"><thead><tr><th>Estado</th><th class="text-end">Total</th><th class="text-end">Efect.</th><th class="text-end">No atend.</th></tr></thead><tbody>
                <?php foreach ($statusBreakdown as $s): ?>
                    <tr><td><?php echo e($s['estado']); ?></td><td class="text-end fw-bold"><?php echo e($s['total']); ?></td><td class="text-end"><span class="badge badge-ok"><?php echo e($s['efectivas']); ?></span></td><td class="text-end"><span class="badge badge-warn"><?php echo e($s['no_atendidas']); ?></span></td></tr>
                <?php endforeach; if (empty($statusBreakdown)): ?>
                    <tr><td colspan="4" class="text-center text-muted py-4">Sin datos de campaña.</td></tr>
                <?php endif; ?>
                </tbody></table></div>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm border-0 mb-4">
    <div class="card-header bg-white d-flex flex-wrap justify-content-between align-items-center gap-2">
        <span class="fw-bold"><i class="bi bi-megaphone"></i> Resumen por campaña saliente</span>
        <span class="badge bg-light text-dark border">Campañas: <?php echo e(count($summaryRows)); ?></span>
    </div>
    <div class="card-body table-responsive p-0">
        <table class="table table-hover table-sm align-middle table-polished mb-0">
            <thead><tr><th>Campaña</th><th>Cola</th><th>Troncal</th><th class="text-end">Marcaciones</th><th class="text-end">Registros</th><th class="text-end">Efectivas</th><th class="text-end">Atendidas</th><th class="text-end">No atend.</th><th class="text-end">Efect.%</th><th class="text-end">Atenc.%</th><th class="text-end">No atend.%</th><th class="text-end">Hablado</th><th class="text-end">Prom.</th></tr></thead>
            <tbody>
            <?php foreach ($summaryRows as $r): ?>
                <tr>
                    <td class="fw-bold"><?php echo e($r['campania']); ?><div class="small text-muted">ID <?php echo e($r['id_campaign']); ?> · <?php echo e($r['estado_campania']); ?></div></td>
                    <td><?php echo e($r['cola']); ?></td><td class="code-small"><?php echo e($r['troncal_campania']); ?></td>
                    <td class="text-end fw-bold"><?php echo e($r['marcaciones_dialer']); ?></td><td class="text-end"><?php echo e($r['registros']); ?></td><td class="text-end"><span class="badge badge-ok"><?php echo e($r['efectivas']); ?></span></td><td class="text-end"><?php echo e($r['atendidas']); ?></td><td class="text-end"><span class="badge badge-warn"><?php echo e($r['no_atendidas']); ?></span></td>
                    <td class="text-end"><?php echo e($r['tasa_efectividad_pct']); ?></td><td class="text-end"><?php echo e($r['tasa_atencion_pct']); ?></td><td class="text-end"><?php echo e($r['tasa_no_atendida_pct']); ?></td><td class="text-end"><?php echo e($r['hablado']); ?></td><td class="text-end"><?php echo e($r['hablado_promedio']); ?></td>
                </tr>
            <?php endforeach; if (empty($summaryRows)): ?>
                <tr><td colspan="13" class="text-center text-muted py-4">No hay campañas salientes en el rango seleccionado.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-header bg-white d-flex flex-wrap justify-content-between align-items-center gap-2">
        <span class="fw-bold"><i class="bi bi-list-ul"></i> Detalle de llamadas salientes de campaña</span>
        <span class="badge bg-light text-dark border">Total filtrado: <?php echo e($pagination['total']); ?></span>
    </div>
    <div class="card-body table-responsive p-0">
        <table class="table table-hover table-sm align-middle table-polished mb-0">
            <thead><tr><th>Fecha</th><th>Campaña</th><th>Número</th><th>Agente</th><th>Resultado</th><th>Estado</th><th class="text-end">Marc.</th><th>Duración</th><th>Espera</th><th>Transfer.</th><th>Falla</th><th>ID</th><th>Historial</th></tr></thead>
            <tbody>
            <?php foreach ($detailRows as $r): ?>
                <?php $badge = $r['resultado_final']==='EFECTIVA' ? 'badge-ok' : ($r['resultado_final']==='ATENDIDA' ? 'badge-soft' : 'badge-warn'); ?>
                <tr>
                    <td class="text-nowrap"><?php echo e($r['fecha']); ?></td>
                    <td><?php echo e($r['campania']); ?></td>
                    <td class="code-small fw-bold"><?php echo e($r['numero']); ?><div class="small text-muted"><?php echo e($r['numero_original']); ?></div></td>
                    <td><?php echo e($r['agente']); ?> <span class="text-muted small"><?php echo e($r['nombre']); ?></span></td>
                    <td><span class="badge <?php echo e($badge); ?>"><?php echo e($r['resultado_final']); ?></span></td>
                    <td><span class="badge" data-status-badge><?php echo e($r['estado']); ?></span></td>
                    <td class="text-end fw-bold"><?php echo e($r['marcaciones_dialer']); ?></td>
                    <td><?php echo e($r['duracion']); ?></td><td><?php echo e($r['espera']); ?></td><td><?php echo e($r['transferida']); ?></td>
                    <td><?php echo e($r['failure_cause_txt']); ?></td>
                    <td class="code-small"><?php echo e($r['uniqueid']); ?></td>
                    <td><button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="collapse" data-bs-target="#oc_<?php echo e($r['id']); ?>"><i class="bi bi-eye"></i></button></td>
                </tr>
                <tr class="collapse" id="oc_<?php echo e($r['id']); ?>"><td colspan="13" class="bg-light"><div class="small"><b>Log progreso:</b> <?php echo e($r['estados_log']); ?><br><b>Troncal:</b> <?php echo e($r['trunk']); ?> · <b>Originate:</b> <?php echo e($r['datetime_originate']); ?> · <b>Entrada cola:</b> <?php echo e($r['datetime_entry_queue']); ?> · <b>Grabación:</b> <?php echo e($r['grabacion']); ?></div></td></tr>
            <?php endforeach; if (empty($detailRows)): ?>
                <tr><td colspan="13" class="text-center text-muted py-4">Sin llamadas salientes de campaña para los filtros seleccionados.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php render_pagination($pagination, 'page'); ?>
<script>
document.addEventListener('DOMContentLoaded', function(){
    var labels = <?php echo json_encode(array_column($hourly, 'hora')); ?>;
    safeChart('outboundHourlyChart', {
        type: 'bar',
        data: { labels: labels, datasets: [
            { label: 'Marcaciones dialer', data: <?php echo json_encode(array_map('intval', array_column($hourly, 'marcaciones'))); ?> },
            { label: 'Efectivas', data: <?php echo json_encode(array_map('intval', array_column($hourly, 'efectivas'))); ?> },
            { label: 'Atendidas', data: <?php echo json_encode(array_map('intval', array_column($hourly, 'atendidas'))); ?> },
            { label: 'No atendidas', data: <?php echo json_encode(array_map('intval', array_column($hourly, 'no_atendidas'))); ?> }
        ] },
        options: { plugins: { legend: { position: 'bottom' } }, responsive: true, maintainAspectRatio: false }
    });
});
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
