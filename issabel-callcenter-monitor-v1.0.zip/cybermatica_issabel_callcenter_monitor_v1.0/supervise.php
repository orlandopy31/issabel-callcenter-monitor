<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_permission('supervision.view');
$canControlSupervision = has_permission('supervision.control');

$repo = new ReportRepository();
$ami = new AmiClient();
$agents = $repo->getAgents();
$runtime = $repo->getCurrentAgentRuntime();
$snapshot = $ami->cachedAgentOperationalSnapshot($runtime);
$summary = isset($snapshot['summary']) ? $snapshot['summary'] : array();

function sv_param($names, $default = '') {
    foreach ((array)$names as $name) {
        if (isset($_GET[$name]) && trim((string)$_GET[$name]) !== '') return trim((string)$_GET[$name]);
        if (isset($_POST[$name]) && trim((string)$_POST[$name]) !== '') return trim((string)$_POST[$name]);
        if (isset($_REQUEST[$name]) && trim((string)$_REQUEST[$name]) !== '') return trim((string)$_REQUEST[$name]);
    }
    return $default;
}

function sv_clean_extension($value) {
    $value = trim((string)$value);
    $value = preg_replace('/@.*$/', '', $value);
    if (preg_match('/^(PJSIP|SIP|IAX2|LOCAL|Local|Agent)\s*[\\\/:\-_ ]*\s*(.+)$/i', $value, $m)) {
        $value = $m[2];
    } elseif (preg_match('/^(PJSIP|SIP)([0-9A-Za-z_\-].*)$/i', $value, $m)) {
        $value = $m[2];
    } elseif (preg_match('/^(IAX2)([0-9A-Za-z_\-].*)$/i', $value, $m)) {
        $value = $m[2];
    }
    return preg_replace('/[^0-9A-Za-z_\-]/', '', $value);
}

function sv_parse_endpoint($value, $selectedTech) {
    $raw = trim((string)$value);
    $tech = strtoupper(trim((string)$selectedTech));
    if (!in_array($tech, array('PJSIP','SIP','IAX2'), true)) $tech = 'PJSIP';

    if (preg_match('/^(PJSIP|SIP|IAX2)\s*[\\\/:\-_ ]+\s*(.+)$/i', $raw, $m)) {
        $tech = strtoupper($m[1]);
        $raw = $m[2];
    } elseif (preg_match('/^(PJSIP|SIP)([0-9A-Za-z_\-].*)$/i', $raw, $m)) {
        $tech = strtoupper($m[1]);
        $raw = $m[2];
    } elseif (preg_match('/^(IAX2)([0-9A-Za-z_\-].*)$/i', $raw, $m)) {
        $tech = 'IAX2';
        $raw = $m[2];
    }

    $raw = preg_replace('/@.*$/', '', $raw);
    $ext = preg_replace('/[^0-9A-Za-z_\-]/', '', (string)$raw);
    return array($tech, $ext);
}

$defaultSupervisorTech = strtoupper((string)app_config('supervision.default_supervisor_tech', 'SIP'));
if (!in_array($defaultSupervisorTech, array('LOCAL','PJSIP','SIP','IAX2'), true)) $defaultSupervisorTech = 'SIP';

$values = array(
    'listen_ext' => sv_clean_extension(sv_param(array('listen_ext','listener','extension_que_escuchara','interno_escucha','interno_supervisor'), '')),
    'supervisor_tech' => strtoupper(sv_param('supervisor_tech', $defaultSupervisorTech)),
    'target_ext' => sv_param(array('target_ext','agent_ext','target_extension','interno_agente'), ''),
    'target_tech' => strtoupper(sv_param(array('target_tech','agent_tech'), 'PJSIP')),
    'mode' => strtolower(sv_param(array('mode','spy_mode'), 'listen')),
    'agent_id' => sv_param('agent_id', '0')
);
if (!in_array($values['supervisor_tech'], array('LOCAL','PJSIP','SIP','IAX2'), true)) $values['supervisor_tech'] = $defaultSupervisorTech;
list($parsedTargetTech, $parsedTargetExt) = sv_parse_endpoint($values['target_ext'], $values['target_tech']);
$values['target_tech'] = $parsedTargetTech;
$values['target_ext'] = $parsedTargetExt;
if (!in_array($values['mode'], array('listen','whisper','barge'), true)) $values['mode'] = 'listen';

$modeSwitchResult = null;
if (isset($_REQUEST['switch_supervision_mode'])) {
    if (!csrf_check(isset($_REQUEST['csrf']) ? $_REQUEST['csrf'] : '')) {
        $modeSwitchResult = array('ok' => false, 'message' => 'La sesión del formulario venció. Recargue la página.');
    } elseif (!$canControlSupervision) {
        $modeSwitchResult = array('ok' => false, 'message' => 'Su usuario puede visualizar la supervisión, pero no cambiar el modo de una escucha activa.');
    } else {
        $switchChannel = sv_param(array('spy_channel','channel'), '');
        $switchMode = strtolower(sv_param(array('switch_mode','mode'), 'listen'));
        $modeSwitchResult = $ami->switchChanSpyMode($switchChannel, $switchMode);
        auth_audit('supervision.switch_mode', 'Canal=' . $switchChannel . ' modo=' . $switchMode . ' resultado=' . (!empty($modeSwitchResult['ok']) ? 'ok' : 'error'));
    }
}

$spyResult = null;
if (isset($_REQUEST['start_supervision'])) {
    if (!csrf_check(isset($_REQUEST['csrf']) ? $_REQUEST['csrf'] : '')) {
        $spyResult = array('ok' => false, 'message' => 'La sesión del formulario venció. Recargue la página.');
    } elseif (!$canControlSupervision) {
        $spyResult = array('ok' => false, 'message' => 'Su usuario no tiene permiso para iniciar escucha, susurro o conferencia.');
    } elseif ($values['listen_ext'] === '') {
        $spyResult = array('ok' => false, 'message' => 'Debe indicar la extensión que escuchará. Use solo el número, por ejemplo 3, 1000 o 110.');
    } elseif ($values['target_ext'] === '') {
        $spyResult = array('ok' => false, 'message' => 'Debe indicar la extensión/agente a supervisar. Ejemplo: 102.');
    } else {
        $targetPrefix = $ami->spyTargetByExtension('', $values['target_tech'], $values['target_ext']);
        if ($targetPrefix === '') {
            $spyResult = array('ok' => false, 'message' => 'No se pudo construir el destino de supervisión. Verifique tecnología y extensión del agente.');
        } elseif (preg_match('/\/(Trunk|troncal|gateway|granstream)/i', $targetPrefix)) {
            $spyResult = array('ok' => false, 'message' => 'Se detectó un destino tipo troncal (' . $targetPrefix . '). Debe supervisar la extensión del agente.');
        } else {
            $label = 'target=' . $targetPrefix . ' listener=' . $values['listen_ext'];
            $spyResult = $ami->originateChanSpy($values['supervisor_tech'], $values['listen_ext'], $targetPrefix, $values['mode'], $label);
            auth_audit('supervision.start', 'Supervisor=' . $values['listen_ext'] . ' target=' . $targetPrefix . ' modo=' . $values['mode'] . ' resultado=' . (!empty($spyResult['ok']) ? 'ok' : 'error'));
        }
    }
}

$pageTitle = 'Escucha, susurro y conferencia';
$pageSubtitle = 'Supervisión rápida de agentes por extensión';
include __DIR__ . '/includes/header.php';
$refreshSeconds = (int)app_config('supervision.refresh_seconds', 15);
if ($refreshSeconds < 10) $refreshSeconds = 10;
$activeSpies = $ami->activeSpySessions();
$activeSpyRows = (!empty($activeSpies['ok']) && isset($activeSpies['rows']) && is_array($activeSpies['rows'])) ? $activeSpies['rows'] : array();
?>

<?php if (is_array($modeSwitchResult)): ?>
    <div class="alert alert-<?php echo !empty($modeSwitchResult['ok']) ? 'success' : 'danger'; ?> border-0 shadow-sm rounded-4 mb-4">
        <div class="fw-bold">Resultado</div>
        <div><?php echo e(isset($modeSwitchResult['message']) ? $modeSwitchResult['message'] : 'Sin respuesta'); ?></div>
        <?php if (!empty($modeSwitchResult['channel'])): ?>
            <div class="small mt-2 text-muted">Canal supervisor: <b><?php echo e($modeSwitchResult['channel']); ?></b></div>
        <?php endif; ?>
    </div>
<?php endif; ?>

<?php if (is_array($spyResult)): ?>
    <div class="alert alert-<?php echo !empty($spyResult['ok']) ? 'success' : 'danger'; ?> border-0 shadow-sm rounded-4 mb-4">
        <div class="fw-bold">Resultado</div>
        <div><?php echo e(isset($spyResult['message']) ? $spyResult['message'] : 'Sin respuesta'); ?></div>
        <?php if (!empty($spyResult['target']) || !empty($spyResult['supervisor'])): ?>
            <div class="small mt-2 text-muted">
                <?php if (!empty($spyResult['supervisor'])): ?>Supervisor: <b><?php echo e($spyResult['supervisor']); ?></b><?php endif; ?>
                <?php if (!empty($spyResult['target'])): ?> | Destino: <b><?php echo e($spyResult['target']); ?></b><?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>

<div id="switch-mode-result" class="mb-3"></div>

<div class="row g-3 mb-4">
    <div class="col-sm-6 col-xl-3"><div class="card metric-card"><div class="card-body"><div class="metric-icon"><i class="bi bi-telephone"></i></div><div class="metric-value" id="sup-kpi-call"><?php echo e(isset($summary['en_llamada']) ? $summary['en_llamada'] : 0); ?></div><div class="metric-label">Agentes detectados en llamada</div></div></div></div>
    <div class="col-sm-6 col-xl-3"><div class="card metric-card"><div class="card-body"><div class="metric-icon"><i class="bi bi-person-check"></i></div><div class="metric-value" id="sup-kpi-login"><?php echo e(isset($summary['logueados']) ? $summary['logueados'] : 0); ?></div><div class="metric-label">Agentes logueados</div></div></div></div>
    <div class="col-sm-6 col-xl-3"><div class="card metric-card"><div class="card-body"><div class="metric-icon"><i class="bi bi-soundwave"></i></div><div class="metric-value" id="sup-kpi-channels"><?php echo e(isset($summary['canales_activos']) ? $summary['canales_activos'] : 0); ?></div><div class="metric-label">Canales activos AMI</div></div></div></div>
    <div class="col-sm-6 col-xl-3"><div class="card metric-card"><div class="card-body"><div class="metric-icon"><i class="bi bi-arrow-repeat"></i></div><div class="metric-value" id="sup-refresh-count"><?php echo e($refreshSeconds); ?>s</div><div class="metric-label">Refresco liviano</div></div></div></div>
</div>


<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center gap-2">
        <span><i class="bi bi-sliders"></i> Supervisiones activas: cambio de modo sin cortar</span>
        <span class="badge text-bg-light" id="active-spies-count"><?php echo count($activeSpyRows); ?> activa(s)</span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th>Extensión que escucha</th>
                        <th>Canal supervisor</th>
                        <th>Agente / destino</th>
                        <th>Modo actual</th>
                        <th>Duración</th>
                        <th class="text-end">Cambiar modo</th>
                    </tr>
                </thead>
                <tbody id="active-spies-body">
                <?php if (empty($activeSpyRows)): ?>
                    <tr><td colspan="6" class="text-center text-muted py-4">No hay supervisiones activas. Inicie una escucha para habilitar los botones de cambio de modo.</td></tr>
                <?php else: ?>
                    <?php foreach ($activeSpyRows as $sp): ?>
                        <tr data-spy-channel="<?php echo e($sp['channel']); ?>">
                            <td><span class="badge text-bg-primary fs-6"><?php echo e($sp['listener_extension'] ?: '-'); ?></span></td>
                            <td class="small wrap-text"><?php echo e($sp['channel']); ?></td>
                            <td>
                                <div class="fw-semibold"><?php echo e($sp['target']); ?></div>
                                <div class="small text-muted">Ext. <?php echo e($sp['target_extension'] ?: '-'); ?></div>
                            </td>
                            <td><span class="badge text-bg-dark spy-mode-badge"><?php echo e($sp['mode_label']); ?></span></td>
                            <td><?php echo e($sp['duration'] ?: '00:00:00'); ?></td>
                            <td class="text-end">
                                <?php if ($canControlSupervision): ?>
                                <div class="btn-group btn-group-sm" role="group" aria-label="Cambiar modo de supervisión">
                                    <button class="btn btn-outline-secondary switch-spy-mode" type="button" data-channel="<?php echo e($sp['channel']); ?>" data-mode="listen" data-label="Escucha"><i class="bi bi-ear"></i> Escucha</button>
                                    <button class="btn btn-outline-warning switch-spy-mode" type="button" data-channel="<?php echo e($sp['channel']); ?>" data-mode="whisper" data-label="Susurro"><i class="bi bi-chat-left-quote"></i> Susurro</button>
                                    <button class="btn btn-outline-danger switch-spy-mode" type="button" data-channel="<?php echo e($sp['channel']); ?>" data-mode="barge" data-label="Barge / conferencia"><i class="bi bi-people"></i> Conferencia</button>
                                </div>
                                <?php else: ?>
                                    <span class="badge text-bg-light"><i class="bi bi-eye"></i> Solo lectura</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="px-3 py-2 small text-muted border-top">
            Los botones cambian el modo enviando DTMF interno al canal de supervisión: 4=escucha, 5=susurro, 6=conferencia. La tabla se limpia automáticamente cuando la llamada supervisada termina.
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-xl-5">
        <div class="card h-100">
            <div class="card-header"><i class="bi bi-person-soundwave"></i> Nueva supervisión</div>
            <div class="card-body">
                <form id="spy-form" class="vstack gap-3" method="post" action="supervise.php" autocomplete="off">
                    <?php if (!$canControlSupervision): ?><div class="alert alert-info py-2 mb-0"><i class="bi bi-eye"></i> Acceso de solo lectura: puede observar agentes y supervisiones activas, pero no iniciar ni modificar monitoreos.</div><?php endif; ?>
                    <fieldset <?php echo $canControlSupervision ? '' : 'disabled'; ?>>
                    <input type="hidden" name="csrf" value="<?php echo e(csrf_token()); ?>">
                    <input type="hidden" name="start_supervision" id="start_supervision" value="1">
                    <input type="hidden" name="agent_id" id="agent_id" value="<?php echo e($values['agent_id']); ?>">

                    <div class="rounded-4 p-3 bg-light border">
                        <div class="fw-bold mb-2"><i class="bi bi-headset"></i> Extensión supervisora</div>
                        <div class="row g-2">
                            <div class="col-md-5">
                                <label for="supervisor_tech" class="form-label fw-semibold">Tecnología del supervisor</label>
                                <select name="supervisor_tech" id="supervisor_tech" class="form-select">
                                    <option value="SIP" <?php echo $values['supervisor_tech']==='SIP'?'selected':''; ?>>SIP directo</option>
                                    <option value="PJSIP" <?php echo $values['supervisor_tech']==='PJSIP'?'selected':''; ?>>PJSIP directo</option>
                                    <option value="IAX2" <?php echo $values['supervisor_tech']==='IAX2'?'selected':''; ?>>IAX2 directo</option>
                                    <option value="LOCAL" <?php echo $values['supervisor_tech']==='LOCAL'?'selected':''; ?>>Dialplan from-internal</option>
                                </select>
                            </div>
                            <div class="col-md-7">
                                <label for="listen_ext" class="form-label fw-semibold">Extensión que escuchará</label>
                                <input type="text" name="listen_ext" id="listen_ext" class="form-control form-control-lg" placeholder="Ej: 3, 1000, 110" value="<?php echo e($values['listen_ext']); ?>" autocomplete="off" required>
                            </div>
                        </div>
                    </div>

                    <div class="rounded-4 p-3 bg-light border">
                        <div class="fw-bold mb-2"><i class="bi bi-person-badge"></i> Agente/extensión a supervisar</div>
                        <label for="agent_picker" class="form-label fw-semibold">Seleccionar agente disponible en Issabel</label>
                        <select id="agent_picker" class="form-select">
                            <option value="">Seleccionar manualmente o elegir un agente...</option>
                            <?php foreach ($agents as $a): ?>
                                <?php
                                    $type = strtoupper((string)$a['type']);
                                    $tech = in_array($type, array('PJSIP','SIP','IAX2'), true) ? $type : 'PJSIP';
                                ?>
                                <option value="<?php echo e($a['id']); ?>" data-ext="<?php echo e($a['number']); ?>" data-tech="<?php echo e($tech); ?>">
                                    <?php echo e($a['number'] . ' · ' . $a['name'] . ' (' . $a['type'] . ')'); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="row g-2 mt-2">
                            <div class="col-md-5">
                                <label for="target_tech" class="form-label fw-semibold">Tecnología agente</label>
                                <select name="target_tech" id="target_tech" class="form-select">
                                    <option value="PJSIP" <?php echo $values['target_tech']==='PJSIP'?'selected':''; ?>>PJSIP</option>
                                    <option value="SIP" <?php echo $values['target_tech']==='SIP'?'selected':''; ?>>SIP</option>
                                    <option value="IAX2" <?php echo $values['target_tech']==='IAX2'?'selected':''; ?>>IAX2</option>
                                </select>
                            </div>
                            <div class="col-md-7">
                                <label for="target_ext" class="form-label fw-semibold">Número de agente/extensión</label>
                                <input type="text" name="target_ext" id="target_ext" class="form-control" placeholder="Ej: 102" value="<?php echo e($values['target_ext']); ?>" autocomplete="off" required>
                                <div class="form-text">Destino a supervisar: <span class="fw-bold" id="target-preview"><?php echo e($values['target_tech'] . '/' . ($values['target_ext'] ?: '102')); ?></span></div>
                            </div>
                        </div>
                    </div>

                    <div>
                        <label for="mode" class="form-label fw-semibold">Modo de supervisión</label>
                        <select name="mode" id="mode" class="form-select form-select-lg">
                            <option value="listen" <?php echo $values['mode']==='listen'?'selected':''; ?>>Solo escucha</option>
                            <option value="whisper" <?php echo $values['mode']==='whisper'?'selected':''; ?>>Susurro al agente</option>
                            <option value="barge" <?php echo $values['mode']==='barge'?'selected':''; ?>>Barge / conferencia</option>
                        </select>
                    </div>

                    <button class="btn btn-primary btn-lg rounded-4" id="start-spy-btn" type="submit">
                        <i class="bi bi-ear"></i> Iniciar monitoreo
                    </button>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>

    <div class="col-xl-7">
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center gap-2">
                <span><i class="bi bi-broadcast-pin"></i> Agentes detectados en llamada</span>
                <div class="d-flex align-items-center gap-2 small text-muted">
                    <span id="sup-updated">Actualizado: <?php echo e(isset($snapshot['updated_at']) ? $snapshot['updated_at'] : date('d/m/Y H:i:s')); ?></span>
                    <button class="btn btn-sm btn-outline-primary" type="button" id="refresh-live-now"><i class="bi bi-arrow-clockwise"></i> Actualizar</button>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead><tr><th>Agente</th><th>Estado</th><th>Número actual</th><th>Duración</th><th>Canal detectado</th><th class="text-end">Acción</th></tr></thead>
                        <tbody id="live-agents-body">
                        <?php $liveAgents = isset($snapshot['agents']) && is_array($snapshot['agents']) ? $snapshot['agents'] : array(); $shown = 0; ?>
                        <?php foreach ($liveAgents as $a): ?>
                            <?php if (!(isset($a['llamada_actual']) && $a['llamada_actual'] === 'Sí')) continue; $shown++; ?>
                            <?php
                                $aTech = strtoupper(isset($a['tipo']) ? $a['tipo'] : 'PJSIP');
                                $ch = strtoupper(isset($a['canal_actual']) ? $a['canal_actual'] : '');
                                if (strpos($ch, 'PJSIP/') === 0) $aTech = 'PJSIP';
                                elseif (strpos($ch, 'SIP/') === 0) $aTech = 'SIP';
                                elseif (strpos($ch, 'IAX2/') === 0) $aTech = 'IAX2';
                                if (!in_array($aTech, array('PJSIP','SIP','IAX2'), true)) $aTech = 'PJSIP';
                                $aExt = !empty($a['login_extension']) ? $a['login_extension'] : (isset($a['agente']) ? $a['agente'] : '');
                            ?>
                            <tr>
                                <td><div class="fw-bold"><?php echo e((isset($a['agente'])?$a['agente']:'') . ' · ' . (isset($a['nombre'])?$a['nombre']:'')); ?></div><div class="small text-muted"><?php echo e(isset($a['tipo'])?$a['tipo']:''); ?> · Ext. <?php echo e($aExt); ?></div></td>
                                <td><span class="badge text-bg-primary"><?php echo e(isset($a['estado_operativo'])?$a['estado_operativo']:'En llamada'); ?></span><div class="small text-muted"><?php echo e(isset($a['tipo_llamada_actual'])?$a['tipo_llamada_actual']:''); ?></div></td>
                                <td><?php echo e(isset($a['numero_actual'])?$a['numero_actual']:''); ?></td>
                                <td><?php echo e(isset($a['duracion_llamada_actual'])?$a['duracion_llamada_actual']:'00:00:00'); ?></td>
                                <td class="small wrap-text"><?php echo e(isset($a['canal_actual'])?$a['canal_actual']:''); ?></td>
                                <td class="text-end"><button class="btn btn-sm btn-primary use-agent" type="button" data-ext="<?php echo e($aExt); ?>" data-tech="<?php echo e($aTech); ?>" data-agent="<?php echo e(isset($a['id_agent'])?$a['id_agent']:'0'); ?>"><i class="bi bi-check2-circle"></i> Usar</button></td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if ($shown === 0): ?>
                            <tr><td colspan="6" class="text-center text-muted py-4">No hay agentes detectados en llamada. Igual puede seleccionar el agente manualmente a la izquierda.</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
const SUP_REFRESH_SECONDS = <?php echo (int)$refreshSeconds; ?>;
const CAN_CONTROL_SUPERVISION = <?php echo $canControlSupervision ? 'true' : 'false'; ?>;
const SUP_CSRF_TOKEN = <?php echo json_encode(csrf_token()); ?>;
let supCountdown = SUP_REFRESH_SECONDS;
let supRefreshBusy = false;

function htmlEscape(value){
    return (value || '').toString().replace(/[&<>'"]/g, function(c){
        return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c];
    });
}
function normalizeEndpointInput(value, selectedTech){
    let raw = (value || '').toString().trim();
    let tech = (selectedTech || 'PJSIP').toString().toUpperCase();
    let m = raw.match(/^(PJSIP|SIP|IAX2)\s*[\\/:\-_ ]+\s*(.+)$/i);
    if (!m) m = raw.match(/^(PJSIP|SIP)(\d.*)$/i);
    if (!m) m = raw.match(/^(IAX2)(\d.*)$/i);
    if (m) { tech = m[1].toUpperCase(); raw = m[2] || ''; }
    raw = raw.replace(/@.*$/, '').replace(/[^0-9A-Za-z_-]/g, '').replace(/^(PJSIP|SIP|IAX2)(?=\d)/i, '');
    if (!['PJSIP','SIP','IAX2'].includes(tech)) tech = 'PJSIP';
    return {tech: tech, ext: raw};
}
function updatePreview(){
    const targetExtEl = document.getElementById('target_ext');
    const targetTechEl = document.getElementById('target_tech');
    const previewEl = document.getElementById('target-preview');
    if (!targetExtEl || !targetTechEl || !previewEl) return;
    const parsed = normalizeEndpointInput(targetExtEl.value || '102', targetTechEl.value || 'PJSIP');
    if (['PJSIP','SIP','IAX2'].includes(parsed.tech)) targetTechEl.value = parsed.tech;
    previewEl.textContent = parsed.tech + '/' + parsed.ext;
}
function fillTarget(ext, tech, agentId){
    const parsed = normalizeEndpointInput(ext, tech || 'PJSIP');
    document.getElementById('target_ext').value = parsed.ext;
    document.getElementById('target_tech').value = parsed.tech;
    document.getElementById('agent_id').value = agentId || '0';
    updatePreview();
}
function attachUseButtons(){
    document.querySelectorAll('.use-agent').forEach(function(btn){
        btn.onclick = function(){
            fillTarget(btn.getAttribute('data-ext') || '', btn.getAttribute('data-tech') || 'PJSIP', btn.getAttribute('data-agent') || '0');
        };
    });
}
function renderActiveSpies(rows){
    const body = document.getElementById('active-spies-body');
    const badge = document.getElementById('active-spies-count');
    if (badge) badge.textContent = (rows && rows.length ? rows.length : 0) + ' activa(s)';
    if (!body) return;
    if (!rows || !rows.length) {
        body.innerHTML = '<tr><td colspan="6" class="text-center text-muted py-4">No hay supervisiones activas. Inicie una escucha para habilitar los botones de cambio de modo.</td></tr>';
        return;
    }
    body.innerHTML = rows.map(function(sp){
        const channel = sp.channel || '';
        const listener = sp.listener_extension || '-';
        const target = sp.target || '';
        const targetExt = sp.target_extension || '-';
        const mode = sp.mode_label || 'Escucha';
        const duration = sp.duration || '00:00:00';
        const esc = encodeURIComponent(channel);
        return '<tr data-spy-channel="'+htmlEscape(channel)+'">'+ 
            '<td><span class="badge text-bg-primary fs-6">'+htmlEscape(listener)+'</span></td>'+ 
            '<td class="small wrap-text">'+htmlEscape(channel)+'</td>'+ 
            '<td><div class="fw-semibold">'+htmlEscape(target)+'</div><div class="small text-muted">Ext. '+htmlEscape(targetExt)+'</div></td>'+ 
            '<td><span class="badge text-bg-dark spy-mode-badge">'+htmlEscape(mode)+'</span></td>'+ 
            '<td>'+htmlEscape(duration)+'</td>'+ 
            '<td class="text-end">'+(CAN_CONTROL_SUPERVISION ? '<div class="btn-group btn-group-sm" role="group" aria-label="Cambiar modo de supervisión">'+
                '<button class="btn btn-outline-secondary switch-spy-mode" type="button" data-channel="'+htmlEscape(channel)+'" data-mode="listen" data-label="Escucha"><i class="bi bi-ear"></i> Escucha</button>'+ 
                '<button class="btn btn-outline-warning switch-spy-mode" type="button" data-channel="'+htmlEscape(channel)+'" data-mode="whisper" data-label="Susurro"><i class="bi bi-chat-left-quote"></i> Susurro</button>'+ 
                '<button class="btn btn-outline-danger switch-spy-mode" type="button" data-channel="'+htmlEscape(channel)+'" data-mode="barge" data-label="Barge / conferencia"><i class="bi bi-people"></i> Conferencia</button></div>' : '<span class="badge text-bg-light"><i class="bi bi-eye"></i> Solo lectura</span>')+'</td>'+ 
        '</tr>';
    }).join('');
}
async function refreshActiveSpies(){
    if (document.hidden) return;
    try {
        const res = await fetch('api/supervision_active.php?_=' + Date.now(), {cache: 'no-store', credentials: 'same-origin'});
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const data = await res.json();
        renderActiveSpies(data.rows || []);
    } catch (e) {
        // No bloquea el resto del tablero si AMI no responde en un ciclo.
    }
}


function setModeResult(ok, message){
    const box = document.getElementById('switch-mode-result');
    if (!box) return;
    if (!message) { box.innerHTML = ''; return; }
    box.innerHTML = '<div class="alert alert-'+(ok ? 'success' : 'danger')+' border-0 shadow-sm rounded-4 mb-3 py-2">'+htmlEscape(message)+'</div>';
    window.setTimeout(function(){ if (box) box.innerHTML = ''; }, ok ? 2200 : 6000);
}
function setRowMode(channel, label){
    const rows = document.querySelectorAll('#active-spies-body tr[data-spy-channel]');
    rows.forEach(function(row){
        if ((row.getAttribute('data-spy-channel') || '') === channel) {
            const badge = row.querySelector('.spy-mode-badge');
            if (badge) badge.textContent = label;
        }
    });
}
async function switchSpyMode(channel, mode, label, btn){
    if (!channel || !mode) return;
    const previousText = btn ? btn.innerHTML : '';
    const group = btn ? btn.closest('.btn-group') : null;
    const buttons = group ? group.querySelectorAll('button') : [];
    buttons.forEach(function(b){ b.disabled = true; });
    if (btn) btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>' + htmlEscape(label);

    // Actualización optimista inmediata: el operador ve el cambio al presionar.
    setRowMode(channel, label);
    try {
        const body = new URLSearchParams();
        body.set('spy_channel', channel);
        body.set('switch_mode', mode);
        body.set('csrf', SUP_CSRF_TOKEN);
        const res = await fetch('api/supervision_switch.php', {
            method: 'POST',
            cache: 'no-store',
            credentials: 'same-origin',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: body.toString()
        });
        const data = await res.json();
        if (!data.ok) {
            setModeResult(false, data.message || 'No se pudo cambiar el modo.');
        } else {
            setRowMode(channel, data.mode_label || label);
            setModeResult(true, data.message || ('Modo cambiado a ' + (data.mode_label || label)));
        }
        refreshActiveSpies();
    } catch (e) {
        setModeResult(false, 'No se pudo contactar al servicio de supervisión.');
    } finally {
        if (btn) btn.innerHTML = previousText;
        buttons.forEach(function(b){ b.disabled = false; });
    }
}
function attachSwitchModeButtons(){
    document.querySelectorAll('.switch-spy-mode').forEach(function(btn){
        if (btn.dataset.boundSwitch === '1') return;
        btn.dataset.boundSwitch = '1';
        btn.addEventListener('click', function(){
            switchSpyMode(btn.getAttribute('data-channel') || '', btn.getAttribute('data-mode') || 'listen', btn.getAttribute('data-label') || 'Escucha', btn);
        });
    });
}

function renderLiveRows(rows){
    const body = document.getElementById('live-agents-body');
    if (!body) return;
    if (!rows || !rows.length) {
        body.innerHTML = '<tr><td colspan="6" class="text-center text-muted py-4">No hay agentes detectados en llamada. Igual puede seleccionar el agente manualmente a la izquierda.</td></tr>';
        return;
    }
    body.innerHTML = rows.map(function(a){
        return '<tr>'+
            '<td><div class="fw-bold">'+htmlEscape(a.agente)+' · '+htmlEscape(a.nombre)+'</div><div class="small text-muted">'+htmlEscape(a.tipo)+' · Ext. '+htmlEscape(a.extension)+'</div></td>'+
            '<td><span class="badge text-bg-primary">'+htmlEscape(a.estado || 'En llamada')+'</span><div class="small text-muted">'+htmlEscape(a.tipo_llamada || '')+'</div></td>'+
            '<td>'+htmlEscape(a.numero_actual || '')+'</td>'+
            '<td>'+htmlEscape(a.duracion || '00:00:00')+'</td>'+
            '<td class="small wrap-text">'+htmlEscape(a.canal || '')+'</td>'+
            '<td class="text-end"><button class="btn btn-sm btn-primary use-agent" type="button" data-ext="'+htmlEscape(a.extension)+'" data-tech="'+htmlEscape(a.tech || 'PJSIP')+'" data-agent="'+htmlEscape(a.id_agent || '0')+'"><i class="bi bi-check2-circle"></i> Usar</button></td>'+
        '</tr>';
    }).join('');
    attachUseButtons();
}
function setText(id, value){ const el = document.getElementById(id); if (el) el.textContent = value; }
async function refreshSupervisionRuntime(force){
    if (supRefreshBusy || document.hidden) return;
    supRefreshBusy = true;
    try {
        const url = 'api/supervision_runtime.php' + (force ? '?force=1&_=' + Date.now() : '?_=' + Date.now());
        const res = await fetch(url, {cache: 'no-store', credentials: 'same-origin'});
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const data = await res.json();
        const summary = data.summary || {};
        setText('sup-kpi-call', summary.en_llamada || 0);
        setText('sup-kpi-login', summary.logueados || 0);
        setText('sup-kpi-channels', summary.canales_activos || 0);
        setText('sup-updated', 'Actualizado: ' + (data.updated_at || ''));
        renderLiveRows(data.rows || []);
        refreshActiveSpies();
    } catch (e) {
        setText('sup-updated', 'Actualización pendiente');
    } finally {
        supRefreshBusy = false;
        supCountdown = SUP_REFRESH_SECONDS;
    }
}

var picker = document.getElementById('agent_picker');
if (picker) picker.addEventListener('change', function(){
    const opt = this.options[this.selectedIndex];
    if (!opt || !opt.value) return;
    fillTarget(opt.getAttribute('data-ext') || '', opt.getAttribute('data-tech') || 'PJSIP', opt.value || '0');
});
document.getElementById('target_tech').addEventListener('change', updatePreview);
document.getElementById('target_ext').addEventListener('input', updatePreview);
updatePreview();
attachUseButtons();
attachSwitchModeButtons();
refreshActiveSpies();

const form = document.getElementById('spy-form');
const startBtn = document.getElementById('start-spy-btn');
if (form && startBtn) {
    form.addEventListener('submit', function(){
        startBtn.disabled = true;
        startBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Enviando a AMI...';
    });
}
const refreshBtn = document.getElementById('refresh-live-now');
if (refreshBtn) refreshBtn.addEventListener('click', function(){ refreshSupervisionRuntime(true); });
setInterval(function(){
    supCountdown--;
    if (supCountdown <= 0) refreshSupervisionRuntime(false);
    setText('sup-refresh-count', Math.max(supCountdown, 0) + 's');
}, 1000);
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
