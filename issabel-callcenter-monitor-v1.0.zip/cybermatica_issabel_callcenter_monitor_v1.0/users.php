<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_permission('users.manage');

$pageTitle = 'Usuarios y permisos';
$pageSubtitle = 'Administración de accesos al panel, monitoreo, reportes y funciones sensibles';

$messages = array();
$errors = array();

if (!auth_schema_ready()) {
    include __DIR__ . '/includes/header.php';
    ?>
    <div class="alert alert-warning border-0 shadow-sm rounded-4">
        <h5 class="fw-bold"><i class="bi bi-database-exclamation"></i> Falta instalar la base de usuarios</h5>
        <p class="mb-2">El panel sigue funcionando temporalmente con el usuario legado de <code>config.php</code>. Para habilitar usuarios y permisos ejecute:</p>
        <pre class="bg-dark text-white p-3 rounded-3 mb-2">mysql -u root -p &lt; sql/usuarios_permisos.sql</pre>
        <p class="mb-0">Después vuelva a iniciar sesión con el usuario administrador actual. El primer acceso migrará automáticamente ese usuario como superadministrador.</p>
    </div>
    <?php include __DIR__ . '/includes/footer.php'; exit;
}

function users_all_permissions()
{
    return DB::fetchAll('SELECT id, code, name, category, description FROM ' . auth_table('permissions') . ' ORDER BY category, sort_order, name');
}

function users_permission_ids($userId)
{
    $rows = DB::fetchAll('SELECT permission_id FROM ' . auth_table('user_permissions') . ' WHERE user_id = ? AND allowed = 1', array((int)$userId));
    $ids = array();
    foreach ($rows as $r) $ids[] = (int)$r['permission_id'];
    return $ids;
}

function users_active_superadmins_count()
{
    return (int)DB::value('SELECT COUNT(*) FROM ' . auth_table('users') . ' WHERE active = 1 AND is_superadmin = 1', array(), 0);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check(isset($_POST['csrf']) ? $_POST['csrf'] : '')) {
        $errors[] = 'La sesión del formulario venció. Recargue la página e intente nuevamente.';
    } else {
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        $username = trim(isset($_POST['username']) ? $_POST['username'] : '');
        $fullName = trim(isset($_POST['full_name']) ? $_POST['full_name'] : '');
        $password = isset($_POST['password']) ? (string)$_POST['password'] : '';
        $active = !empty($_POST['active']) ? 1 : 0;
        $isSuperadmin = !empty($_POST['is_superadmin']) ? 1 : 0;
        $permissionIds = isset($_POST['permissions']) && is_array($_POST['permissions']) ? array_map('intval', $_POST['permissions']) : array();

        if (!preg_match('/^[A-Za-z0-9._-]{3,80}$/', $username)) $errors[] = 'El usuario debe tener entre 3 y 80 caracteres y usar solo letras, números, punto, guion o guion bajo.';
        if ($fullName === '') $errors[] = 'Indique el nombre del usuario.';
        if ($id === 0 && strlen($password) < 10) $errors[] = 'La contraseña inicial debe tener al menos 10 caracteres.';
        if ($id > 0 && $password !== '' && strlen($password) < 10) $errors[] = 'La nueva contraseña debe tener al menos 10 caracteres.';

        $current = current_user();
        if ($id > 0 && $current && (int)$current['id'] === $id && !$active) {
            $active = 1;
            $errors[] = 'No puede desactivar el usuario con el que está conectado.';
        }

        $existing = $id > 0 ? DB::fetch('SELECT * FROM ' . auth_table('users') . ' WHERE id = ?', array($id)) : null;
        if ($id > 0 && !$existing) $errors[] = 'El usuario que intenta editar ya no existe.';

        if ($existing && !empty($existing['is_superadmin']) && !$isSuperadmin && users_active_superadmins_count() <= 1) {
            $isSuperadmin = 1;
            $errors[] = 'Debe quedar al menos un superadministrador activo.';
        }

        if (empty($errors)) {
            try {
                DB::beginTransaction();
                if ($id === 0) {
                    DB::execute(
                        'INSERT INTO ' . auth_table('users') . ' (username, full_name, password_hash, active, is_superadmin) VALUES (?,?,?,?,?)',
                        array($username, $fullName, password_hash($password, PASSWORD_DEFAULT), $active, $isSuperadmin)
                    );
                    $id = (int)DB::lastInsertId();
                    $action = 'user.create';
                    $detail = 'Usuario creado: ' . $username;
                } else {
                    $sql = 'UPDATE ' . auth_table('users') . ' SET username = ?, full_name = ?, active = ?, is_superadmin = ?';
                    $params = array($username, $fullName, $active, $isSuperadmin);
                    if ($password !== '') {
                        $sql .= ', password_hash = ?';
                        $params[] = password_hash($password, PASSWORD_DEFAULT);
                    }
                    $sql .= ' WHERE id = ?';
                    $params[] = $id;
                    DB::execute($sql, $params);
                    $action = 'user.update';
                    $detail = 'Usuario actualizado: ' . $username;
                }

                DB::execute('DELETE FROM ' . auth_table('user_permissions') . ' WHERE user_id = ?', array($id));
                if (!$isSuperadmin && !empty($permissionIds)) {
                    $validIds = DB::fetchAll('SELECT id FROM ' . auth_table('permissions') . ' WHERE id IN (' . implode(',', array_fill(0, count($permissionIds), '?')) . ')', $permissionIds);
                    foreach ($validIds as $p) {
                        DB::execute('INSERT INTO ' . auth_table('user_permissions') . ' (user_id, permission_id, allowed) VALUES (?,?,1)', array($id, (int)$p['id']));
                    }
                }
                DB::commit();
                auth_audit($action, $detail . ($isSuperadmin ? ' [superadministrador]' : ''));
                $messages[] = $id > 0 ? 'Usuario guardado correctamente.' : 'Usuario creado correctamente.';
                header('Location: users.php?saved=1');
                exit;
            } catch (PDOException $e) {
                DB::rollBack();
                if ((string)$e->getCode() === '23000') $errors[] = 'Ese nombre de usuario ya está registrado.';
                else $errors[] = app_config('app.debug', false) ? $e->getMessage() : 'No se pudo guardar el usuario.';
            } catch (Exception $e) {
                DB::rollBack();
                $errors[] = app_config('app.debug', false) ? $e->getMessage() : 'No se pudo guardar el usuario.';
            }
        }
    }
}

if (!empty($_GET['saved'])) $messages[] = 'Los cambios fueron guardados.';

$editId = isset($_GET['edit']) ? (int)$_GET['edit'] : 0;
$editUser = $editId > 0 ? DB::fetch('SELECT * FROM ' . auth_table('users') . ' WHERE id = ?', array($editId)) : null;
$editPermissionIds = $editUser ? users_permission_ids($editId) : array();
$permissions = users_all_permissions();
$groupedPermissions = array();
foreach ($permissions as $p) {
    $groupedPermissions[$p['category']][] = $p;
}
$users = DB::fetchAll(
    'SELECT u.id, u.username, u.full_name, u.active, u.is_superadmin, u.last_login_at, u.created_at, COUNT(up.permission_id) AS permission_count
       FROM ' . auth_table('users') . ' u
       LEFT JOIN ' . auth_table('user_permissions') . ' up ON up.user_id = u.id AND up.allowed = 1
      GROUP BY u.id, u.username, u.full_name, u.active, u.is_superadmin, u.last_login_at, u.created_at
      ORDER BY u.active DESC, u.is_superadmin DESC, u.full_name, u.username'
);

include __DIR__ . '/includes/header.php';
?>

<?php foreach ($messages as $m): ?><div class="alert alert-success border-0 shadow-sm rounded-4"><i class="bi bi-check-circle"></i> <?php echo e($m); ?></div><?php endforeach; ?>
<?php foreach ($errors as $m): ?><div class="alert alert-danger border-0 shadow-sm rounded-4"><i class="bi bi-exclamation-triangle"></i> <?php echo e($m); ?></div><?php endforeach; ?>

<div class="row g-4">
    <div class="col-xl-7">
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-people"></i> Usuarios del panel</span>
                <a href="users.php" class="btn btn-sm btn-primary"><i class="bi bi-person-plus"></i> Nuevo usuario</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead><tr><th>Usuario</th><th>Perfil</th><th>Estado</th><th>Último acceso</th><th class="text-end">Acción</th></tr></thead>
                        <tbody>
                        <?php foreach ($users as $u): ?>
                            <tr>
                                <td><div class="fw-bold"><?php echo e($u['full_name']); ?></div><div class="small text-muted"><?php echo e($u['username']); ?></div></td>
                                <td>
                                    <?php if (!empty($u['is_superadmin'])): ?>
                                        <span class="badge text-bg-dark"><i class="bi bi-shield-lock"></i> Superadministrador</span>
                                    <?php else: ?>
                                        <span class="badge badge-soft"><?php echo e((int)$u['permission_count']); ?> permiso(s)</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php if (!empty($u['active'])): ?><span class="badge text-bg-success">Activo</span><?php else: ?><span class="badge text-bg-secondary">Inactivo</span><?php endif; ?></td>
                                <td class="small text-muted"><?php echo e($u['last_login_at'] ?: 'Nunca'); ?></td>
                                <td class="text-end"><a class="btn btn-sm btn-outline-primary" href="users.php?edit=<?php echo (int)$u['id']; ?>"><i class="bi bi-pencil-square"></i> Editar</a></td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($users)): ?><tr><td colspan="5" class="text-center text-muted py-4">Todavía no hay usuarios registrados.</td></tr><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-5">
        <div class="card">
            <div class="card-header"><i class="bi bi-person-gear"></i> <?php echo $editUser ? 'Editar usuario' : 'Crear usuario'; ?></div>
            <div class="card-body">
                <form method="post" autocomplete="off">
                    <input type="hidden" name="csrf" value="<?php echo e(csrf_token()); ?>">
                    <input type="hidden" name="id" value="<?php echo $editUser ? (int)$editUser['id'] : 0; ?>">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Nombre y apellido</label>
                        <input class="form-control" type="text" name="full_name" maxlength="160" required value="<?php echo e($editUser ? $editUser['full_name'] : ''); ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Usuario</label>
                        <input class="form-control" type="text" name="username" maxlength="80" required value="<?php echo e($editUser ? $editUser['username'] : ''); ?>" placeholder="ej. supervisor01">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold"><?php echo $editUser ? 'Nueva contraseña (opcional)' : 'Contraseña inicial'; ?></label>
                        <input class="form-control" type="password" name="password" minlength="10" <?php echo $editUser ? '' : 'required'; ?> autocomplete="new-password">
                        <div class="form-text"><?php echo $editUser ? 'Déjelo vacío para mantener la contraseña actual.' : 'Mínimo 8 caracteres.'; ?></div>
                    </div>
                    <div class="d-flex flex-wrap gap-3 mb-3">
                        <div class="form-check form-switch"><input class="form-check-input" type="checkbox" name="active" id="active" value="1" <?php echo (!$editUser || !empty($editUser['active'])) ? 'checked' : ''; ?>><label class="form-check-label" for="active">Usuario activo</label></div>
                        <div class="form-check form-switch"><input class="form-check-input" type="checkbox" name="is_superadmin" id="is_superadmin" value="1" <?php echo ($editUser && !empty($editUser['is_superadmin'])) ? 'checked' : ''; ?>><label class="form-check-label" for="is_superadmin">Superadministrador</label></div>
                    </div>

                    <div class="alert alert-light border small"><i class="bi bi-info-circle"></i> Un superadministrador tiene acceso total. Para usuarios normales seleccione únicamente las opciones necesarias.</div>

                    <div id="permissionBox">
                        <?php foreach ($groupedPermissions as $category => $items): ?>
                            <div class="border rounded-3 p-3 mb-3 permission-group">
                                <div class="fw-bold mb-2"><?php echo e($category); ?></div>
                                <?php foreach ($items as $p): ?>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input permission-check" type="checkbox" name="permissions[]" value="<?php echo (int)$p['id']; ?>" id="perm_<?php echo (int)$p['id']; ?>" <?php echo in_array((int)$p['id'], $editPermissionIds, true) ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="perm_<?php echo (int)$p['id']; ?>">
                                            <span class="fw-semibold"><?php echo e($p['name']); ?></span>
                                            <?php if (!empty($p['description'])): ?><div class="small text-muted"><?php echo e($p['description']); ?></div><?php endif; ?>
                                        </label>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <button class="btn btn-primary w-100" type="submit"><i class="bi bi-save"></i> Guardar usuario y permisos</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
(function(){
    const superBox = document.getElementById('is_superadmin');
    const checks = document.querySelectorAll('.permission-check');
    function refresh(){
        const disabled = !!superBox.checked;
        checks.forEach(function(c){ c.disabled = disabled; });
        document.getElementById('permissionBox').style.opacity = disabled ? '.45' : '1';
    }
    superBox.addEventListener('change', refresh);
    refresh();
})();
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
