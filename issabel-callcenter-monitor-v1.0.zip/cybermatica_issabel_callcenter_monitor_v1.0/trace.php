<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_any_permission(array('calls.view','manual_calls.view','callbacks.view'));
$uniqueid = isset($_GET['uniqueid']) ? $_GET['uniqueid'] : '';
$linkedid = isset($_GET['linkedid']) ? $_GET['linkedid'] : '';
$repo = new ReportRepository();
$data = ($uniqueid || $linkedid) ? $repo->getTrace($uniqueid,$linkedid) : array('cdr'=>array(),'cel'=>array());
$pageTitle='Detalle de llamada';
$pageSubtitle='Recorrido, eventos y grabación asociada cuando exista';
include __DIR__ . '/includes/header.php';
?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="fw-bold mb-0"><i class="bi bi-eye"></i> Detalle de llamada</h4>
    <a class="btn btn-outline-secondary btn-sm" href="javascript:history.back()"><i class="bi bi-arrow-left"></i> Volver</a>
</div>
<div class="card shadow-sm border-0 mb-4">
    <div class="card-header bg-white fw-bold"><i class="bi bi-diagram-3"></i> Recorrido de la llamada</div>
    <div class="card-body table-responsive">
        <table class="table table-sm table-hover align-middle">
            <thead><tr><th>Fecha</th><th>Origen</th><th>Destino</th><th>Canal</th><th>Destino final</th><th>Aplicación</th><th>Total</th><th>Hablado</th><th>Estado</th><th>Grabación</th><th>ID llamada</th></tr></thead>
            <tbody>
            <?php foreach($data['cdr'] as $r): ?>
                <tr>
                    <td><?php echo e($r['calldate']); ?></td>
                    <td><?php echo e($r['src']); ?></td>
                    <td><?php echo e($r['dst']); ?></td>
                    <td class="small wrap-text"><?php echo e($r['channel']); ?></td>
                    <td class="small wrap-text"><?php echo e($r['dstchannel']); ?></td>
                    <td><?php echo e($r['lastapp']); ?></td>
                    <td><?php echo e(seconds_to_hms($r['duration'])); ?></td>
                    <td><?php echo e(seconds_to_hms($r['billsec'])); ?></td>
                    <td><span class="badge" data-status-badge><?php echo e($r['disposition']); ?></span></td>
                    <td class="small wrap-text"><?php echo e($r['recordingfile']); ?></td>
                    <td class="code-small"><?php echo e($r['uniqueid']); ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if(empty($data['cdr'])): ?><tr><td colspan="11" class="text-muted text-center py-4">No se encontraron registros del recorrido para esta llamada.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<div class="card shadow-sm border-0">
    <div class="card-header bg-white fw-bold"><i class="bi bi-list-check"></i> Eventos de la llamada</div>
    <div class="card-body table-responsive">
        <table class="table table-sm table-striped align-middle">
            <thead><tr><th>Fecha</th><th>Evento</th><th>Número</th><th>Extensión</th><th>Canal</th><th>Acción</th><th>Detalle</th></tr></thead>
            <tbody>
            <?php foreach($data['cel'] as $r): ?>
                <tr>
                    <td><?php echo e($r['eventtime']); ?></td>
                    <td><?php echo e($r['eventtype']); ?></td>
                    <td><?php echo e($r['cid_num']); ?></td>
                    <td><?php echo e($r['exten']); ?></td>
                    <td class="small wrap-text"><?php echo e($r['channame']); ?></td>
                    <td><?php echo e($r['appname']); ?></td>
                    <td class="small wrap-text"><?php echo e(trim($r['appdata'].' '.$r['eventextra'])); ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if(empty($data['cel'])): ?><tr><td colspan="7" class="text-muted text-center py-4">No se encontraron eventos adicionales para esta llamada.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
