<?php
require_once __DIR__ . '/includes/bootstrap.php'; require_permission('sessions.view');
$repo = new ReportRepository();
$range = range_from_request();
$agentId = current_agent_filter();
$agents = $repo->getAgents();
$sessions = $repo->getSessions($range['from'],$range['to'],$agentId);
$logged = $repo->getLoggedByHour($range['from'],$range['to'],$agentId);

$totalSessions = 0; $totalSeconds = 0; $activeRows = 0; $maxLogged = 0; $maxHour = '';
foreach ($sessions as $s) { $totalSessions += (int)$s['sesiones']; $totalSeconds += (int)$s['tiempo_seg']; }
foreach ($logged as $l) { if ((int)$l['agentes_logueados'] > 0) $activeRows++; if ((int)$l['agentes_logueados'] > $maxLogged) { $maxLogged = (int)$l['agentes_logueados']; $maxHour = $l['hora']; } }

$chartLabels = array_map(function($r){ return substr((string)$r['hora'],11,5); }, $logged);
$chartData = array_map(function($r){ return isset($r['agentes_logueados']) ? (int)$r['agentes_logueados'] : 0; }, $logged);

$pageTitle='Sesiones y logueados por hora';
$pageSubtitle='Detalle de sesiones, extensión utilizada y cantidad de agentes conectados por franja horaria';
include __DIR__ . '/includes/header.php'; require_once __DIR__ . '/includes/filters.php'; render_filters($agents,$range,$agentId);
?>
<div class="row g-3 mb-4">
    <div class="col-md-6 col-xl-3"><div class="metric-card-v11"><span class="metric-title">Sesiones</span><strong><?php echo e($totalSessions); ?></strong><small>en el rango</small></div></div>
    <div class="col-md-6 col-xl-3"><div class="metric-card-v11 info"><span class="metric-title">Tiempo logueado</span><strong><?php echo e(seconds_to_hms($totalSeconds)); ?></strong><small>sumatoria total</small></div></div>
    <div class="col-md-6 col-xl-3"><div class="metric-card-v11 success"><span class="metric-title">Pico logueados</span><strong><?php echo e($maxLogged); ?></strong><small><?php echo e($maxHour ? substr($maxHour,0,16) : 'sin datos'); ?></small></div></div>
    <div class="col-md-6 col-xl-3"><div class="metric-card-v11 warning"><span class="metric-title">Horas con actividad</span><strong><?php echo e($activeRows); ?></strong><small>franjas con agentes</small></div></div>
</div>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <div><h4 class="fw-bold mb-0"><i class="bi bi-clock-history"></i> Tiempo de sesión y agentes logueados</h4><div class="text-muted small">El cálculo considera el solapamiento real de sesiones con el rango seleccionado.</div></div>
    <div class="btn-group"><a class="btn btn-outline-success btn-sm" href="export.php?report=sessions&format=csv&<?php echo e(build_query_string(array())); ?>">CSV sesiones</a><a class="btn btn-outline-danger btn-sm" href="export.php?report=sessions&format=pdf&<?php echo e(build_query_string(array())); ?>">PDF sesiones</a><a class="btn btn-outline-success btn-sm" href="export.php?report=logged_by_hour&format=csv&<?php echo e(build_query_string(array())); ?>">CSV por hora</a></div>
</div>
<div class="row g-4">
    <div class="col-xl-7"><div class="card shadow-sm border-0 h-100"><div class="card-header bg-white fw-bold"><i class="bi bi-person-check"></i> Sesiones por agente</div><div class="card-body table-responsive p-0"><table class="table table-hover table-sm align-middle table-polished mb-0"><thead><tr><th>Agente</th><th>Tipo</th><th>Extensión login</th><th class="text-end">Sesiones</th><th>Tiempo sesión</th><th>Primer login</th><th>Último logout</th></tr></thead><tbody>
    <?php foreach($sessions as $r): ?><tr><td><b><?php echo e($r['agente']); ?></b><br><span class="small text-muted"><?php echo e($r['nombre']); ?></span></td><td><span class="badge badge-soft"><?php echo e($r['tipo_agente']); ?></span></td><td><span class="code-small"><?php echo e($r['login_extension']); ?></span></td><td class="text-end fw-bold"><?php echo e($r['sesiones']); ?></td><td><?php echo e($r['tiempo_sesion']); ?></td><td class="text-nowrap"><?php echo e($r['primer_login']); ?></td><td class="text-nowrap"><?php echo e($r['ultimo_logout']); ?></td></tr><?php endforeach; if(empty($sessions)): ?>
    <tr><td colspan="7" class="text-center py-4 text-muted">No hay sesiones para el rango seleccionado.</td></tr><?php else: ?>
    <tr class="table-dark"><td colspan="3"><b>TOTAL GENERAL</b></td><td class="text-end"><b><?php echo e($totalSessions); ?></b></td><td><b><?php echo e(seconds_to_hms($totalSeconds)); ?></b></td><td colspan="2"></td></tr>
    <?php endif; ?>
    </tbody></table></div></div></div>
    <div class="col-xl-5"><div class="card shadow-sm border-0 h-100"><div class="card-header bg-white fw-bold"><i class="bi bi-bar-chart-line"></i> Logueados por hora</div><div class="card-body"><div class="chart-box"><canvas id="loggedHour"></canvas></div><div id="loggedHourWarning" class="alert alert-warning small mt-3 d-none">No se pudo dibujar el gráfico, pero los datos están disponibles en la tabla.</div><div class="table-responsive mt-3"><table class="table table-sm table-polished"><thead><tr><th>Hora</th><th class="text-end">Total</th><th>Agentes</th></tr></thead><tbody><?php foreach($logged as $r): ?><tr><td><?php echo e(substr((string)$r['hora'],0,16)); ?></td><td class="text-end fw-bold"><?php echo e($r['agentes_logueados']); ?></td><td class="small wrap-text"><?php echo e($r['detalle_agentes']); ?></td></tr><?php endforeach; if(empty($logged)): ?><tr><td colspan="3" class="text-center py-3 text-muted">Sin datos por hora.</td></tr><?php endif; ?></tbody></table></div></div></div></div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function(){
  const labels = <?php echo json_encode($chartLabels, JSON_UNESCAPED_UNICODE); ?>;
  const values = <?php echo json_encode($chartData, JSON_UNESCAPED_UNICODE); ?>;
  try {
    if (typeof safeChart === 'function' && document.getElementById('loggedHour')) {
      safeChart('loggedHour', {
        type: 'line',
        data: { labels: labels, datasets: [{ label: 'Agentes logueados', data: values, tension: .25, fill: false }] },
        options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } }
      });
    }
  } catch (e) {
    var warn = document.getElementById('loggedHourWarning');
    if (warn) { warn.classList.remove('d-none'); warn.textContent = 'No se pudo dibujar el gráfico: ' + e.message; }
  }
});
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
