<?php
require_once __DIR__ . '/includes/bootstrap.php'; require_permission('reports.export');
$repo = new AnalyticsRepository();
$range = range_from_request();
$agentId = current_agent_filter();
$report = isset($_GET['report']) ? $_GET['report'] : 'executive_summary';
$requiredReportPermission = report_required_permission($report);
if ($requiredReportPermission && !has_permission($requiredReportPermission)) {
    deny_access('Su usuario no tiene permiso para consultar ni exportar este tipo de reporte.');
}
$format = isset($_GET['format']) ? $_GET['format'] : 'csv';
$max = (int)app_config('app.max_export_rows', 30000);
$title = 'Reporte'; $headers = array(); $rows = array(); $pdfHeaders = null;

$agents = $repo->getAgents();
$agentLabel = 'Todos los agentes';
foreach ($agents as $a) {
    if ($agentId !== null && (int)$a['id'] === (int)$agentId) $agentLabel = $a['number'] . ' - ' . $a['name'] . ' (' . $a['type'] . ')';
}
$summary = $repo->getSummary($range['from'], $range['to'], $agentId);
$pdfSummary = array(
    'Recibidas' => $summary['incoming'] + $summary['manual_incoming'],
    'Realizadas' => $summary['outgoing_campaign'] + $summary['manual_outgoing'],
    'Abandonadas' => $summary['abandoned'],
    'Transferidas' => $summary['transferred'],
    'Tiempo hablado' => seconds_to_hms($summary['talk_seconds']),
    'Tiempo pausa' => seconds_to_hms($summary['pause_seconds']),
    'Sesiones' => $summary['session_count'],
    'Callbacks pendientes' => $summary['callbacks_pending'],
);
$meta = array(
    'Rango' => $range['label'],
    'Agente' => $agentLabel,
    'Generado' => date('d/m/Y H:i'),
    'Fuente' => 'Panel operativo Issabel'
);

if ($report === 'agent_decision_total') {
    $title = 'Reporte ejecutivo de productividad por agente';
    $rows = $repo->getAgentDecisionMetrics($range['from'],$range['to'],$agentId);
    $headers = array(
        'agente'=>'Agente','nombre'=>'Nombre','tipo'=>'Tipo','extension_relacionada'=>'Extensión','score_productividad'=>'Score','efectividad_pct'=>'Efectividad','nivel_servicio_pct'=>'Nivel servicio','sla_meta_pct'=>'Meta SLA','cumple_sla'=>'Cumple SLA','sla_objetivo'=>'Política SLA',
        'total_recibidas'=>'Recibidas','total_realizadas'=>'Realizadas','salientes_no_devolucion'=>'Salientes no devueltas','manuales_entrantes'=>'Manual entrante','manuales_salientes'=>'Manual saliente','manuales_salientes_gestion'=>'Manual gestión','total_llamadas'=>'Total llamadas','respondidas'=>'Respondidas','respondidas_ajustadas'=>'Respondidas ajustadas','no_atendidas_brutas'=>'No atendidas brutas','no_atendidas_netas'=>'No atendidas netas',
        'abandonadas'=>'Abandonadas','abandonadas_devueltas'=>'Aband. devueltas','abandonadas_pendientes'=>'Aband. pendientes','devueltas_manual'=>'Dev. manual','devueltas_campania'=>'Dev. campaña','transferidas'=>'Transferidas','efectividad_ajustada_pct'=>'Eficiencia ajustada','tiempo_logueo'=>'Logueo','tiempo_pausa'=>'Pausa','tiempo_productivo'=>'Productivo','tiempo_hablado'=>'Hablado','llamadas_por_hora'=>'Llam/h','ocupacion_pct'=>'Ocupación','pausa_pct'=>'% Pausa','formularios'=>'Formularios','hora_mayor_no_atendida'=>'Hora pico pérdida'
    );
    $meta['Política SLA'] = report_sla_policy_label();
    $pdfHeaders = array('agente'=>'Agente','nombre'=>'Nombre','extension_relacionada'=>'Ext.','score_productividad'=>'Score','efectividad_ajustada_pct'=>'Efic. ajust.','total_recibidas'=>'Recib.','no_atendidas_netas'=>'No resp.','abandonadas_devueltas'=>'Dev.','total_realizadas'=>'Realiz.','salientes_no_devolucion'=>'Sal. no dev.','manuales_salientes_gestion'=>'Manual gest.','tiempo_logueo'=>'Logueo','tiempo_pausa'=>'Pausa','tiempo_hablado'=>'Hablado','llamadas_por_hora'=>'Llam/h');
} elseif ($report === 'agent_daily_decision') {
    $title = 'Productividad diaria por agente';
    $rows = $repo->getAgentDailyDecision($range['from'],$range['to'],$agentId);
    $headers = array('fecha'=>'Fecha','agente'=>'Agente','nombre'=>'Nombre','tipo'=>'Tipo','recibidas'=>'Recibidas','realizadas'=>'Realizadas','salientes_no_devolucion'=>'Salientes no devueltas','manuales'=>'Manuales','manuales_gestion'=>'Manual gestión','total_llamadas'=>'Total','respondidas'=>'Respondidas','devueltas'=>'Devueltas','no_atendidas_brutas'=>'No atendidas brutas','no_atendidas'=>'No atendidas netas','efectividad_pct'=>'Efectividad','efectividad_ajustada_pct'=>'Eficiencia ajustada','nivel_servicio_pct'=>'Nivel servicio','sla_meta_pct'=>'Meta SLA','cumple_sla'=>'Cumple SLA','sla_objetivo'=>'Política SLA','pausas'=>'Pausas','tiempo_pausa'=>'Pausa','tiempo_logueo'=>'Logueo','tiempo_hablado'=>'Hablado','formularios'=>'Formularios');
    $meta['Política SLA'] = report_sla_policy_label();
    $pdfHeaders = array('fecha'=>'Fecha','agente'=>'Agente','nombre'=>'Nombre','recibidas'=>'Recib.','realizadas'=>'Realiz.','devueltas'=>'Dev.','no_atendidas'=>'No resp.','manuales_gestion'=>'Manual gest.','efectividad_ajustada_pct'=>'Efic. ajust.','tiempo_pausa'=>'Pausa','tiempo_logueo'=>'Logueo');
} elseif (strpos($report, 'service_level_') === 0) {
    $bucket = str_replace('service_level_', '', $report);
    if (!in_array($bucket, array('hour','day','week','month'))) $bucket = 'hour';
    $title = 'Nivel de servicio por ' . ($bucket==='hour'?'hora':($bucket==='day'?'día':($bucket==='week'?'semana':'mes')));
    $rows = $repo->getServiceLevel($range['from'],$range['to'],$agentId,$bucket);
    $headers = array('periodo'=>'Periodo','bucket'=>'Agrupación','cola'=>'Cola','agente'=>'Agente','nombre'=>'Nombre','ofrecidas'=>'Ofrecidas','atendidas'=>'Atendidas','abandonadas'=>'Abandonadas','devueltas'=>'Devueltas','abandonadas_pendientes'=>'Pendientes','dentro_sla'=>'Dentro SLA','nivel_servicio_pct'=>'Nivel servicio','sla_meta_pct'=>'Meta SLA','cumple_sla'=>'Cumple SLA','nivel_servicio_ajustado_pct'=>'NS ajustado recuperación','nivel_devolucion_pct'=>'Nivel devolución','tasa_atencion_pct'=>'Tasa atención','tasa_abandono_pct'=>'Tasa abandono bruto','tasa_abandono_neta_pct'=>'Tasa abandono neto','espera_promedio'=>'Espera prom.','espera_maxima'=>'Espera máx.','hablado_promedio'=>'Hablado prom.','sla_objetivo'=>'Objetivo');
    $pdfHeaders = array('periodo'=>'Periodo','cola'=>'Cola','agente'=>'Agente','ofrecidas'=>'Ofrec.','atendidas'=>'Atend.','abandonadas'=>'Aband.','devueltas'=>'Dev.','abandonadas_pendientes'=>'Pend.','nivel_servicio_pct'=>'SLA','sla_meta_pct'=>'Meta','cumple_sla'=>'Cumple','nivel_servicio_ajustado_pct'=>'NS ajust.','nivel_devolucion_pct'=>'Dev.%','tasa_abandono_neta_pct'=>'Aband. neto','espera_promedio'=>'Espera prom.');
    $meta['Política SLA'] = report_sla_policy_label();
} elseif ($report === 'inbound_queue_comparison') {
    $title = 'Comparativo de llamadas entrantes en cola';
    $bucket = isset($_GET['bucket']) ? $_GET['bucket'] : 'day';
    if (!in_array($bucket, array('hour','day','week','month'), true)) $bucket = 'day';
    $queue = isset($_GET['queue']) ? trim((string)$_GET['queue']) : '';
    $rows = $repo->getInboundQueueComparison($range['from'], $range['to'], $bucket, $queue !== '' ? $queue : null);
    $headers = array(
        'periodo'=>'Periodo',
        'bucket'=>'Agrupación',
        'cola'=>'Cola',
        'ofrecidas'=>'Ofrecidas',
        'contestadas'=>'Contestadas',
        'abandonadas'=>'Abandonadas',
        'devueltas'=>'Devueltas',
        'pendientes'=>'Pendientes',
        'gestionadas_ajustadas'=>'Gestionadas ajustadas',
        'tasa_contestacion_pct'=>'Contestación',
        'tasa_abandono_pct'=>'Abandono bruto',
        'nivel_devolucion_pct'=>'Nivel devolución',
        'tasa_pendiente_pct'=>'Abandono neto',
        'eficiencia_ajustada_pct'=>'Eficiencia ajustada',
        'nivel_servicio_pct'=>'Nivel servicio',
        'sla_meta_pct'=>'Meta SLA',
        'cumple_sla'=>'Cumple SLA',
        'sla_objetivo'=>'Política SLA',
        'espera_promedio'=>'Espera promedio',
        'espera_maxima'=>'Espera máxima',
        'tiempo_hablado'=>'Tiempo hablado'
    );
    $pdfHeaders = array(
        'periodo'=>'Periodo','cola'=>'Cola','ofrecidas'=>'Ofrec.','contestadas'=>'Contest.','abandonadas'=>'Aband.','devueltas'=>'Dev.','pendientes'=>'Pend.','tasa_contestacion_pct'=>'Contest.%','nivel_servicio_pct'=>'SLA','cumple_sla'=>'Cumple','eficiencia_ajustada_pct'=>'Efic. ajust.','nivel_devolucion_pct'=>'Dev.%','tasa_pendiente_pct'=>'Aband. neto','espera_promedio'=>'Espera prom.'
    );
    $toff=0; $tans=0; $tab=0; $tdev=0; $tpen=0; $tadj=0; $tsla=0;
    foreach ($rows as $r) {
        $toff += (int)$r['ofrecidas'];
        $tans += (int)$r['contestadas'];
        $tab += (int)$r['abandonadas'];
        $tdev += (int)$r['devueltas'];
        $tpen += (int)$r['pendientes'];
        $tadj += (int)$r['gestionadas_ajustadas'];
        $tsla += (int)$r['dentro_sla'];
    }
    $pdfSummary = array(
        'Ofrecidas'=>$toff,
        'Contestadas'=>$tans,
        'Abandonadas'=>$tab,
        'Devueltas'=>$tdev,
        'Pendientes'=>$tpen,
        'SLA vigente'=>report_sla_policy_label(),
        'SLA real'=>$toff>0?number_format(($tsla/$toff)*100,2,'.').'%':'0.00%',
        'Cumplimiento SLA'=>($toff>0 && (($tsla/$toff)*100)>=report_sla_target_pct())?'CUMPLE':'NO CUMPLE',
        'Eficiencia ajustada'=>$toff>0?number_format(($tadj/$toff)*100,2,'.').'%':'0.00%',
        'Nivel devolución'=>$tab>0?number_format(($tdev/$tab)*100,2,'.').'%':'0.00%'
    );
    if ($queue !== '') $meta['Cola'] = $queue;
    $meta['Agrupación'] = $bucket;
} elseif ($report === 'after_hours_guard') {
    $title = 'Llamadas fuera de horario desviadas a guardia';
    $guardNumber = isset($_GET['guard_number']) ? trim($_GET['guard_number']) : app_config('after_hours.guard_number', '');
    $rows = $repo->getAfterHoursGuardCalls($range['from'], $range['to'], $guardNumber, $max);
    $q = isset($_GET['q']) ? trim($_GET['q']) : '';
    $rows = filter_rows_by_query($rows, $q, array('numero_llamante','numero_llamante_original','numero_guardia','fecha','hora','estado','did','destino_cdr','uniqueid','linkedid','lastdata'));
    $headers = array('fecha'=>'Fecha','hora'=>'Hora','dia_semana'=>'Día','tipo_fuera_horario'=>'Fuera de horario','numero_llamante'=>'Número llamante','numero_llamante_original'=>'Número original','numero_guardia'=>'Guardia','destino_cdr'=>'Destino CDR','did'=>'DID','estado'=>'Estado','duracion'=>'Duración','hablado'=>'Hablado','tramos'=>'Tramos','lastapp'=>'Última app','lastdata'=>'Datos app','uniqueid'=>'UniqueID','linkedid'=>'LinkedID','recordingfile'=>'Grabación');
    $pdfHeaders = array('fecha'=>'Fecha','hora'=>'Hora','tipo_fuera_horario'=>'Tipo','numero_llamante'=>'Número','numero_guardia'=>'Guardia','did'=>'DID','estado'=>'Estado','duracion'=>'Duración','hablado'=>'Hablado','tramos'=>'Tramos');
    $answered = 0; $talk = 0; $uniqueCallers = array();
    foreach ($rows as $r) {
        if (strtoupper((string)$r['estado']) === 'ANSWERED' || (int)$r['hablado_seg'] > 0) $answered++;
        $talk += (int)$r['hablado_seg'];
        if (!empty($r['numero_llamante'])) $uniqueCallers[$r['numero_llamante']] = true;
    }
    $pdfSummary = array('Total llamadas'=>count($rows),'Atendidas guardia'=>$answered,'No atendidas'=>max(0,count($rows)-$answered),'Números únicos'=>count($uniqueCallers),'Tiempo hablado'=>seconds_to_hms($talk),'Guardia'=>$guardNumber);
    $meta['Guardia'] = $guardNumber;
} elseif ($report === 'outbound_campaigns_summary') {
    $title = 'Campañas salientes - resumen operativo';
    $campaignId = (isset($_GET['campaign_id']) && $_GET['campaign_id'] !== '') ? (int)$_GET['campaign_id'] : null;
    $rows = $repo->getOutboundCampaignSummary($range['from'], $range['to'], $agentId, $campaignId);
    $headers = array('campania'=>'Campaña','id_campaign'=>'ID','estado_campania'=>'Estado campaña','cola'=>'Cola','troncal_campania'=>'Troncal','marcaciones_dialer'=>'Marcaciones dialer','registros'=>'Registros','numeros_unicos'=>'Números únicos','efectivas'=>'Efectivas','atendidas'=>'Atendidas','no_atendidas'=>'No atendidas','conectadas_agente'=>'Conectadas agente','sin_agente'=>'Sin agente','transferidas'=>'Transferidas','agendadas'=>'Agendadas','dnc'=>'DNC','reintentos_usados'=>'Reintentos usados','tasa_efectividad_pct'=>'Efectividad','tasa_atencion_pct'=>'Atención','tasa_no_atendida_pct'=>'No atendida','hablado'=>'Tiempo hablado','hablado_promedio'=>'Promedio hablado','espera_promedio'=>'Espera promedio','primera_marcacion'=>'Primera marcación','ultima_marcacion'=>'Última marcación');
    $pdfHeaders = array('campania'=>'Campaña','cola'=>'Cola','marcaciones_dialer'=>'Marc.','efectivas'=>'Efect.','atendidas'=>'Atend.','no_atendidas'=>'No atend.','tasa_efectividad_pct'=>'Efect.%','tasa_atencion_pct'=>'Atenc.%','hablado'=>'Hablado','hablado_promedio'=>'Prom.','transferidas'=>'Transf.');
    $tm=0; $te=0; $ta=0; $tn=0; $tt=0;
    foreach ($rows as $r) { $tm += (int)$r['marcaciones_dialer']; $te += (int)$r['efectivas']; $ta += (int)$r['atendidas']; $tn += (int)$r['no_atendidas']; $tt += (int)$r['hablado_seg']; }
    $pdfSummary = array('Marcaciones'=>$tm,'Efectivas'=>$te,'Atendidas'=>$ta,'No atendidas'=>$tn,'Efectividad'=>$tm>0?number_format(($te/$tm)*100,2,'.').'%':'0.00%','Tiempo hablado'=>seconds_to_hms($tt));
} elseif ($report === 'outbound_campaigns_detail') {
    $title = 'Campañas salientes - detalle de marcaciones';
    $campaignId = (isset($_GET['campaign_id']) && $_GET['campaign_id'] !== '') ? (int)$_GET['campaign_id'] : null;
    $rows = $repo->getOutboundCampaignDetails($range['from'], $range['to'], $agentId, $campaignId, $max);
    $q = isset($_GET['q']) ? trim($_GET['q']) : '';
    $rows = filter_rows_by_query($rows, $q, array('numero','numero_original','campania','agente','nombre','estado','resultado_final','uniqueid','failure_cause_txt','estados_log'));
    $headers = array('fecha'=>'Fecha','campania'=>'Campaña','cola'=>'Cola','numero'=>'Número','numero_original'=>'Número original','agente'=>'Agente','nombre'=>'Nombre','resultado_final'=>'Resultado final','efectiva'=>'Efectiva','atendida'=>'Atendida','no_atendida'=>'No atendida','estado'=>'Estado','marcaciones_dialer'=>'Marcaciones','duracion'=>'Duración','espera'=>'Espera','retries'=>'Reintentos','transferida'=>'Transferida','failure_cause'=>'Cód. falla','failure_cause_txt'=>'Falla','trunk'=>'Troncal','agendada'=>'Agendada','dnc_texto'=>'DNC','uniqueid'=>'UniqueID','grabacion'=>'Grabación','estados_log'=>'Historial progreso');
    $pdfHeaders = array('fecha'=>'Fecha','campania'=>'Campaña','numero'=>'Número','agente'=>'Agente','resultado_final'=>'Resultado','estado'=>'Estado','marcaciones_dialer'=>'Marc.','duracion'=>'Duración','failure_cause_txt'=>'Falla');
    $tm=0; $te=0; $ta=0; $tn=0;
    foreach ($rows as $r) { $tm += (int)$r['marcaciones_dialer']; if ($r['efectiva']==='Sí') $te++; if ($r['atendida']==='Sí') $ta++; if ($r['no_atendida']==='Sí') $tn++; }
    $pdfSummary = array('Registros'=>count($rows),'Marcaciones'=>$tm,'Efectivas'=>$te,'Atendidas'=>$ta,'No atendidas'=>$tn,'Efectividad'=>$tm>0?number_format(($te/$tm)*100,2,'.').'%':'0.00%');
} elseif ($report === 'lost_calls_by_hour') {
    $title = 'Horario de mayor pérdida de llamadas';
    $rows = $repo->getLostCallsByHour($range['from'],$range['to'],$agentId);
    $headers = array('hora'=>'Hora','cola'=>'Cola','abandonadas'=>'Abandonadas','espera_promedio'=>'Espera promedio','espera_maxima'=>'Espera máxima');
} elseif ($report === 'not_answered') {
    $title = 'Detalle de llamadas no atendidas';
    $rows = $repo->getNotAnsweredCalls($range['from'],$range['to'],$agentId,$max);
    $headers = array('fecha'=>'Fecha','fuente'=>'Fuente','agente'=>'Agente','nombre'=>'Nombre','extension_login'=>'Extensión','numero'=>'Número','tipo_llamada'=>'Tipo','estado'=>'Estado','espera'=>'Espera','duracion'=>'Duración','detalle'=>'Detalle','uniqueid'=>'ID llamada');
    $pdfHeaders = array('fecha'=>'Fecha','fuente'=>'Fuente','agente'=>'Agente','extension_login'=>'Ext.','numero'=>'Número','tipo_llamada'=>'Tipo','estado'=>'Estado','espera'=>'Espera','duracion'=>'Duración','detalle'=>'Detalle');
} elseif ($report === 'agent_total') {
    $title = 'Reporte total por agente';
    $rows = $repo->getAgentTotalReport($range['from'],$range['to'],$agentId);
    $headers = array(
        'agente'=>'Agente','nombre'=>'Nombre','tipo'=>'Tipo','extension_login'=>'Extensión login','sesiones'=>'Sesiones','tiempo_logueo'=>'Logueo','pausas'=>'Pausas','tiempo_pausa'=>'Pausa',
        'entrantes_callcenter'=>'Entrantes CC','manuales_entrantes'=>'Manual entrante','salientes_campania'=>'Salientes campaña','manuales_salientes'=>'Manual saliente',
        'total_recibidas'=>'Total recibidas','total_realizadas'=>'Total realizadas','total_llamadas'=>'Total llamadas','abandonadas'=>'Abandonadas','abandonadas_devueltas'=>'Aband. devueltas','transferidas'=>'Transferidas',
        'tiempo_hablado'=>'Hablado','tiempo_total_llamadas'=>'Total llamadas tiempo','promedio_hablado'=>'Prom. hablado','ocupacion_pct'=>'Ocupación','pausa_pct'=>'% Pausa','formularios'=>'Formularios'
    );
    $pdfHeaders = array('agente'=>'Agente','nombre'=>'Nombre','extension_login'=>'Ext.','sesiones'=>'Ses.','tiempo_logueo'=>'Logueo','pausas'=>'Pausas','tiempo_pausa'=>'Pausa','total_recibidas'=>'Recib.','total_realizadas'=>'Realiz.','manuales_salientes'=>'Manual sal.','total_llamadas'=>'Total','abandonadas_devueltas'=>'Devueltas','tiempo_hablado'=>'Hablado','ocupacion_pct'=>'Ocup.');
} elseif ($report === 'agent_session_detail') {
    $title = 'Detalle de sesión y pausas por agente';
    $rows = $repo->getAgentSessionDetail($range['from'],$range['to'],$agentId,$max);
    $headers = array('tipo_registro'=>'Tipo','agente'=>'Agente','nombre'=>'Nombre','tipo_agente'=>'Tipo agente','extension_login'=>'Extensión','inicio'=>'Inicio','fin'=>'Fin','duracion'=>'Duración','motivo'=>'Motivo','estado'=>'Estado');
    $pdfHeaders = array('tipo_registro'=>'Tipo','agente'=>'Agente','nombre'=>'Nombre','extension_login'=>'Ext.','inicio'=>'Inicio','fin'=>'Fin','duracion'=>'Duración','motivo'=>'Motivo','estado'=>'Estado');
} elseif ($report === 'executive_summary') {
    $title = 'Resumen ejecutivo de operación';
    $rows = $repo->getAgentPerformance($range['from'],$range['to'],$agentId);
    $headers = array('agente'=>'Agente','nombre'=>'Nombre','tipo'=>'Tipo','recibidas'=>'Recibidas','realizadas'=>'Realizadas','abandonadas'=>'Abandonadas','abandonadas_devueltas'=>'Aband. devueltas','transferidas'=>'Transferidas','tiempo_hablado'=>'Hablado','tiempo_sesion'=>'Sesión','pausas'=>'Pausas','tiempo_pausa'=>'Pausa','ocupacion_pct'=>'Ocupación','pausa_pct'=>'% Pausa','formularios'=>'Formularios');
} elseif ($report === 'agent_performance') {
    $title = 'Productividad por agente';
    $rows = $repo->getAgentPerformance($range['from'],$range['to'],$agentId);
    $headers = array('agente'=>'Agente','nombre'=>'Nombre','tipo'=>'Tipo','estado'=>'Estado','recibidas'=>'Recibidas','realizadas'=>'Realizadas','campania_saliente'=>'Campaña saliente','manuales_salientes'=>'Manual saliente','manuales_entrantes'=>'Manual entrante','abandonadas'=>'Abandonadas','abandonadas_devueltas'=>'Aband. devueltas','transferidas'=>'Transferidas','tiempo_hablado'=>'Tiempo hablado','tiempo_sesion'=>'Tiempo sesión','pausas'=>'Pausas','tiempo_pausa'=>'Tiempo pausa','ocupacion_pct'=>'Ocupación','pausa_pct'=>'% Pausa','formularios'=>'Formularios');
} elseif ($report === 'agent_activity') {
    $title = 'Detalle completo de actividades de agentes';
    $rows = $repo->getAgentActivityDetail($range['from'],$range['to'],$agentId,$max);
    $headers = array('fecha'=>'Fecha','agente'=>'Agente','nombre'=>'Nombre','tipo_agente'=>'Tipo','actividad'=>'Actividad','detalle'=>'Detalle','numero_cliente'=>'Número','resultado'=>'Resultado','duracion'=>'Duración','tiempo_hablado'=>'Hablado','espera'=>'Espera','transferida'=>'Transferida','uniqueid'=>'ID llamada');
    $pdfHeaders = array('fecha'=>'Fecha','agente'=>'Agente','nombre'=>'Nombre','actividad'=>'Actividad','detalle'=>'Detalle','numero_cliente'=>'Número','resultado'=>'Resultado','duracion'=>'Duración','tiempo_hablado'=>'Hablado');
} elseif ($report === 'trend_daily') {
    $title = 'Comportamiento diario de llamadas, pausas y sesiones';
    $rows = $repo->getDailyTrend($range['from'],$range['to'],$agentId);
    $headers = array('fecha'=>'Fecha','recibidas'=>'Recibidas','realizadas'=>'Realizadas','campania_saliente'=>'Campaña saliente','manuales_salientes'=>'Manual saliente','manuales_entrantes'=>'Manual entrante','abandonadas'=>'Abandonadas','devueltas'=>'Devueltas','transferidas'=>'Transferidas','tiempo_hablado'=>'Hablado','tiempo_pausa'=>'Pausa','tiempo_sesion'=>'Sesión');
} elseif ($report === 'calls') {
    $title = 'Seguimiento unificado de llamadas';
    $type = isset($_GET['type']) ? $_GET['type'] : '';
    $rows = $repo->getUnifiedCalls($range['from'],$range['to'],$agentId,$type,$max);
    $q = isset($_GET['q']) ? trim($_GET['q']) : '';
    $rows = filter_rows_by_query($rows, $q, array('numero_cliente','agente','nombre','tipo_agente','estado','campania','cola','uniqueid','linkedid','grabacion','tipo_llamada'));
    $headers = array('fecha_inicio'=>'Fecha','tipo_llamada'=>'Tipo','numero_cliente'=>'Número','agente'=>'Agente','nombre'=>'Nombre','tipo_agente'=>'Tipo agente','estado'=>'Estado','tiempo_hablado'=>'Hablado','duracion_total'=>'Total','espera'=>'Espera','transferida'=>'Transferida','transferencia'=>'Destino transf.','campania'=>'Campaña','cola'=>'Cola','uniqueid'=>'ID llamada','linkedid'=>'ID seguimiento','grabacion'=>'Grabación');
    $pdfHeaders = array('fecha_inicio'=>'Fecha','tipo_llamada'=>'Tipo','numero_cliente'=>'Número','agente'=>'Agente','estado'=>'Estado','tiempo_hablado'=>'Hablado','transferida'=>'Transf.','campania'=>'Campaña','uniqueid'=>'ID llamada');
} elseif ($report === 'manual_direct_calls') {
    $title = 'Llamadas manuales y directas por agente';
    $rows = $repo->getManualDirectCalls($range['from'],$range['to'],$agentId,$max);
    $tipoFilter = isset($_GET['tipo_manual']) ? trim($_GET['tipo_manual']) : '';
    if ($tipoFilter !== '') {
        $tmp = array();
        foreach ($rows as $r) {
            if ($tipoFilter === 'devuelta' && $r['devuelta'] === 'Sí') $tmp[] = $r;
            elseif ($tipoFilter === 'saliente_manual' && $r['tipo'] === 'Saliente' && $r['devuelta'] !== 'Sí') $tmp[] = $r;
            elseif ($tipoFilter === 'interna' && $r['clasificacion'] === 'Interna directa') $tmp[] = $r;
            elseif ($tipoFilter === 'troncal' && $r['clasificacion'] === 'Entrante por troncal directa') $tmp[] = $r;
        }
        $rows = $tmp;
    }
    $q = isset($_GET['q']) ? trim($_GET['q']) : '';
    $rows = filter_rows_by_query($rows, $q, array('numero','numero_normalizado','agente','nombre','extension_relacionada','clasificacion','tipo','estado','uniqueid','linkedid','channel','dstchannel','dcontext','did','grabacion'));
    $headers = array(
        'fecha'=>'Fecha','clasificacion'=>'Clasificación','tipo'=>'Tipo','devuelta'=>'Devuelta','numero_normalizado'=>'Número normalizado','numero'=>'Número original','agente'=>'Agente','nombre'=>'Nombre','tipo_agente'=>'Tipo agente','extension_relacionada'=>'Extensión relacionada','estado'=>'Estado','tiempo_hablado'=>'Hablado','duracion_total'=>'Duración total','origen'=>'Origen','destino'=>'Destino','channel'=>'Canal','dstchannel'=>'Canal destino','dcontext'=>'Contexto','did'=>'DID','fecha_abandono'=>'Fecha abandono','espera_abandono'=>'Espera abandono','cola_abandono'=>'Cola abandono','campania_abandono'=>'Campaña abandono','uniqueid'=>'UniqueID','linkedid'=>'LinkedID','grabacion'=>'Grabación'
    );
    $pdfHeaders = array('fecha'=>'Fecha','clasificacion'=>'Clasificación','tipo'=>'Tipo','devuelta'=>'Dev.','numero_normalizado'=>'Número','agente'=>'Agente','extension_relacionada'=>'Ext.','estado'=>'Estado','tiempo_hablado'=>'Hablado','fecha_abandono'=>'Abandono','cola_abandono'=>'Cola');
} elseif ($report === 'pauses') {
    $title = 'Pausas por agente';
    $breakId = (isset($_GET['break_id']) && $_GET['break_id'] !== '') ? (int)$_GET['break_id'] : null;
    $rows = $repo->getPauses($range['from'],$range['to'],$agentId,$breakId);
    $totalCantidad = 0; $totalSegundos = 0;
    foreach ($rows as $rr) { $totalCantidad += (int)$rr['cantidad']; $totalSegundos += (int)$rr['tiempo_seg']; }
    if (count($rows) > 0) {
        $rows[] = array('agente'=>'TOTAL','nombre'=>'General','tipo_agente'=>'','motivo'=>'Todos los motivos','cantidad'=>$totalCantidad,'tiempo_pausa'=>seconds_to_hms($totalSegundos),'promedio_pausa'=>seconds_to_hms($totalCantidad > 0 ? round($totalSegundos / $totalCantidad) : 0),'primera'=>'','ultima'=>'');
    }
    $headers = array('agente'=>'Agente','nombre'=>'Nombre','tipo_agente'=>'Tipo','motivo'=>'Motivo','cantidad'=>'Cantidad','tiempo_pausa'=>'Tiempo total','promedio_pausa'=>'Promedio','primera'=>'Primera','ultima'=>'Última');
} elseif ($report === 'sessions') {
    $title = 'Sesiones por agente';
    $rows = $repo->getSessions($range['from'],$range['to'],$agentId);
    $totalSesiones = 0; $totalSegundos = 0;
    foreach ($rows as $rr) { $totalSesiones += (int)$rr['sesiones']; $totalSegundos += (int)$rr['tiempo_seg']; }
    if (count($rows) > 0) {
        $rows[] = array('agente'=>'TOTAL','nombre'=>'General','tipo_agente'=>'','login_extension'=>'','sesiones'=>$totalSesiones,'tiempo_sesion'=>seconds_to_hms($totalSegundos),'primer_login'=>'','ultimo_logout'=>'');
    }
    $headers = array('agente'=>'Agente','nombre'=>'Nombre','tipo_agente'=>'Tipo','login_extension'=>'Extensión login','sesiones'=>'Sesiones','tiempo_sesion'=>'Tiempo sesión','primer_login'=>'Primer login','ultimo_logout'=>'Último logout');
} elseif ($report === 'logged_by_hour') {
    $title = 'Agentes logueados por hora';
    $rows = $repo->getLoggedByHour($range['from'],$range['to'],$agentId);
    $headers = array('hora'=>'Hora','agentes_logueados'=>'Total','detalle_agentes'=>'Agentes');
} elseif ($report === 'abandoned') {
    $title = 'Llamadas abandonadas';
    $rows = $repo->getAbandoned($range['from'],$range['to'],$agentId,$max);
    $headers = array('fecha_abandono'=>'Fecha abandono','numero_cliente'=>'Número','espera'=>'Espera','estado'=>'Estado','cola'=>'Cola','campania'=>'Campaña','uniqueid'=>'ID llamada');
} elseif ($report === 'callbacks') {
    $status = isset($_GET['status']) ? trim($_GET['status']) : 'pendientes';
    if (!in_array($status, array('pendientes','devueltas','todas'), true)) $status = 'pendientes';
    $titleSuffix = $status === 'devueltas' ? ' - devueltas' : ($status === 'pendientes' ? ' - no devueltas' : ' - todas');
    $title = 'Devolución de llamadas' . $titleSuffix;
    $rows = $repo->getCallbacks($range['from'],$range['to'],$agentId,$max);
    $q = isset($_GET['q']) ? trim($_GET['q']) : '';
    $rows = filter_rows_by_query($rows, $q, array('numero_cliente','numero_cliente_original','fecha_abandono','cola','campania','devuelta','fecha_devolucion','extension_devolvio','agente_devolvio','agente_devolvio_numero','agente_devolvio_nombre','tipo_devolucion','origen_devolucion','estado_devolucion','uniqueid_abandono','uniqueid_devolucion','linkedid_devolucion'));
    if ($status !== 'todas') {
        $tmp = array();
        foreach ($rows as $r) {
            $isReturned = isset($r['devuelta']) && $r['devuelta'] === 'Sí';
            if ($status === 'devueltas' && $isReturned) $tmp[] = $r;
            if ($status === 'pendientes' && !$isReturned) $tmp[] = $r;
        }
        $rows = $tmp;
    }
    $headers = array('numero_cliente'=>'Número perdido','numero_cliente_original'=>'Número original','fecha_abandono'=>'Fecha abandono','espera'=>'Espera','estado_abandono'=>'Estado abandono','cola'=>'Cola','campania'=>'Campaña','devuelta'=>'Devuelta','fecha_devolucion'=>'Fecha devolución','extension_devolvio'=>'Extensión devolvió','agente_devolvio_numero'=>'Nro. agente','agente_devolvio_nombre'=>'Nombre agente','agente_devolvio'=>'Agente devolvió','tipo_devolucion'=>'Tipo','origen_devolucion'=>'Origen','estado_devolucion'=>'Estado devolución','tiempo_hasta_devolucion'=>'Tiempo hasta devolución','uniqueid_abandono'=>'ID abandono','uniqueid_devolucion'=>'ID devolución','linkedid_devolucion'=>'LinkedID devolución');
    $pdfHeaders = array('numero_cliente'=>'Número','fecha_abandono'=>'Abandono','espera'=>'Espera','devuelta'=>'Devuelta','fecha_devolucion'=>'Devolución','extension_devolvio'=>'Extensión','agente_devolvio'=>'Agente','tipo_devolucion'=>'Tipo','origen_devolucion'=>'Origen','estado_devolucion'=>'Estado','tiempo_hasta_devolucion'=>'Tiempo');
} elseif ($report === 'forms') {
    $title = 'Formularios cargados';
    $rows = $repo->getForms($range['from'],$range['to'],$agentId,$max);
    $headers = array('fecha'=>'Fecha','tipo_llamada'=>'Tipo llamada','id_llamada'=>'ID llamada','numero_cliente'=>'Número','agente'=>'Agente','nombre'=>'Nombre','campo'=>'Campo','valor'=>'Valor');
} elseif ($report === 'transfers') {
    $title = 'Transferencias';
    $rows = $repo->getTransfers($range['from'],$range['to'],$agentId);
    $headers = array('fecha_inicio'=>'Fecha','tipo_llamada'=>'Tipo','numero_cliente'=>'Número','agente'=>'Agente','nombre'=>'Nombre','transferencia'=>'Destino','estado'=>'Estado','uniqueid'=>'ID llamada','linkedid'=>'ID seguimiento');
} else {
    die('Reporte no válido');
}
$filename = preg_replace('/[^a-z0-9_\-]+/i','_',strtolower($title)) . '_' . date('Ymd_His');
if ($format === 'pdf') {
    download_pdf($filename . '.pdf', $title, $pdfHeaders ? $pdfHeaders : $headers, $rows, $meta, $pdfSummary);
}
download_csv($filename . '.csv', $headers, $rows);
