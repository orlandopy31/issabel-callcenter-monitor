<?php
require_once __DIR__ . '/includes/bootstrap.php'; require_permission('after_hours.view');
$repo = new AnalyticsRepository();
$range = range_from_request();
$guardNumber = isset($_GET['guard_number']) ? trim($_GET['guard_number']) : app_config('after_hours.guard_number', '');
$q = isset($_GET['q']) ? trim($_GET['q']) : '';
$perPage = (int)app_config('app.records_per_page', 30);

$allRows = $repo->getAfterHoursGuardCalls($range['from'], $range['to'], $guardNumber, (int)app_config('app.max_export_rows', 30000));
$allRows = filter_rows_by_query($allRows, $q, array('numero_llamante','numero_llamante_original','numero_guardia','fecha','hora','estado','did','destino_cdr','uniqueid','linkedid','lastdata','channel','dstchannel'));
$pagination = paginate_array($allRows, $perPage, 'page');
$rows = $pagination['rows'];
$hourly = $repo->getAfterHoursGuardHourly($range['from'], $range['to'], $guardNumber);

$total = count($allRows);
$answered = 0; $notAnswered = 0; $talk = 0; $duration = 0; $uniqueCallers = array();
$peakHour = '-'; $peakCount = 0;
foreach ($allRows as $r) {
    $isAnswered = strtoupper((string)$r['estado']) === 'ANSWERED' || (int)$r['hablado_seg'] > 0;
    if ($isAnswered) $answered++; else $notAnswered++;
    $talk += (int)$r['hablado_seg'];
    $duration += (int)$r['duracion_seg'];
    if (!empty($r['numero_llamante'])) $uniqueCallers[$r['numero_llamante']] = true;
}
foreach ($hourly as $h) {
    if ((int)$h['llamadas'] > $peakCount) { $peakCount = (int)$h['llamadas']; $peakHour = $h['hora']; }
}
$answeredRate = $total > 0 ? round(($answered / $total) * 100, 2) : 0;
$guardDisplay = normalize_phone($guardNumber);
if ($guardDisplay === '') $guardDisplay = $guardNumber;

$pageTitle='Fuera de horario a guardia';
$pageSubtitle='Llamadas ingresadas fuera de 06:00 a 20:00 de lunes a viernes y desviadas al número de guardia';
include __DIR__ . '/includes/header.php';
?>
<form method="get" class="card filter-card shadow-sm border-0 mb-4">
    <div class="card-body">
        <div class="row g-3 align-items-end">
            <div class="col-12 col-md-2">
                <label class="form-label">Periodo</label>
                <select name="period" class="form-select" onchange="toggleCustomDates(this.value)">
                    <option value="today" <?php echo $range['period']==='today'?'selected':''; ?>>Hoy</option>
                    <option value="yesterday" <?php echo $range['period']==='yesterday'?'selected':''; ?>>Ayer</option>
                    <option value="week" <?php echo $range['period']==='week'?'selected':''; ?>>Semana actual</option>
                    <option value="month" <?php echo $range['period']==='month'?'selected':''; ?>>Mes actual</option>
                    <option value="custom" <?php echo $range['period']==='custom'?'selected':''; ?>>Personalizado</option>
                </select>
            </div>
            <div class="col-6 col-md-2 custom-date">
                <label class="form-label">Desde</label>
                <input type="date" name="from" class="form-control" value="<?php echo e($range['from_date']); ?>">
            </div>
            <div class="col-6 col-md-2 custom-date">
                <label class="form-label">Hasta</label>
                <input type="date" name="to" class="form-control" value="<?php echo e($range['to_date']); ?>">
            </div>
            <div class="col-12 col-md-2">
                <label class="form-label">Número de guardia</label>
                <input type="text" name="guard_number" class="form-control" value="<?php echo e($guardNumber); ?>" placeholder="09XXXXXXXX">
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Buscar número / ID</label>
                <input type="text" name="q" class="form-control" value="<?php echo e($q); ?>" placeholder="Número, DID, uniqueid, linkedid">
            </div>
            <div class="col-12 col-md-1 d-grid">
                <button class="btn btn-primary"><i class="bi bi-search"></i> Ver</button>
            </div>
        </div>
        <div class="text-muted small mt-2">
            <i class="bi bi-calendar2-week"></i> Rango: <?php echo e($range['label']); ?> · Horario normal: <?php echo e(app_config('after_hours.start_time','06:00:00')); ?> a <?php echo e(app_config('after_hours.end_time','20:00:00')); ?>, lunes a viernes.
        </div>
    </div>
</form>
<script>document.addEventListener('DOMContentLoaded', function(){ toggleCustomDates('<?php echo e($range['period']); ?>'); });</script>

<div class="row g-3 mb-4">
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 info"><span class="metric-title">Fuera de horario</span><strong><?php echo e($total); ?></strong><small>Llamadas desviadas a guardia</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 success"><span class="metric-title">Atendidas por guardia</span><strong><?php echo e($answered); ?></strong><small><?php echo e($answeredRate); ?>% de atención</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 warning"><span class="metric-title">No atendidas</span><strong><?php echo e($notAnswered); ?></strong><small>Según CDR / billsec</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 dark"><span class="metric-title">Hora pico</span><strong><?php echo e($peakHour); ?></strong><small><?php echo e($peakCount); ?> llamada(s)</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 info"><span class="metric-title">Números únicos</span><strong><?php echo e(count($uniqueCallers)); ?></strong><small>Llamantes distintos</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 success"><span class="metric-title">Tiempo hablado</span><strong><?php echo e(seconds_to_hms($talk)); ?></strong><small>Conversación con guardia</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 neutral"><span class="metric-title">Guardia consultada</span><strong><?php echo e($guardDisplay); ?></strong><small>Editable en el filtro</small></div></div>
</div>

<div class="row g-4 mb-4">
    <div class="col-xxl-8">
        <div class="card h-100">
            <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-2">
                <span><i class="bi bi-bar-chart-line"></i> Llamadas fuera de horario por hora</span>
                <div class="btn-group">
                    <a class="btn btn-outline-success btn-sm" href="export.php?report=after_hours_guard&format=csv&<?php echo e(build_query_string(array('page'=>null))); ?>"><i class="bi bi-filetype-csv"></i> CSV</a>
                    <a class="btn btn-outline-danger btn-sm" href="export.php?report=after_hours_guard&format=pdf&<?php echo e(build_query_string(array('page'=>null))); ?>"><i class="bi bi-filetype-pdf"></i> PDF</a>
                </div>
            </div>
            <div class="card-body">
                <div style="height:320px"><canvas id="afterHoursChart"></canvas></div>
            </div>
        </div>
    </div>
    <div class="col-xxl-4">
        <div class="card h-100">
            <div class="card-header"><i class="bi bi-clock-history"></i> Resumen por hora</div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-sm table-hover mb-0">
                        <thead><tr><th>Hora</th><th class="text-end">Total</th><th class="text-end">Atend.</th><th class="text-end">No atend.</th></tr></thead>
                        <tbody>
                        <?php foreach ($hourly as $h): if ((int)$h['llamadas'] <= 0) continue; ?>
                            <tr><td class="fw-bold"><?php echo e($h['hora']); ?></td><td class="text-end"><?php echo e($h['llamadas']); ?></td><td class="text-end"><span class="badge badge-ok"><?php echo e($h['contestadas_guardia']); ?></span></td><td class="text-end"><span class="badge badge-warn"><?php echo e($h['no_contestadas']); ?></span></td></tr>
                        <?php endforeach; if ($total === 0): ?>
                            <tr><td colspan="4" class="text-center text-muted py-4">Sin llamadas fuera de horario.</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-header bg-white d-flex flex-wrap justify-content-between align-items-center gap-2">
        <span class="fw-bold"><i class="bi bi-moon-stars"></i> Lista de números desviados a guardia fuera de horario</span>
        <span class="badge bg-light text-dark border">Total filtrado: <?php echo e($pagination['total']); ?></span>
    </div>
    <div class="card-body table-responsive p-0">
        <table class="table table-hover table-sm align-middle table-polished mb-0">
            <thead><tr><th>Fecha</th><th>Hora</th><th>Tipo</th><th>Número llamante</th><th>Original</th><th>Guardia</th><th>DID</th><th>Estado</th><th>Duración</th><th>Hablado</th><th>Destino CDR</th><th>Detalle</th></tr></thead>
            <tbody>
            <?php foreach($rows as $r): ?>
            <tr>
                <td class="text-nowrap"><?php echo e($r['fecha']); ?></td>
                <td class="fw-bold"><?php echo e($r['hora']); ?></td>
                <td><span class="badge badge-soft"><?php echo e($r['tipo_fuera_horario']); ?></span></td>
                <td class="code-small fw-bold"><?php echo e($r['numero_llamante']); ?></td>
                <td class="code-small"><?php echo e($r['numero_llamante_original']); ?></td>
                <td class="code-small"><?php echo e($r['numero_guardia']); ?></td>
                <td class="code-small"><?php echo e($r['did']); ?></td>
                <td><span class="badge" data-status-badge><?php echo e($r['estado']); ?></span></td>
                <td><?php echo e($r['duracion']); ?></td>
                <td><?php echo e($r['hablado']); ?></td>
                <td class="code-small"><?php echo e($r['destino_cdr']); ?></td>
                <td>
                    <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="collapse" data-bs-target="#ah_<?php echo e(md5($r['uniqueid'].$r['linkedid'].$r['fecha'])); ?>"><i class="bi bi-eye"></i> Ver</button>
                </td>
            </tr>
            <tr class="collapse" id="ah_<?php echo e(md5($r['uniqueid'].$r['linkedid'].$r['fecha'])); ?>">
                <td colspan="12" class="bg-light">
                    <div class="row g-2 small">
                        <div class="col-md-4"><b>Canal:</b> <?php echo e($r['channel']); ?></div>
                        <div class="col-md-4"><b>Canal destino:</b> <?php echo e($r['dstchannel']); ?></div>
                        <div class="col-md-4"><b>Contexto:</b> <?php echo e($r['dcontext']); ?></div>
                        <div class="col-md-4"><b>Última app:</b> <?php echo e($r['lastapp']); ?></div>
                        <div class="col-md-8"><b>Lastdata:</b> <?php echo e($r['lastdata']); ?></div>
                        <div class="col-md-4"><b>UniqueID:</b> <?php echo e($r['uniqueid']); ?></div>
                        <div class="col-md-4"><b>LinkedID:</b> <?php echo e($r['linkedid']); ?></div>
                        <div class="col-md-4"><b>Tramos:</b> <?php echo e($r['tramos']); ?></div>
                        <div class="col-12"><b>Recorrido:</b> <?php echo e($r['recorrido']); ?></div>
                    </div>
                </td>
            </tr>
            <?php endforeach; if(empty($rows)): ?>
            <tr><td colspan="12" class="text-center py-4 text-muted">No se encontraron llamadas fuera de horario desviadas al número de guardia seleccionado.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php render_pagination($pagination, 'page'); ?>

<script>
document.addEventListener('DOMContentLoaded', function(){
    var labels = <?php echo json_encode(array_column($hourly, 'hora')); ?>;
    var totals = <?php echo json_encode(array_map('intval', array_column($hourly, 'llamadas'))); ?>;
    var answered = <?php echo json_encode(array_map('intval', array_column($hourly, 'contestadas_guardia'))); ?>;
    var notAnswered = <?php echo json_encode(array_map('intval', array_column($hourly, 'no_contestadas'))); ?>;
    safeChart('afterHoursChart', {
        type: 'bar',
        data: { labels: labels, datasets: [
            { label: 'Total fuera de horario', data: totals },
            { label: 'Atendidas guardia', data: answered },
            { label: 'No atendidas', data: notAnswered }
        ] },
        options: { plugins: { legend: { position: 'bottom' } } }
    });
});
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
