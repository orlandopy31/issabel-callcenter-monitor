# Wallboard profesional - live.php

## Objetivo
La pantalla `live.php` fue rediseñada para utilizarse como tablero compartido en TV o monitor grande.

## Principales cambios
- Vista de tarjetas por agente en lugar de tabla técnica.
- Estados con identificación visual clara: Disponible, En llamada, En pausa, Timbrando y Desconectado.
- Tiempo principal contextual por agente:
  - llamada/timbrado: duración actual;
  - pausa: duración de la pausa y motivo;
  - disponible: duración de la sesión;
  - desconectado: fuera de sesión.
- Resumen superior con conectados, disponibles, en llamada, en pausa, timbrando y desconectados.
- Reloj en vivo y hora de la última actualización.
- Refresco automático cada 5 segundos.
- Modo TV que oculta el menú lateral y la barra superior.
- No muestra número del cliente ni canal AMI en la pantalla compartida.
- Conserva el último estado recibido si una actualización falla.

## Acceso recomendado para la TV
Crear un usuario específico, por ejemplo `wallboard`, y asignarle solamente:

- `live.view` - Monitoreo en tiempo real.

No asignar otros permisos.

El usuario podrá entrar a `live.php`, pero las demás opciones quedarán protegidas por el sistema de permisos.

## Modo TV
Hay dos formas de activarlo:

1. Entrar a `live.php` y pulsar **Modo TV**.
2. Abrir directamente:

   `live.php?tv=1`

La segunda opción carga directamente el diseño sin menú y es útil para dejar una PC conectada permanentemente a una TV.

> El navegador puede exigir una acción manual para activar pantalla completa real. Aun si bloquea fullscreen, `?tv=1` mantiene el diseño de pared sin navegación.

## Instalación rápida
Si ya tiene instalada la versión con usuarios y permisos, solo necesita reemplazar:

`live.php`

No hay cambios de base de datos ni de API para esta mejora.

Se recomienda conservar una copia del archivo anterior:

```bash
cd /ruta/del/panel
cp live.php live.php.bak_$(date +%F_%H%M)
```

Luego copiar el nuevo `live.php` y verificar:

```bash
php -l live.php
```

