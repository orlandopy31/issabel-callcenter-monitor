<?php
require_once dirname(__DIR__) . '/includes/bootstrap.php';
require_api_permission('supervision.view');

$ami = new AmiClient();
$active = $ami->activeSpySessions();
$rows = (!empty($active['ok']) && isset($active['rows']) && is_array($active['rows'])) ? $active['rows'] : array();

$out = array();
foreach ($rows as $sp) {
    $out[] = array(
        'channel' => isset($sp['channel']) ? $sp['channel'] : '',
        'listener_extension' => isset($sp['listener_extension']) ? $sp['listener_extension'] : '',
        'target' => isset($sp['target']) ? $sp['target'] : '',
        'target_extension' => isset($sp['target_extension']) ? $sp['target_extension'] : '',
        'mode_label' => isset($sp['mode_label']) ? $sp['mode_label'] : 'Escucha',
        'duration' => isset($sp['duration']) ? $sp['duration'] : '00:00:00',
        'duration_seconds' => isset($sp['duration_seconds']) ? (int)$sp['duration_seconds'] : 0,
        'target_active' => isset($sp['target_active']) ? $sp['target_active'] : 'Sí',
    );
}

json_response(array(
    'ok' => !empty($active['ok']),
    'message' => isset($active['message']) ? $active['message'] : '',
    'count' => count($out),
    'rows' => $out,
    'updated_at' => date('d/m/Y H:i:s')
));
