<?php
require_once dirname(__DIR__) . '/includes/bootstrap.php';
require_api_permission('live.view');
if (isset($_GET['manual'])) {
    $cache = dirname(__DIR__) . '/cache/ami_agents_snapshot.json';
    if (is_file($cache)) @unlink($cache);
}
$repo = new ReportRepository();
$ami = new AmiClient();
$runtime = $repo->getCurrentAgentRuntime();
$data = $ami->cachedAgentOperationalSnapshot($runtime);
json_response($data);
