<?php
require_once dirname(__DIR__) . '/includes/bootstrap.php';
require_api_permission('supervision.control');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(array('ok' => false, 'message' => 'Método no permitido'), 405);
}

function switch_param($keys, $default = '') {
    static $payload = null;
    if ($payload === null) {
        $payload = array();
        $raw = file_get_contents('php://input');
        if (is_string($raw) && trim($raw) !== '') {
            $json = json_decode($raw, true);
            if (is_array($json)) {
                $payload = array_merge($payload, $json);
            } else {
                $tmp = array();
                parse_str($raw, $tmp);
                if (is_array($tmp)) $payload = array_merge($payload, $tmp);
            }
        }
    }
    foreach ((array)$keys as $key) {
        if (isset($_POST[$key]) && trim((string)$_POST[$key]) !== '') return trim((string)$_POST[$key]);
        if (isset($_GET[$key]) && trim((string)$_GET[$key]) !== '') return trim((string)$_GET[$key]);
        if (isset($payload[$key]) && trim((string)$payload[$key]) !== '') return trim((string)$payload[$key]);
    }
    return $default;
}

$csrf = switch_param(array('csrf'), '');
if (!csrf_check($csrf)) {
    json_response(array('ok' => false, 'message' => 'Token de seguridad inválido. Recargue la página.'), 419);
}

$channel = switch_param(array('spy_channel', 'channel'), '');
$mode = strtolower(switch_param(array('switch_mode', 'mode'), 'listen'));

$ami = new AmiClient();
$result = $ami->switchChanSpyMode($channel, $mode);
auth_audit('supervision.switch_mode_api', 'Canal=' . $channel . ' modo=' . $mode . ' resultado=' . (!empty($result['ok']) ? 'ok' : 'error'));
json_response($result, !empty($result['ok']) ? 200 : 400);
