<?php
require_once dirname(__DIR__) . '/includes/bootstrap.php';
require_api_permission('supervision.view');

$repo = new ReportRepository();
$ami = new AmiClient();

if (!empty($_GET['force'])) {
    $cache = dirname(__DIR__) . '/cache/ami_agents_snapshot.json';
    if (is_file($cache)) @unlink($cache);
}

$runtime = $repo->getCurrentAgentRuntime();
$data = $ami->cachedAgentOperationalSnapshot($runtime);

$agents = isset($data['agents']) && is_array($data['agents']) ? $data['agents'] : array();
$rows = array();
foreach ($agents as $a) {
    if (!isset($a['llamada_actual']) || $a['llamada_actual'] !== 'Sí') continue;
    $tech = strtoupper(isset($a['tipo']) ? (string)$a['tipo'] : 'PJSIP');
    $channel = strtoupper(isset($a['canal_actual']) ? (string)$a['canal_actual'] : '');
    if (strpos($channel, 'PJSIP/') === 0) $tech = 'PJSIP';
    elseif (strpos($channel, 'SIP/') === 0) $tech = 'SIP';
    elseif (strpos($channel, 'IAX2/') === 0) $tech = 'IAX2';
    if (!in_array($tech, array('PJSIP','SIP','IAX2'), true)) $tech = 'PJSIP';
    $ext = !empty($a['login_extension']) ? $a['login_extension'] : (isset($a['agente']) ? $a['agente'] : '');
    $rows[] = array(
        'id_agent' => isset($a['id_agent']) ? $a['id_agent'] : (isset($a['id']) ? $a['id'] : '0'),
        'agente' => isset($a['agente']) ? $a['agente'] : '',
        'nombre' => isset($a['nombre']) ? $a['nombre'] : '',
        'tipo' => isset($a['tipo']) ? $a['tipo'] : '',
        'tech' => $tech,
        'extension' => $ext,
        'estado' => isset($a['estado_operativo']) ? $a['estado_operativo'] : 'En llamada',
        'tipo_llamada' => isset($a['tipo_llamada_actual']) ? $a['tipo_llamada_actual'] : '',
        'numero_actual' => isset($a['numero_actual']) ? $a['numero_actual'] : '',
        'duracion' => isset($a['duracion_llamada_actual']) ? $a['duracion_llamada_actual'] : '00:00:00',
        'canal' => isset($a['canal_actual']) ? $a['canal_actual'] : '',
    );
}

json_response(array(
    'ok' => true,
    'connected' => !empty($data['connected']),
    'error' => isset($data['error']) ? $data['error'] : '',
    'summary' => isset($data['summary']) ? $data['summary'] : array(),
    'rows' => $rows,
    'updated_at' => isset($data['updated_at']) ? $data['updated_at'] : date('d/m/Y H:i:s'),
    'cache_status' => isset($data['cache_status']) ? $data['cache_status'] : '',
    'refresh_seconds' => (int)app_config('supervision.refresh_seconds', 15),
));
