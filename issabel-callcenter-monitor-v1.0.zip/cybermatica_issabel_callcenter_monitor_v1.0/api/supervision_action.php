<?php
require_once dirname(__DIR__) . '/includes/bootstrap.php';
require_api_permission('supervision.control');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(array('ok' => false, 'message' => 'Método no permitido'), 405);
}


function request_payload_values() {
    static $payload = null;
    if ($payload !== null) return $payload;
    $payload = array();
    $raw = file_get_contents('php://input');
    if (is_string($raw) && $raw !== '') {
        $json = json_decode($raw, true);
        if (is_array($json)) {
            $payload = array_merge($payload, $json);
        } else {
            $tmp = array();
            parse_str($raw, $tmp);
            if (is_array($tmp)) $payload = array_merge($payload, $tmp);
        }
    }
    return $payload;
}

function post_first_value($keys, $default = '') {
    $payload = request_payload_values();
    foreach ($keys as $key) {
        if (isset($_POST[$key]) && trim((string)$_POST[$key]) !== '') return $_POST[$key];
        if (isset($_GET[$key]) && trim((string)$_GET[$key]) !== '') return $_GET[$key];
        if (isset($payload[$key]) && trim((string)$payload[$key]) !== '') return $payload[$key];
    }
    // v35: cabeceras de respaldo para evitar falso campo vacío.
    $headerMap = array(
        'HTTP_X_SUPERVISOR_EXTENSION',
        'HTTP_X_LISTENER_EXTENSION',
        'HTTP_X_MONITOR_EXTENSION'
    );
    foreach ($headerMap as $h) {
        if (isset($_SERVER[$h]) && trim((string)$_SERVER[$h]) !== '') return $_SERVER[$h];
    }
    return $default;
}

$csrf = post_first_value(array('csrf'), '');
if (!csrf_check($csrf)) {
    json_response(array('ok' => false, 'message' => 'Token de seguridad inválido. Recargue la página.'), 419);
}

$agentId = isset($_POST['agent_id']) ? (int)$_POST['agent_id'] : 0;
$supervisorTech = post_first_value(array('supervisor_tech', 'listener_tech', 'monitor_tech', 'spy_tech'), 'LOCAL');
$supervisorExtension = post_first_value(array(
    'listen_ext',
    'supervisor_extension',
    'supervisor_extension_final',
    'extension_que_escuchara',
    'listener_extension',
    'monitor_extension',
    'spy_extension',
    'extension_supervisor',
    'extension_listener',
    'extension_monitor',
    'listen_extension',
    'escucha_extension',
    'interno_supervisor',
    'interno_escucha',
    'extension',
    'interno',
    'supervisor'
), '');
$mode = post_first_value(array('mode', 'spy_mode', 'supervision_mode'), 'listen');
$targetMode = post_first_value(array('target_mode'), 'extension'); // extension | exact
$targetTech = post_first_value(array('target_tech', 'agent_tech'), 'PJSIP');
$targetExtension = post_first_value(array('target_ext', 'target_extension', 'agent_extension', 'extension_agent', 'interno_agente'), '');
$targetChannel = post_first_value(array('target_channel', 'agent_channel'), '');


function parse_endpoint_extension_input($value, $selectedTech) {
    $raw = trim((string)$value);
    $tech = strtoupper(trim((string)$selectedTech));
    if (!in_array($tech, array('PJSIP','SIP','IAX2','Agent','LOCAL'), true)) {
        $tech = 'PJSIP';
    }

    // Acepta entradas como: 102, PJSIP/102, PJSIP102, SIP/102, SIP102, IAX2/102, IAX2102.
    // Esto corrige el error observado en CLI: ChanSpy(PJSIP/PJSIP102,q).
    $patterns = array(
        '/^(PJSIP|SIP|IAX2|AGENT|LOCAL)\s*[\\\/\:\-_ ]+\s*(.+)$/i',
        '/^(PJSIP|SIP)(\d.*)$/i',
        '/^(IAX2)(\d.*)$/i',
        '/^(AGENT)(\d.*)$/i',
        '/^(LOCAL)(\d.*)$/i'
    );
    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $raw, $m)) {
            $detected = strtoupper($m[1]);
            if ($detected === 'AGENT') $detected = 'Agent';
            if ($detected === 'LOCAL') $detected = 'LOCAL';
            $tech = $detected;
            $raw = isset($m[2]) ? $m[2] : '';
            break;
        }
    }

    $ext = preg_replace('/@.*$/', '', $raw);
    $ext = preg_replace('/[^0-9A-Za-z_\-]/', '', (string)$ext);
    // Si por algún motivo vuelve a quedar prefijada, limpiar otra vez.
    $ext = preg_replace('/^(PJSIP|SIP|IAX2|Agent|LOCAL)(?=\d)/i', '', $ext);

    return array($tech, $ext);
}

list($targetTech, $targetExtension) = parse_endpoint_extension_input($targetExtension, $targetTech);
$supervisorExtension = preg_replace('/@.*$/', '', (string)$supervisorExtension);
$supervisorExtension = preg_replace('/^(PJSIP|SIP|IAX2|LOCAL|Agent)\s*[\\\/\:\-_ ]*/i', '', $supervisorExtension);
$supervisorExtension = preg_replace('/^(PJSIP|SIP|IAX2|LOCAL|Agent)(?=\d)/i', '', $supervisorExtension);
$supervisorExtension = preg_replace('/[^0-9A-Za-z_\-]/', '', $supervisorExtension);

if ($targetExtension === '' && $targetMode !== 'exact') {
    json_response(array('ok' => false, 'message' => 'Debe indicar la extensión/agente a supervisar. Ejemplo: 102.'), 400);
}
if (!in_array($targetTech, array('PJSIP','SIP','IAX2','Agent','LOCAL'), true)) {
    $targetTech = 'PJSIP';
}

$ami = new AmiClient();

// v32: estilo call center/VICIdial. No dependemos de que el panel detecte al agente en línea.
// El supervisor puede intentar monitorear una extensión/agente manualmente por prefijo de canal.
if ($targetMode === 'exact' && trim((string)$targetChannel) !== '') {
    $targetPrefix = $ami->spyTargetExactChannel($targetChannel);
} else {
    $targetPrefix = $ami->spyTargetByExtension('', $targetTech, $targetExtension);
}

if ($targetPrefix === '') {
    json_response(array('ok' => false, 'message' => 'No se pudo construir el destino de supervisión. Verifique tecnología y extensión del agente.'), 400);
}

if (preg_match('/\/(Trunk|troncal|gateway|granstream)/i', $targetPrefix)) {
    json_response(array('ok' => false, 'message' => 'Se detectó un canal de troncal para supervisar (' . $targetPrefix . '). Debe supervisar la extensión del agente, por ejemplo PJSIP/102, SIP/102 o IAX2/102.'), 409);
}

$labelParts = array();
if ($agentId > 0) $labelParts[] = 'agent_id=' . $agentId;
$labelParts[] = 'target=' . $targetPrefix;
$labelParts[] = 'extension=' . $targetExtension;
$label = implode(' ', $labelParts);

$result = $ami->originateChanSpy($supervisorTech, $supervisorExtension, $targetPrefix, $mode, $label);
if (!$result['ok'] && stripos($result['message'], 'extensión que escuchará') !== false) {
    $receivedKeys = array_unique(array_merge(array_keys($_POST), array_keys($_GET), array_keys(request_payload_values())));
    $result['message'] .= ' Campo recibido vacío. Complete el campo “Extensión que escuchará” con solo el número, por ejemplo 3, 1000 o 110. v36 recomienda usar supervise.php con POST clásico; el API también acepta listen_ext y target_ext. Campos recibidos: ' . implode(', ', $receivedKeys) . '.';
}
auth_audit('supervision.start_api', 'Supervisor=' . $supervisorExtension . ' target=' . $targetPrefix . ' modo=' . $mode . ' resultado=' . (!empty($result['ok']) ? 'ok' : 'error'));
json_response($result, $result['ok'] ? 200 : 400);
