<?php
require_once __DIR__ . '/includes/bootstrap.php'; require_permission('inbound_comparison.view');
$repo = new AnalyticsRepository();
$slaSeconds = report_sla_seconds();
$slaTarget = report_sla_target_pct();
$range = range_from_request();
$bucket = isset($_GET['bucket']) ? $_GET['bucket'] : 'day';
if (!in_array($bucket, array('hour','day','week','month'), true)) $bucket = 'day';
$queue = isset($_GET['queue']) ? trim((string)$_GET['queue']) : '';
$queues = $repo->getInboundQueueList($range['from'], $range['to']);
$perPage = (int)app_config('app.records_per_page', 30);
$allRows = $repo->getInboundQueueComparison($range['from'], $range['to'], $bucket, $queue !== '' ? $queue : null);
$pg = paginate_array($allRows, $perPage, 'page');
$rows = $pg['rows'];

$tot = array('ofrecidas'=>0,'contestadas'=>0,'abandonadas'=>0,'devueltas'=>0,'pendientes'=>0,'dentro_sla'=>0,'gestionadas_ajustadas'=>0,'hablado_seg'=>0,'espera_promedio_base'=>0,'espera_promedio_count'=>0);
foreach ($allRows as $r) {
    $tot['ofrecidas'] += (int)$r['ofrecidas'];
    $tot['contestadas'] += (int)$r['contestadas'];
    $tot['abandonadas'] += (int)$r['abandonadas'];
    $tot['devueltas'] += (int)$r['devueltas'];
    $tot['pendientes'] += (int)$r['pendientes'];
    $tot['dentro_sla'] += (int)$r['dentro_sla'];
    $tot['gestionadas_ajustadas'] += (int)$r['gestionadas_ajustadas'];
    $tot['hablado_seg'] += (int)$r['hablado_seg'];
    if ((int)$r['ofrecidas'] > 0) {
        $tot['espera_promedio_base'] += ((int)$r['espera_promedio_seg'] * (int)$r['ofrecidas']);
        $tot['espera_promedio_count'] += (int)$r['ofrecidas'];
    }
}
$rate = function($n,$d) { return $d > 0 ? number_format(($n/$d)*100, 2, '.', '') . '%' : '0.00%'; };
$avgWait = $tot['espera_promedio_count'] > 0 ? (int)round($tot['espera_promedio_base'] / $tot['espera_promedio_count']) : 0;

$chartRows = array_reverse($allRows);
$chartLabels = array(); $chartAnswered = array(); $chartPending = array(); $chartReturned = array(); $chartAbandoned = array();
foreach ($chartRows as $r) {
    $label = $r['periodo'] . ($r['cola'] !== '' ? ' / ' . $r['cola'] : '');
    $chartLabels[] = $label;
    $chartAnswered[] = (int)$r['contestadas'];
    $chartAbandoned[] = (int)$r['abandonadas'];
    $chartReturned[] = (int)$r['devueltas'];
    $chartPending[] = (int)$r['pendientes'];
}
$pageTitle = 'Comparativo de llamadas entrantes';
$pageSubtitle = 'Cola de atención: contestadas, abandonadas, devueltas y pendientes en una sola vista';
include __DIR__ . '/includes/header.php';
?>
<form method="get" class="card filter-card shadow-sm border-0 mb-4">
    <div class="card-body">
        <div class="row g-3 align-items-end">
            <div class="col-12 col-md-2">
                <label for="period" class="form-label">Periodo</label>
                <select id="period" name="period" class="form-select" onchange="toggleCustomDates(this.value)">
                    <option value="today" <?php echo $range['period']==='today'?'selected':''; ?>>Hoy</option>
                    <option value="yesterday" <?php echo $range['period']==='yesterday'?'selected':''; ?>>Ayer</option>
                    <option value="week" <?php echo $range['period']==='week'?'selected':''; ?>>Semana actual</option>
                    <option value="month" <?php echo $range['period']==='month'?'selected':''; ?>>Mes actual</option>
                    <option value="custom" <?php echo $range['period']==='custom'?'selected':''; ?>>Personalizado</option>
                </select>
            </div>
            <div class="col-6 col-md-2 custom-date">
                <label for="from" class="form-label">Desde</label>
                <input id="from" type="date" name="from" class="form-control" value="<?php echo e($range['from_date']); ?>">
            </div>
            <div class="col-6 col-md-2 custom-date">
                <label for="to" class="form-label">Hasta</label>
                <input id="to" type="date" name="to" class="form-control" value="<?php echo e($range['to_date']); ?>">
            </div>
            <div class="col-12 col-md-2">
                <label for="bucket" class="form-label">Agrupar por</label>
                <select id="bucket" name="bucket" class="form-select">
                    <option value="hour" <?php echo $bucket==='hour'?'selected':''; ?>>Hora</option>
                    <option value="day" <?php echo $bucket==='day'?'selected':''; ?>>Día</option>
                    <option value="week" <?php echo $bucket==='week'?'selected':''; ?>>Semana</option>
                    <option value="month" <?php echo $bucket==='month'?'selected':''; ?>>Mes</option>
                </select>
            </div>
            <div class="col-12 col-md-2">
                <label for="queue" class="form-label">Cola</label>
                <select id="queue" name="queue" class="form-select">
                    <option value="" <?php echo $queue===''?'selected':''; ?>>Todas las colas</option>
                    <?php foreach ($queues as $q): ?>
                        <option value="<?php echo e($q); ?>" <?php echo $queue===(string)$q?'selected':''; ?>><?php echo e($q); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-12 col-md-2 d-grid">
                <button class="btn btn-primary"><i class="bi bi-search"></i> Aplicar</button>
            </div>
        </div>
        <div class="text-muted small mt-2"><i class="bi bi-calendar2-week"></i> Rango consultado: <?php echo e($range['label']); ?></div>
    </div>
</form>
<script>document.addEventListener('DOMContentLoaded', function(){ toggleCustomDates('<?php echo e($range['period']); ?>'); });</script>

<div class="row g-3 mb-4">
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 info"><span class="metric-title">Llamadas ofrecidas</span><strong><?php echo e($tot['ofrecidas']); ?></strong><small>Total que ingresó a la cola</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 success"><span class="metric-title">Contestadas</span><strong><?php echo e($tot['contestadas']); ?></strong><small><?php echo e($rate($tot['contestadas'], $tot['ofrecidas'])); ?> de atención bruta</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 danger"><span class="metric-title">Abandonadas</span><strong><?php echo e($tot['abandonadas']); ?></strong><small><?php echo e($rate($tot['abandonadas'], $tot['ofrecidas'])); ?> de abandono bruto</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 success"><span class="metric-title">Devueltas</span><strong><?php echo e($tot['devueltas']); ?></strong><small><?php echo e($rate($tot['devueltas'], $tot['abandonadas'])); ?> de recuperación</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 warning"><span class="metric-title">Pendientes</span><strong><?php echo e($tot['pendientes']); ?></strong><small>Abandonadas aún no devueltas</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 info"><span class="metric-title">Eficiencia ajustada</span><strong><?php echo e($rate($tot['gestionadas_ajustadas'], $tot['ofrecidas'])); ?></strong><small>Contestadas + devueltas</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 info"><span class="metric-title">SLA</span><strong><?php echo e($rate($tot['dentro_sla'], $tot['ofrecidas'])); ?></strong><small>Meta <?php echo e(rtrim(rtrim(number_format($slaTarget,2,'.',''),'0'),'.')); ?>% en <?php echo e($slaSeconds); ?> segundos</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11"><span class="metric-title">Espera promedio</span><strong><?php echo e(seconds_to_hms($avgWait)); ?></strong><small>Promedio ponderado por ofrecidas</small></div></div>
</div>

<div class="card mb-4">
    <div class="card-header d-flex flex-wrap justify-content-between gap-2 align-items-center">
        <span><i class="bi bi-bar-chart-line"></i> Comparativo visual</span>
        <div class="d-flex gap-2">
            <a class="btn btn-sm btn-outline-danger" href="export.php?report=inbound_queue_comparison&format=pdf&<?php echo e(build_query_string(array('page'=>null))); ?>"><i class="bi bi-filetype-pdf"></i> PDF horizontal</a>
            <a class="btn btn-sm btn-outline-success" href="export.php?report=inbound_queue_comparison&format=csv&<?php echo e(build_query_string(array('page'=>null))); ?>"><i class="bi bi-filetype-csv"></i> CSV</a>
        </div>
    </div>
    <div class="card-body">
        <div style="height:360px"><canvas id="inboundComparisonChart"></canvas></div>
    </div>
</div>

<div class="card">
    <div class="card-header"><i class="bi bi-table"></i> Detalle comparativo de la cola</div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover table-polished align-middle mb-0">
                <thead><tr><th>Periodo</th><th>Cola</th><th class="text-end">Ofrecidas</th><th class="text-end">Contestadas</th><th class="text-end">Abandonadas</th><th class="text-end">Devueltas</th><th class="text-end">Pendientes</th><th class="text-end">Atención</th><th class="text-end">SLA</th><th class="text-center">Cumple</th><th class="text-end">Efic. ajustada</th><th class="text-end">Dev.%</th><th class="text-end">Aband. neto</th><th>Espera prom.</th><th>Espera máx.</th></tr></thead>
                <tbody>
                <?php foreach ($rows as $r): ?>
                    <tr>
                        <td class="fw-bold"><?php echo e($r['periodo']); ?></td>
                        <td><?php echo e($r['cola']); ?></td>
                        <td class="text-end"><?php echo e($r['ofrecidas']); ?></td>
                        <td class="text-end"><span class="badge badge-ok"><?php echo e($r['contestadas']); ?></span></td>
                        <td class="text-end"><span class="badge badge-danger-soft"><?php echo e($r['abandonadas']); ?></span></td>
                        <td class="text-end"><span class="badge badge-ok"><?php echo e($r['devueltas']); ?></span></td>
                        <td class="text-end"><span class="badge badge-warn"><?php echo e($r['pendientes']); ?></span></td>
                        <td class="text-end"><?php echo e($r['tasa_contestacion_pct']); ?></td>
                        <td class="text-end"><span class="badge <?php echo (isset($r['cumple_sla']) && $r['cumple_sla']==='CUMPLE') ? 'text-bg-success' : 'text-bg-danger'; ?>"><?php echo e($r['nivel_servicio_pct']); ?></span></td>
                        <td class="text-center"><span class="badge <?php echo (isset($r['cumple_sla']) && $r['cumple_sla']==='CUMPLE') ? 'text-bg-success' : 'text-bg-danger'; ?>"><?php echo e(isset($r['cumple_sla'])?$r['cumple_sla']:'NO CUMPLE'); ?></span></td>
                        <td class="text-end"><strong><?php echo e($r['eficiencia_ajustada_pct']); ?></strong></td>
                        <td class="text-end"><?php echo e($r['nivel_devolucion_pct']); ?></td>
                        <td class="text-end"><?php echo e($r['tasa_pendiente_pct']); ?></td>
                        <td><?php echo e($r['espera_promedio']); ?></td>
                        <td><?php echo e($r['espera_maxima']); ?></td>
                    </tr>
                <?php endforeach; if (empty($rows)): ?>
                    <tr><td colspan="15" class="text-center text-muted py-4">Sin datos de llamadas entrantes para el rango seleccionado.</td></tr>
                <?php endif; ?>
                </tbody>
                <tfoot><tr class="fw-bold"><td colspan="2">TOTAL GENERAL</td><td class="text-end"><?php echo e($tot['ofrecidas']); ?></td><td class="text-end"><?php echo e($tot['contestadas']); ?></td><td class="text-end"><?php echo e($tot['abandonadas']); ?></td><td class="text-end"><?php echo e($tot['devueltas']); ?></td><td class="text-end"><?php echo e($tot['pendientes']); ?></td><td class="text-end"><?php echo e($rate($tot['contestadas'],$tot['ofrecidas'])); ?></td><td class="text-end"><?php echo e($rate($tot['dentro_sla'],$tot['ofrecidas'])); ?></td><td class="text-center"><?php $slaTotalNum=$tot['ofrecidas']>0?($tot['dentro_sla']/$tot['ofrecidas']*100):0; ?><span class="badge <?php echo $slaTotalNum >= $slaTarget ? 'text-bg-success':'text-bg-danger'; ?>"><?php echo $slaTotalNum >= $slaTarget ? 'CUMPLE':'NO CUMPLE'; ?></span></td><td class="text-end"><?php echo e($rate($tot['gestionadas_ajustadas'],$tot['ofrecidas'])); ?></td><td class="text-end"><?php echo e($rate($tot['devueltas'],$tot['abandonadas'])); ?></td><td class="text-end"><?php echo e($rate($tot['pendientes'],$tot['ofrecidas'])); ?></td><td><?php echo e(seconds_to_hms($avgWait)); ?></td><td></td></tr></tfoot>
            </table>
        </div>
    </div>
</div>
<?php render_pagination($pg, 'page'); ?>

<script>
document.addEventListener('DOMContentLoaded', function(){
    safeChart('inboundComparisonChart', {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($chartLabels, JSON_UNESCAPED_UNICODE); ?>,
            datasets: [
                {label:'Contestadas', data: <?php echo json_encode($chartAnswered); ?>},
                {label:'Abandonadas', data: <?php echo json_encode($chartAbandoned); ?>},
                {label:'Devueltas', data: <?php echo json_encode($chartReturned); ?>},
                {label:'Pendientes', data: <?php echo json_encode($chartPending); ?>}
            ]
        },
        options: {plugins:{legend:{position:'bottom'}}, scales:{x:{ticks:{maxRotation:60,minRotation:0}}, y:{beginAtZero:true}}}
    });
});
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
