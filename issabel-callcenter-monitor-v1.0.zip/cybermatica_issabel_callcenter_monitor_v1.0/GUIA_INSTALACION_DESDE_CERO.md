# Guía completa de instalación desde cero
## Cybermatica Call Center Monitor v1.0 para Issabel

Esta guía asume que el panel se instalará **en el mismo servidor donde funcionan Issabel y Asterisk**.

---

## 1. Qué instala el paquete

El panel NO reemplaza Issabel, Asterisk ni el módulo Call Center. Trabaja sobre la información ya registrada por Issabel.

Bases utilizadas:

- `call_center`: agentes, auditoría, pausas, campañas y llamadas del módulo Call Center.
- `asteriskcdrdb`: CDR/CEL de Asterisk.
- `asterisk`: información auxiliar de la PBX.
- `callcenter_panel`: base exclusiva del nuevo panel para usuarios, permisos, SLA, configuración y auditoría.

La aplicación usa un usuario MySQL propio con:

- SOLO lectura sobre `call_center`, `asteriskcdrdb` y `asterisk`;
- lectura/escritura sobre `callcenter_panel`.

No es necesario que PHP utilice `root`.

---

## 2. Funciones incluidas

### Operación

- Dashboard ejecutivo.
- Monitoreo en tiempo real.
- Wallboard TV.
- Productividad.
- Actividad por agente.
- Campañas salientes.
- Seguimiento y trazabilidad de llamadas.
- Llamadas manuales/directas.

### Supervisión

- Escucha.
- Susurro.
- Barge/conferencia.
- Control de acceso independiente para ver y para ejecutar supervisión.

### Control de gestión

- Pausas.
- Sesiones.
- Abandonadas.
- Devoluciones.
- SLA / nivel de servicio.
- Comparativo entrantes.
- Fuera de horario.
- Formularios.

### Administración

- Usuarios.
- Permisos granulares.
- Auditoría.
- SLA configurable.

### Reportes

- CSV.
- PDF.
- Grabaciones cuando el usuario tenga permiso.

---

## 3. Requisitos

En el servidor ejecute:

```bash
php -v
php -m | egrep -i 'PDO|pdo_mysql|json'
mysql --version
asterisk -V
systemctl status httpd --no-pager
```

Se requiere PHP 7.2 o superior y la extensión PDO MySQL.

Si falta PDO MySQL en Rocky Linux / Issabel:

```bash
dnf install -y php-mysqlnd
systemctl restart php-fpm 2>/dev/null || true
systemctl restart httpd
```

Antes de modificar un servidor de producción realice backup de Issabel y de las bases de datos.

---

# PARTE A - INSTALACIÓN AUTOMÁTICA

## 4. Subir y descomprimir

Copie el ZIP al servidor, por ejemplo a `/root`.

```bash
cd /root
unzip cybermatica_issabel_callcenter_monitor_v1.0.zip
cd cybermatica_issabel_callcenter_monitor_v1.0
```

## 5. Ejecutar el instalador

```bash
sudo bash install.sh
```

El instalador preguntará:

1. directorio web;
2. nombre de la empresa/call center;
3. zona horaria;
4. usuario administrador de MariaDB/MySQL;
5. contraseña de MariaDB/MySQL;
6. usuario administrador del panel;
7. nombre del administrador;
8. contraseña inicial del administrador.

Recomendado:

```text
Directorio: /var/www/html/callcenter-panel
Zona horaria: America/Asuncion
Administrador BD: root
Usuario del panel: admin
```

La contraseña del panel debe tener al menos 10 caracteres.

## 6. Qué hace exactamente install.sh

### 6.1 Verifica Issabel

Comprueba que existan:

```text
call_center.agent
call_center.audit
call_center.call_entry
asteriskcdrdb.cdr
```

Si alguna no existe, el instalador se detiene sin instalar el panel.

### 6.2 Crea la base del panel

Ejecuta:

```text
sql/usuarios_permisos.sql
```

Esto crea:

```text
callcenter_panel.users
callcenter_panel.permissions
callcenter_panel.user_permissions
callcenter_panel.system_settings
callcenter_panel.audit_log
```

### 6.3 Crea un usuario técnico MySQL

Por defecto:

```text
ccpanel@localhost
```

Su contraseña se genera aleatoriamente.

Permisos equivalentes:

```sql
GRANT SELECT, SHOW VIEW ON call_center.* TO 'ccpanel'@'localhost';
GRANT SELECT, SHOW VIEW ON asteriskcdrdb.* TO 'ccpanel'@'localhost';
GRANT SELECT, SHOW VIEW ON asterisk.* TO 'ccpanel'@'localhost';
GRANT SELECT, INSERT, UPDATE, DELETE ON callcenter_panel.* TO 'ccpanel'@'localhost';
```

### 6.4 Crea el administrador

La contraseña se guarda usando `password_hash()` de PHP. No queda en texto plano en la tabla `users`.

### 6.5 Configura AMI

El instalador crea un usuario local en:

```text
/etc/asterisk/manager_custom.conf
```

Con acceso restringido a `127.0.0.1`.

El bloque generado es conceptualmente:

```ini
[ccpanel_monitor]
secret = CLAVE_GENERADA
deny = 0.0.0.0/0.0.0.0
permit = 127.0.0.1/255.255.255.255
read = system,call
write = call,originate
```

El panel utiliza AMI para consultar canales actuales y para las acciones de supervisión.

El instalador ejecuta:

```bash
asterisk -rx "manager reload"
```

No reinicia Asterisk.

### 6.6 Instala el panel

Ruta por defecto:

```text
/var/www/html/callcenter-panel
```

El código queda propiedad de `root:apache`, y solamente `cache/` queda escribible por Apache.

### 6.7 SELinux

Cuando SELinux está activo, el instalador habilita la conexión saliente necesaria desde Apache y asigna a `cache/` un contexto escribible.

---

## 7. Acceso inicial

Abra:

```text
http://IP_DEL_ISSABEL/callcenter-panel/
```

Ingrese con el usuario y contraseña creados durante la instalación.

---

## 8. Crear usuario para una TV / Wallboard

Ingrese como administrador:

```text
Administración > Usuarios y permisos
```

Cree por ejemplo:

```text
Usuario: wallboard
Nombre: Pantalla Call Center
```

Asigne ÚNICAMENTE:

```text
Ver monitoreo en tiempo real
```

Código interno:

```text
live.view
```

Luego abra:

```text
http://IP_DEL_ISSABEL/callcenter-panel/live.php?tv=1
```

Así la pantalla puede visualizar el estado operativo sin tener acceso a reportes, grabaciones ni supervisión.

---

## 9. Configurar SLA

Ingrese:

```text
Administración > Configuración SLA
```

Ejemplo estándar inicial:

```text
Meta: 80 %
Tiempo: 20 segundos
```

Esto significa que el objetivo es atender al menos el 80 % de las llamadas dentro de 20 segundos.

El tiempo SLA modifica el cálculo de qué llamadas se consideran dentro del objetivo. La meta porcentual determina si el resultado final CUMPLE o NO CUMPLE.

---

## 10. Grabaciones

El panel busca por defecto en:

```text
/var/spool/asterisk/monitor
/var/spool/asterisk/monitoring
```

Compruebe:

```bash
ls -ld /var/spool/asterisk/monitor
```

Si Apache no puede leer las grabaciones y el servidor tiene `setfacl`:

```bash
setfacl -R -m u:apache:rX /var/spool/asterisk/monitor
setfacl -R -d -m u:apache:rX /var/spool/asterisk/monitor
```

Si SELinux bloquea específicamente esta lectura, revise primero el audit log antes de deshabilitar SELinux.

---

## 11. Diagnóstico desde consola

Después de instalar:

```bash
cd /var/www/html/callcenter-panel
sudo -u apache php bin/diagnostico.php
```

El diagnóstico comprueba:

- PHP;
- PDO MySQL;
- conexión con las bases;
- tablas importantes;
- AMI;
- cache;
- directorios de grabaciones.

---

# PARTE B - INSTALACIÓN MANUAL

Use esta sección si no desea ejecutar `install.sh`.

## 12. Crear la base del panel

Desde la carpeta descomprimida:

```bash
mysql -u root -p < sql/usuarios_permisos.sql
```

## 13. Crear el usuario MySQL del panel

Genere una contraseña segura:

```bash
openssl rand -hex 24
```

Ingrese a MariaDB:

```bash
mysql -u root -p
```

Ejecute, reemplazando `CLAVE_SEGURA`:

```sql
CREATE USER IF NOT EXISTS 'ccpanel'@'localhost' IDENTIFIED BY 'CLAVE_SEGURA';
ALTER USER 'ccpanel'@'localhost' IDENTIFIED BY 'CLAVE_SEGURA';

GRANT SELECT, SHOW VIEW ON call_center.* TO 'ccpanel'@'localhost';
GRANT SELECT, SHOW VIEW ON asteriskcdrdb.* TO 'ccpanel'@'localhost';
GRANT SELECT, SHOW VIEW ON asterisk.* TO 'ccpanel'@'localhost';
GRANT SELECT, INSERT, UPDATE, DELETE ON callcenter_panel.* TO 'ccpanel'@'localhost';
FLUSH PRIVILEGES;
```

## 14. Crear el administrador manualmente

Genere el hash:

```bash
php -r 'echo password_hash("CAMBIAR_ESTA_CLAVE", PASSWORD_DEFAULT), PHP_EOL;'
```

Copie el resultado y ejecute:

```sql
USE callcenter_panel;

INSERT INTO users
(username, full_name, password_hash, active, is_superadmin, must_change_password)
VALUES
('admin', 'Administrador', 'HASH_GENERADO', 1, 1, 0);
```

## 15. Copiar el código

```bash
mkdir -p /var/www/html/callcenter-panel
cp -a . /var/www/html/callcenter-panel/
```

No deje el ZIP dentro del DocumentRoot.

## 16. Configurar config.php

Edite:

```bash
nano /var/www/html/callcenter-panel/config.php
```

Configure como mínimo:

```php
'db' => array(
    'host' => 'localhost',
    'port' => 3306,
    'user' => 'ccpanel',
    'pass' => 'CLAVE_MYSQL_DEL_PANEL',
    'charset' => 'utf8mb4',
    'call_center' => 'call_center',
    'cdr' => 'asteriskcdrdb',
    'asterisk' => 'asterisk',
    'panel' => 'callcenter_panel',
),
```

Y AMI:

```php
'ami' => array(
    'enabled' => true,
    'host' => '127.0.0.1',
    'port' => 5038,
    'username' => 'ccpanel_monitor',
    'secret' => 'CLAVE_AMI',
    'timeout' => 1.5,
    'cache_ttl' => 8,
),
```

Para una instalación nueva deje el acceso legado vacío:

```php
'auth' => array(
    'username' => '',
    'password' => '',
    'session_name' => 'ISSABEL_CC_PANEL_PRO',
    'public_devoluciones' => false,
),
```

## 17. Configurar AMI manualmente

Backup:

```bash
cp -a /etc/asterisk/manager_custom.conf /etc/asterisk/manager_custom.conf.bak
```

Agregue:

```ini
[ccpanel_monitor]
secret = CLAVE_AMI
deny = 0.0.0.0/0.0.0.0
permit = 127.0.0.1/255.255.255.255
read = system,call
write = call,originate
```

Verifique que `manager.conf` incluya `manager_custom.conf`.

Después:

```bash
chown asterisk:asterisk /etc/asterisk/manager_custom.conf
chmod 640 /etc/asterisk/manager_custom.conf
asterisk -rx "manager reload"
```

Prueba de puerto:

```bash
ss -lntp | grep 5038
```

## 18. Permisos de archivos

```bash
cd /var/www/html
chown -R root:apache callcenter-panel
find callcenter-panel -type d -exec chmod 750 {} \;
find callcenter-panel -type f -exec chmod 640 {} \;
chown -R apache:apache callcenter-panel/cache
chmod 770 callcenter-panel/cache
```

## 19. SELinux

Si está activo:

```bash
getenforce
```

Permita las conexiones locales de Apache necesarias para MySQL/AMI:

```bash
setsebool -P httpd_can_network_connect 1
```

Para cache:

```bash
semanage fcontext -a -t httpd_sys_rw_content_t '/var/www/html/callcenter-panel/cache(/.*)?'
restorecon -Rv /var/www/html/callcenter-panel/cache
```

Si `semanage` no existe:

```bash
dnf install -y policycoreutils-python-utils
```

## 20. Reiniciar solamente servicios web

```bash
systemctl restart php-fpm 2>/dev/null || true
systemctl restart httpd
```

Asterisk no necesita reiniciarse; para AMI basta `manager reload`.

---

# PARTE C - PERMISOS DEL SISTEMA

## 21. Permisos disponibles

Principales códigos:

```text
dashboard.view
live.view
supervision.view
supervision.control
productivity.view
agents.view
outbound.view
calls.view
recordings.view
manual_calls.view
pauses.view
sessions.view
abandoned.view
callbacks.view
service_level.view
inbound_comparison.view
after_hours.view
forms.view
reports.view
reports.export
users.manage
settings.sla.manage
```

Un usuario sin permiso no solamente deja de ver el menú: las páginas y APIs también validan autorización del lado del servidor.

---

# PARTE D - PRUEBAS

## 22. Pruebas recomendadas después de instalar

### Login

```text
http://IP/callcenter-panel/login.php
```

### Wallboard

```text
http://IP/callcenter-panel/live.php?tv=1
```

Debe mostrar agentes y refrescar automáticamente.

### SLA

Cambie temporalmente el SLA, por ejemplo:

```text
80% / 20 s -> 80% / 30 s
```

Vuelva a consultar Nivel de servicio y verifique que se recalcule.

### AMI

Desde consola:

```bash
asterisk -rx "manager show users"
```

Debe aparecer el usuario del panel.

### Sintaxis PHP

```bash
find /var/www/html/callcenter-panel -name '*.php' -print0 | xargs -0 -n1 php -l
```

---

# PARTE E - BACKUP Y ROLLBACK

## 23. Backup del panel

```bash
cp -a /var/www/html/callcenter-panel /root/callcenter-panel_backup_$(date +%F_%H%M)
mysqldump -u root -p callcenter_panel > /root/callcenter_panel_$(date +%F_%H%M).sql
```

## 24. Rollback

Si reemplazó una instalación existente, `install.sh` genera automáticamente una copia con formato:

```text
/var/www/html/callcenter-panel_backup_AAAAMMDD_HHMMSS
```

Para volver atrás:

```bash
mv /var/www/html/callcenter-panel /var/www/html/callcenter-panel_fallido
mv /var/www/html/callcenter-panel_backup_AAAAMMDD_HHMMSS /var/www/html/callcenter-panel
systemctl restart httpd
```

---

# PARTE F - PROBLEMAS FRECUENTES

## Error: No se pudo conectar a la base de datos

Pruebe:

```bash
mysql -u ccpanel -p -e "SELECT COUNT(*) FROM call_center.agent;"
```

Revise `config.php` y los GRANT.

## Wallboard muestra BD sin AMI

Pruebe:

```bash
asterisk -rx "manager show users"
ss -lntp | grep 5038
```

Luego:

```bash
sudo -u apache php /var/www/html/callcenter-panel/bin/diagnostico.php
```

## HTTP 500

```bash
tail -100 /var/log/httpd/error_log
journalctl -u php-fpm -n 100 --no-pager
php -l /var/www/html/callcenter-panel/config.php
```

## 403 en cache o error al escribir AMI snapshot

```bash
ls -ldZ /var/www/html/callcenter-panel/cache
```

Reaplique permisos y contexto SELinux de la sección 19.

## No se pueden escuchar grabaciones

Compruebe que Apache pueda leer los archivos reales:

```bash
sudo -u apache find /var/spool/asterisk/monitor -type f | head
```

Si da `Permission denied`, aplique ACL según la sección 10.

---

# 25. Seguridad recomendada

- No usar root como usuario MySQL de la aplicación.
- Mantener AMI permitido solamente desde `127.0.0.1` cuando panel y Asterisk estén en el mismo servidor.
- No asignar `supervision.control` a usuarios que solo deban consultar.
- Tratar `recordings.view` como permiso sensible.
- Crear un usuario exclusivo con solo `live.view` para la TV.
- Utilizar HTTPS si el panel será accesible fuera de una red administrativa controlada.
- Realizar backup antes de actualizar.

---

# 26. Archivos principales

```text
config.php                     Configuración general
install.sh                     Instalación automática
sql/usuarios_permisos.sql      Base del panel
includes/auth.php              Usuarios/permisos
includes/db.php                PDO MySQL
includes/AmiClient.php         AMI y supervisión
live.php                       Wallboard/monitoreo
api/live_agents.php            Datos en vivo
supervise.php                  Supervisión
sla_settings.php               Configuración SLA
service_level.php              Reporte SLA
users.php                      Administración de usuarios
export.php                     CSV/PDF
bin/diagnostico.php            Diagnóstico CLI
```

---

# 27. Dependencias visuales del navegador

La interfaz actual carga Bootstrap 5.3.3, Bootstrap Icons 1.11.3 y Chart.js desde CDN. El servidor no necesita esos paquetes para procesar PHP, pero el navegador que abre el panel debe poder acceder a Internet para cargar esos recursos visuales.

Si la red del Call Center no tiene salida a Internet, conviene descargar esas librerías dentro de `assets/vendor/` y cambiar las referencias de `includes/header.php`, `includes/footer.php`, `login.php` y `devoluciones.php` a archivos locales antes de ponerlo en producción.
