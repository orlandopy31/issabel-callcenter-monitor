<?php
require_once __DIR__ . '/includes/bootstrap.php'; require_permission('pauses.view');
$repo = new ReportRepository();
$range = range_from_request();
$agentId = current_agent_filter();
$breakId = (isset($_GET['break_id']) && $_GET['break_id'] !== '') ? (int)$_GET['break_id'] : null;
$agents = $repo->getAgents();
$breaks = $repo->getBreaks();
$rows = $repo->getPauses($range['from'],$range['to'],$agentId,$breakId);

$totalCantidad = 0;
$totalSegundos = 0;
$agentesConPausa = array();
foreach ($rows as $r) {
    $totalCantidad += (int)$r['cantidad'];
    $totalSegundos += (int)$r['tiempo_seg'];
    if (!empty($r['agente'])) $agentesConPausa[(string)$r['agente']] = true;
}
$promedioGlobal = $totalCantidad > 0 ? round($totalSegundos / $totalCantidad) : 0;

$pageTitle='Pausas - Panel Issabel';
$pageSubtitle='Cantidad de pausas, motivo y sumatoria total por día, semana, mes o rango personalizado';
include __DIR__ . '/includes/header.php'; require_once __DIR__ . '/includes/filters.php'; render_filters($agents,$range,$agentId,array('break_filter'=>true,'breaks'=>$breaks));
?>
<div class="row g-3 mb-4">
    <div class="col-md-6 col-xl-3"><div class="metric-card-v11"><span class="metric-title">Total pausas</span><strong><?php echo e($totalCantidad); ?></strong><small>cantidad del rango</small></div></div>
    <div class="col-md-6 col-xl-3"><div class="metric-card-v11 warning"><span class="metric-title">Tiempo total</span><strong><?php echo e(seconds_to_hms($totalSegundos)); ?></strong><small>sumatoria general</small></div></div>
    <div class="col-md-6 col-xl-3"><div class="metric-card-v11 info"><span class="metric-title">Promedio pausa</span><strong><?php echo e(seconds_to_hms($promedioGlobal)); ?></strong><small>promedio global</small></div></div>
    <div class="col-md-6 col-xl-3"><div class="metric-card-v11 success"><span class="metric-title">Agentes con pausa</span><strong><?php echo e(count($agentesConPausa)); ?></strong><small>agentes distintos</small></div></div>
</div>
<div class="d-flex justify-content-between align-items-center mb-3">
    <div><h4 class="fw-bold mb-0"><i class="bi bi-pause-circle"></i> Pausas por agente y motivo</h4><div class="text-muted small">Incluye fila final con total general del rango filtrado. <?php if($breakId): ?>Filtro de pausa aplicado: <b><?php foreach($breaks as $br){ if((int)$br['id']===(int)$breakId){ echo e($br['name']); break; } } ?></b><?php endif; ?></div></div>
    <div class="btn-group"><a class="btn btn-outline-success btn-sm" href="export.php?report=pauses&format=csv&<?php echo e(build_query_string(array())); ?>">CSV</a><a class="btn btn-outline-danger btn-sm" href="export.php?report=pauses&format=pdf&<?php echo e(build_query_string(array())); ?>">PDF</a></div>
</div>
<div class="card shadow-sm border-0"><div class="card-body table-responsive"><table class="table table-striped table-sm align-middle table-polished"><thead><tr><th>Agente</th><th>Tipo</th><th>Motivo</th><th class="text-end">Cantidad</th><th>Tiempo total</th><th>Promedio</th><th>Primera</th><th>Última</th></tr></thead><tbody>
<?php foreach($rows as $r): ?><tr><td><b><?php echo e($r['agente']); ?></b><br><span class="small text-muted"><?php echo e($r['nombre']); ?></span></td><td><?php echo e($r['tipo_agente']); ?></td><td><?php echo e($r['motivo']); ?></td><td class="text-end fw-bold"><?php echo e($r['cantidad']); ?></td><td><?php echo e($r['tiempo_pausa']); ?></td><td><?php echo e($r['promedio_pausa']); ?></td><td><?php echo e($r['primera']); ?></td><td><?php echo e($r['ultima']); ?></td></tr><?php endforeach; ?>
<?php if(empty($rows)): ?><tr><td colspan="8" class="text-center py-4 text-muted">No hay pausas en el rango seleccionado.</td></tr><?php else: ?>
<tr class="table-dark"><td colspan="3"><b>TOTAL GENERAL</b></td><td class="text-end"><b><?php echo e($totalCantidad); ?></b></td><td><b><?php echo e(seconds_to_hms($totalSegundos)); ?></b></td><td><b><?php echo e(seconds_to_hms($promedioGlobal)); ?></b></td><td colspan="2"></td></tr>
<?php endif; ?>
</tbody></table></div></div>
<?php include __DIR__ . '/includes/footer.php'; ?>
