/*
Vistas operativas opcionales - Panel Issabel Call Center Pro v11
Ejecutar como root o usuario con permiso CREATE VIEW.
Estas vistas no reemplazan las consultas del sistema; ayudan a consultar de forma ordenada
la relación agente/extensión, sesiones, pausas y llamadas Call Center.
*/

USE call_center;

CREATE OR REPLACE VIEW vw_cc_agentes_extensiones AS
SELECT
    a.id AS id_agent,
    a.type AS tipo_agente,
    a.number AS agente,
    a.name AS nombre,
    a.estatus,
    GROUP_CONCAT(DISTINCT NULLIF(TRIM(au.login_extension), '') ORDER BY au.login_extension SEPARATOR ', ') AS extensiones_usadas,
    MAX(au.login_extension) AS ultima_extension,
    MAX(au.datetime_init) AS ultimo_login
FROM agent a
LEFT JOIN audit au ON au.id_agent = a.id AND au.id_break IS NULL
GROUP BY a.id, a.type, a.number, a.name, a.estatus;

CREATE OR REPLACE VIEW vw_cc_sesiones_agente AS
SELECT
    au.id,
    au.id_agent,
    a.number AS agente,
    a.name AS nombre,
    a.type AS tipo_agente,
    au.login_extension,
    au.datetime_init AS inicio,
    au.datetime_end AS fin,
    TIMESTAMPDIFF(SECOND, au.datetime_init, COALESCE(au.datetime_end, NOW())) AS segundos,
    CASE WHEN au.datetime_end IS NULL THEN 'ABIERTA' ELSE 'CERRADA' END AS estado
FROM audit au
INNER JOIN agent a ON a.id = au.id_agent
WHERE au.id_break IS NULL;

CREATE OR REPLACE VIEW vw_cc_pausas_agente AS
SELECT
    au.id,
    au.id_agent,
    a.number AS agente,
    a.name AS nombre,
    a.type AS tipo_agente,
    au.login_extension,
    b.name AS motivo_pausa,
    au.datetime_init AS inicio,
    au.datetime_end AS fin,
    TIMESTAMPDIFF(SECOND, au.datetime_init, COALESCE(au.datetime_end, NOW())) AS segundos,
    CASE WHEN au.datetime_end IS NULL THEN 'ABIERTA' ELSE 'CERRADA' END AS estado
FROM audit au
INNER JOIN agent a ON a.id = au.id_agent
LEFT JOIN `break` b ON b.id = au.id_break
WHERE au.id_break IS NOT NULL;

CREATE OR REPLACE VIEW vw_cc_llamadas_entrantes AS
SELECT
    ce.id,
    ce.id_agent,
    a.number AS agente,
    a.name AS nombre,
    a.type AS tipo_agente,
    ce.callerid AS numero_cliente,
    ce.datetime_entry_queue AS entrada_cola,
    ce.datetime_init AS inicio_atencion,
    ce.datetime_end AS fin,
    ce.duration AS segundos_hablados,
    ce.duration_wait AS segundos_espera,
    ce.status AS estado,
    ce.transfer AS transferencia,
    q.queue AS cola,
    camp.name AS campania,
    ce.uniqueid,
    ce.trunk
FROM call_entry ce
LEFT JOIN agent a ON a.id = ce.id_agent
LEFT JOIN queue_call_entry q ON q.id = ce.id_queue_call_entry
LEFT JOIN campaign_entry camp ON camp.id = ce.id_campaign;

CREATE OR REPLACE VIEW vw_cc_llamadas_salientes AS
SELECT
    c.id,
    c.id_agent,
    a.number AS agente,
    a.name AS nombre,
    a.type AS tipo_agente,
    c.phone AS numero_cliente,
    COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue) AS inicio,
    c.end_time AS fin,
    c.duration AS segundos_hablados,
    c.duration_wait AS segundos_espera,
    c.status AS estado,
    c.retries AS reintentos,
    c.transfer AS transferencia,
    camp.name AS campania,
    c.uniqueid,
    c.trunk,
    c.scheduled
FROM calls c
LEFT JOIN agent a ON a.id = c.id_agent
LEFT JOIN campaign camp ON camp.id = c.id_campaign;
