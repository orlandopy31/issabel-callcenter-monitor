-- Índices recomendados para acelerar reportes. Ejecutar fuera del horario pico.
-- Antes de ejecutar, revisar si el índice ya existe.

ALTER TABLE call_center.calls ADD INDEX idx_calls_uniqueid (uniqueid);
ALTER TABLE call_center.calls ADD INDEX idx_calls_agent_start (id_agent, start_time);
ALTER TABLE call_center.calls ADD INDEX idx_calls_phone_start (phone, start_time);

ALTER TABLE call_center.call_entry ADD INDEX idx_call_entry_uniqueid (uniqueid);
ALTER TABLE call_center.call_entry ADD INDEX idx_call_entry_agent_init (id_agent, datetime_init);
ALTER TABLE call_center.call_entry ADD INDEX idx_call_entry_caller_queue (callerid, datetime_entry_queue);

ALTER TABLE call_center.audit ADD INDEX idx_audit_agent_break_range (id_agent, id_break, datetime_init, datetime_end);
ALTER TABLE call_center.audit ADD INDEX idx_audit_login_extension (login_extension);

ALTER TABLE asteriskcdrdb.cdr ADD INDEX idx_cdr_src_calldate (src, calldate);
ALTER TABLE asteriskcdrdb.cdr ADD INDEX idx_cdr_dst_calldate (dst, calldate);
ALTER TABLE asteriskcdrdb.cdr ADD INDEX idx_cdr_linked_unique (linkedid, uniqueid);
ALTER TABLE asteriskcdrdb.cel ADD INDEX idx_cel_linked_eventtime (linkedid, eventtime);
