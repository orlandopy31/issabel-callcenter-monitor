/*
  Vistas opcionales v13 para reporte de devolución de llamadas.
  Ejecutar como root si se desea acelerar/validar la detección de llamadas salientes de devolución:

  mysql -u root -p < /var/www/html/callcenter-panel/sql/vistas_callbacks_v13.sql

  La aplicación NO depende obligatoriamente de estas vistas; son de apoyo operativo.
*/

USE call_center;

CREATE OR REPLACE VIEW v_ccpanel_callback_salientes AS
SELECT
    'Campaña saliente' AS origen_devolucion,
    'Saliente' AS tipo_devolucion,
    c.id AS id_origen,
    COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue) AS fecha_devolucion,
    c.phone AS numero_cliente,
    COALESCE(a.id, a_txt.id) AS id_agent,
    COALESCE(a.number, a_txt.number, c.agent, '') AS agente_numero,
    COALESCE(a.name, a_txt.name, '') AS agente_nombre,
    COALESCE(a.type, a_txt.type, '') AS agente_tipo,
    COALESCE(
        NULLIF(c.agent, ''),
        (
            SELECT au.login_extension
            FROM call_center.audit au
            WHERE au.id_agent = COALESCE(a.id, a_txt.id)
              AND au.id_break IS NULL
              AND au.login_extension IS NOT NULL
              AND au.login_extension <> ''
              AND au.datetime_init <= COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue)
              AND COALESCE(au.datetime_end, NOW()) >= COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue)
            ORDER BY au.datetime_init DESC
            LIMIT 1
        ),
        COALESCE(a.number, a_txt.number, '')
    ) AS extension_devolvio,
    c.status AS estado_devolucion,
    c.uniqueid AS uniqueid_devolucion,
    c.uniqueid AS linkedid_devolucion,
    c.duration AS hablado_seg,
    c.trunk AS troncal,
    '' AS grabacion
FROM call_center.calls c
LEFT JOIN call_center.agent a ON a.id = c.id_agent
LEFT JOIN call_center.agent a_txt ON a_txt.number = c.agent
WHERE COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue) IS NOT NULL
  AND c.phone IS NOT NULL
  AND c.phone <> ''

UNION ALL

SELECT
    'Manual desde extensión' AS origen_devolucion,
    'Saliente' AS tipo_devolucion,
    cd.sequence AS id_origen,
    cd.calldate AS fecha_devolucion,
    cd.dst AS numero_cliente,
    COALESCE(a_session.id, a_direct.id) AS id_agent,
    COALESCE(a_session.number, a_direct.number, cd.src) AS agente_numero,
    COALESCE(a_session.name, a_direct.name, 'Extensión sin agente asociado') AS agente_nombre,
    COALESCE(a_session.type, a_direct.type, '') AS agente_tipo,
    cd.src AS extension_devolvio,
    cd.disposition AS estado_devolucion,
    cd.uniqueid AS uniqueid_devolucion,
    cd.linkedid AS linkedid_devolucion,
    cd.billsec AS hablado_seg,
    '' AS troncal,
    cd.recordingfile AS grabacion
FROM asteriskcdrdb.cdr cd
LEFT JOIN call_center.audit au
    ON au.id_break IS NULL
   AND au.login_extension IS NOT NULL
   AND au.login_extension <> ''
   AND au.login_extension = cd.src
   AND au.datetime_init <= cd.calldate
   AND COALESCE(au.datetime_end, NOW()) >= cd.calldate
LEFT JOIN call_center.agent a_session ON a_session.id = au.id_agent
LEFT JOIN call_center.agent a_direct
    ON (
        a_direct.number = cd.src
        OR cd.channel LIKE CONCAT('PJSIP/', a_direct.number, '-%')
        OR cd.channel LIKE CONCAT('SIP/', a_direct.number, '-%')
        OR cd.channel LIKE CONCAT('IAX2/', a_direct.number, '-%')
    )
WHERE cd.dst IS NOT NULL
  AND cd.dst <> ''
  AND cd.dst NOT IN (SELECT number FROM call_center.agent)
  AND NOT EXISTS (
        SELECT 1
        FROM call_center.calls c
        WHERE c.uniqueid IS NOT NULL
          AND c.uniqueid <> ''
          AND (c.uniqueid = cd.uniqueid OR c.uniqueid = cd.linkedid)
  )
  AND NOT EXISTS (
        SELECT 1
        FROM call_center.call_entry ce
        WHERE ce.uniqueid IS NOT NULL
          AND ce.uniqueid <> ''
          AND (ce.uniqueid = cd.uniqueid OR ce.uniqueid = cd.linkedid)
  );
