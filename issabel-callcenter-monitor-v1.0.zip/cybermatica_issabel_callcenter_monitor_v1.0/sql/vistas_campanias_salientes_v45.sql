/* Vistas opcionales para auditoría de campañas salientes - Panel v45 */
CREATE OR REPLACE VIEW call_center.vw_panel_campanias_salientes_resumen AS
SELECT
    ca.id AS id_campaign,
    ca.name AS campania,
    ca.estatus AS estado_campania,
    ca.queue AS cola,
    ca.trunk AS troncal,
    COUNT(c.id) AS registros,
    COUNT(DISTINCT c.phone) AS numeros_unicos,
    SUM(CASE WHEN (IFNULL(c.duration,0) > 0 OR c.status LIKE '%ANSWER%' OR c.status LIKE '%Success%' OR c.status LIKE '%Completed%') AND c.id_agent IS NOT NULL THEN 1 ELSE 0 END) AS efectivas,
    SUM(CASE WHEN IFNULL(c.duration,0) > 0 OR c.status LIKE '%ANSWER%' OR c.status LIKE '%Success%' OR c.status LIKE '%Completed%' THEN 1 ELSE 0 END) AS atendidas,
    SUM(CASE WHEN NOT (IFNULL(c.duration,0) > 0 OR c.status LIKE '%ANSWER%' OR c.status LIKE '%Success%' OR c.status LIKE '%Completed%') THEN 1 ELSE 0 END) AS no_atendidas,
    SUM(IFNULL(c.duration,0)) AS hablado_seg,
    MIN(COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue)) AS primera_marcacion,
    MAX(COALESCE(c.start_time, c.fecha_llamada, c.datetime_originate, c.datetime_entry_queue)) AS ultima_marcacion
FROM call_center.calls c
LEFT JOIN call_center.campaign ca ON ca.id = c.id_campaign
GROUP BY ca.id, ca.name, ca.estatus, ca.queue, ca.trunk;
