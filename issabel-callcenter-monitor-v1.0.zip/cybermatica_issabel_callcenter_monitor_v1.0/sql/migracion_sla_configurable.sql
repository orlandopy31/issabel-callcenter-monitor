-- Migración: SLA configurable desde el panel
-- Compatible con una instalación que ya tenga usuarios/permisos.

CREATE DATABASE IF NOT EXISTS `callcenter_panel`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `callcenter_panel`;

CREATE TABLE IF NOT EXISTS `system_settings` (
  `setting_key` VARCHAR(100) NOT NULL,
  `setting_value` VARCHAR(255) NOT NULL,
  `label` VARCHAR(160) NOT NULL DEFAULT '',
  `description` VARCHAR(500) NULL,
  `updated_by` INT UNSIGNED NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_key`),
  KEY `idx_system_settings_updated_by` (`updated_by`),
  CONSTRAINT `fk_system_settings_updated_by`
    FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `permissions` (`code`,`name`,`category`,`description`,`sort_order`) VALUES
('settings.sla.manage','Configurar política SLA','Administración','Modificar meta porcentual y tiempo máximo del SLA utilizado por los reportes.',220)
ON DUPLICATE KEY UPDATE
  `name`=VALUES(`name`),
  `category`=VALUES(`category`),
  `description`=VALUES(`description`),
  `sort_order`=VALUES(`sort_order`);

INSERT INTO `system_settings` (`setting_key`,`setting_value`,`label`,`description`) VALUES
('sla_seconds','20','Tiempo SLA (segundos)','Tiempo máximo de espera para considerar una llamada atendida dentro del SLA.'),
('sla_target_pct','80','Meta SLA (%)','Porcentaje objetivo de llamadas ofrecidas que deben ser atendidas dentro del tiempo SLA.')
ON DUPLICATE KEY UPDATE
  `label`=VALUES(`label`),
  `description`=VALUES(`description`);
