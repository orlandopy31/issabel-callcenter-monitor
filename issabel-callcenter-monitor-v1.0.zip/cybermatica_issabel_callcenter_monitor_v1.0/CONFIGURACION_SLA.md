# SLA configurable — Panel Issabel Call Center

## Qué significa SLA

SLA significa **Service Level Agreement (Acuerdo de Nivel de Servicio)**. En este panel se mide como:

**SLA = llamadas atendidas dentro del tiempo SLA / llamadas ofrecidas × 100**

Ejemplo **80/20**: la meta es que al menos el 80% de las llamadas ofrecidas sean atendidas dentro de 20 segundos.

## Qué se puede configurar

Desde **Administración → Configuración SLA**:

- Meta SLA en porcentaje (1 a 100%).
- Tiempo máximo SLA en segundos (1 a 600 segundos).

La configuración se guarda en `callcenter_panel.system_settings`.

## Impacto

El tiempo SLA modifica cuáles llamadas se consideran `dentro_sla`. La meta porcentual define si el resultado **CUMPLE** o **NO CUMPLE**.

Afecta los módulos de nivel de servicio, comparativo de entrantes, productividad y las exportaciones relacionadas.

## NS ajustado por recuperación

El sistema conserva una métrica separada llamada **NS ajustado por recuperación**, que suma devoluciones de llamadas abandonadas como indicador de recuperación. Esta métrica no debe confundirse con el SLA real: una llamada devuelta posteriormente no fue atendida dentro del tiempo SLA original.

## Históricos

El sistema no modifica registros históricos de Issabel. Al cambiar la configuración, los reportes históricos se **recalculan con la política SLA vigente** en el momento de consultar el reporte.

## Instalación sobre la versión anterior

Ejecutar:

```bash
mysql -u root -p < sql/migracion_sla_configurable.sql
```

Luego copiar los archivos de esta versión sobre el panel y validar:

```bash
find . -name '*.php' -print0 | xargs -0 -n1 php -l
```

El superadministrador tendrá acceso automáticamente. Para otros usuarios, asignar el permiso **Configurar política SLA** desde `Usuarios y permisos`.
