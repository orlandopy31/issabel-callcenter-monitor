function toggleCustomDates(value) {
  document.querySelectorAll('.custom-date').forEach(function(el) {
    el.style.display = value === 'custom' ? '' : 'none';
  });
}
function safeChart(id, cfg) {
  const el = document.getElementById(id);
  if (!el || typeof Chart === 'undefined') return null;
  const defaults = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { labels: { boxWidth: 12, usePointStyle: true } } },
    scales: { y: { beginAtZero: true, grid: { color: '#eef2f7' } }, x: { grid: { display: false } } }
  };
  cfg.options = Object.assign(defaults, cfg.options || {});
  return new Chart(el, cfg);
}
function badgeClass(value) {
  value = (value || '').toString().trim().toUpperCase();
  // Importante: NO ANSWER contiene la palabra ANSWER, por eso debe evaluarse primero.
  if (value === 'NO ANSWER' || value.indexOf('NO ANSWER') >= 0 || value === 'NOANSWER') return 'badge-danger-soft';
  if (value.indexOf('ABAND') >= 0 || value.indexOf('BUSY') >= 0 || value.indexOf('FAIL') >= 0 || value.indexOf('CANCEL') >= 0 || value.indexOf('CHANUNAVAIL') >= 0 || value.indexOf('CONGESTION') >= 0) return 'badge-danger-soft';
  if (value === 'ANSWERED' || value.indexOf('ANSWERED') >= 0 || value.indexOf('SUCCESS') >= 0 || value === 'UP') return 'badge-ok';
  return 'badge-neutral';
}
document.addEventListener('DOMContentLoaded', function(){
  document.querySelectorAll('[data-status-badge]').forEach(function(el){ el.classList.add(badgeClass(el.textContent)); });
});
