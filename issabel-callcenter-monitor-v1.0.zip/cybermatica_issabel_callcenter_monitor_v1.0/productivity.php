<?php
require_once __DIR__ . '/includes/bootstrap.php'; require_permission('productivity.view');
$repo = new AnalyticsRepository();
$slaSeconds = report_sla_seconds();
$slaTarget = report_sla_target_pct();
$range = range_from_request();
$agentId = current_agent_filter();
$agents = $repo->getAgents();
$metrics = $repo->getAgentDecisionMetrics($range['from'], $range['to'], $agentId);
$daily = $repo->getAgentDailyDecision($range['from'], $range['to'], $agentId);
$lost = $repo->getLostCallsByHour($range['from'], $range['to'], $agentId);
$sl = $repo->getServiceLevel($range['from'], $range['to'], $agentId, 'hour');
$pageTitle='Tablero de productividad';
$pageSubtitle='Rendimiento real por agente: recibidas, no respondidas, devueltas, salientes manuales y eficiencia ajustada por recuperación';
include __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/filters.php'; render_filters($agents,$range,$agentId);

$summary = array(
    'agentes'=>0,
    'recibidas'=>0,
    'realizadas'=>0,
    'salientes_no_devolucion'=>0,
    'manuales_gestion'=>0,
    'llamadas'=>0,
    'respondidas'=>0,
    'respondidas_ajustadas'=>0,
    'no_atendidas_brutas'=>0,
    'no_atendidas_netas'=>0,
    'devueltas'=>0,
    'abandonadas_pendientes'=>0,
    'pausas'=>0,
    'pause_sec'=>0,
    'login_sec'=>0,
    'talk_sec'=>0,
    'dentro_sla'=>0,
    'ofrecidas'=>0
);
$topRows = array();
foreach ($metrics as $m) {
    if ($m['agente'] === 'TOTAL') continue;
    $summary['agentes']++;
    $summary['recibidas'] += isset($m['total_recibidas']) ? (int)$m['total_recibidas'] : 0;
    $summary['realizadas'] += isset($m['total_realizadas']) ? (int)$m['total_realizadas'] : 0;
    $summary['salientes_no_devolucion'] += isset($m['salientes_no_devolucion']) ? (int)$m['salientes_no_devolucion'] : 0;
    $summary['manuales_gestion'] += isset($m['manuales_salientes_gestion']) ? (int)$m['manuales_salientes_gestion'] : 0;
    $summary['llamadas'] += isset($m['total_llamadas']) ? (int)$m['total_llamadas'] : 0;
    $summary['respondidas'] += isset($m['respondidas']) ? (int)$m['respondidas'] : 0;
    $summary['respondidas_ajustadas'] += isset($m['respondidas_ajustadas']) ? (int)$m['respondidas_ajustadas'] : ((isset($m['respondidas']) ? (int)$m['respondidas'] : 0) + (isset($m['abandonadas_devueltas']) ? (int)$m['abandonadas_devueltas'] : 0));
    $summary['no_atendidas_brutas'] += isset($m['no_atendidas_brutas']) ? (int)$m['no_atendidas_brutas'] : (isset($m['no_atendidas']) ? (int)$m['no_atendidas'] : 0);
    $summary['no_atendidas_netas'] += isset($m['no_atendidas_netas']) ? (int)$m['no_atendidas_netas'] : (isset($m['no_atendidas']) ? (int)$m['no_atendidas'] : 0);
    $summary['devueltas'] += isset($m['abandonadas_devueltas']) ? (int)$m['abandonadas_devueltas'] : 0;
    $summary['abandonadas_pendientes'] += isset($m['abandonadas_pendientes']) ? (int)$m['abandonadas_pendientes'] : 0;
    $summary['pausas'] += isset($m['pausas']) ? (int)$m['pausas'] : 0;
    $summary['pause_sec'] += isset($m['tiempo_pausa_seg']) ? (int)$m['tiempo_pausa_seg'] : 0;
    $summary['login_sec'] += isset($m['tiempo_logueo_seg']) ? (int)$m['tiempo_logueo_seg'] : 0;
    $summary['talk_sec'] += isset($m['tiempo_hablado_seg']) ? (int)$m['tiempo_hablado_seg'] : 0;
    $summary['dentro_sla'] += isset($m['dentro_sla']) ? (int)$m['dentro_sla'] : 0;
    $summary['ofrecidas'] += isset($m['ofrecidas_cola']) ? (int)$m['ofrecidas_cola'] : 0;
    $topRows[] = $m;
}
$effectiveness = $summary['llamadas']>0 ? round(($summary['respondidas']/$summary['llamadas'])*100,2) : 0;
$adjustedEffectiveness = $summary['llamadas']>0 ? round(($summary['respondidas_ajustadas']/$summary['llamadas'])*100,2) : 0;
$slaPct = $summary['ofrecidas']>0 ? round(($summary['dentro_sla']/$summary['ofrecidas'])*100,2) : 0;
$occupancy = $summary['login_sec']>0 ? round(($summary['talk_sec']/$summary['login_sec'])*100,2) : 0;
$pausePct = $summary['login_sec']>0 ? round(($summary['pause_sec']/$summary['login_sec'])*100,2) : 0;
$chartAgents = array_slice($topRows,0,10);
?>
<div class="row g-3 mb-4">
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11"><span class="metric-title">Llamadas recibidas</span><strong><?php echo e($summary['recibidas']); ?></strong><small>Call Center + directas a extensión</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 danger"><span class="metric-title">No respondidas netas</span><strong><?php echo e($summary['no_atendidas_netas']); ?></strong><small><?php echo e($summary['no_atendidas_brutas']); ?> brutas antes de recuperación</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 success"><span class="metric-title">Llamadas devueltas</span><strong><?php echo e($summary['devueltas']); ?></strong><small>Abandonadas recuperadas por llamada saliente</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 info"><span class="metric-title">Eficiencia ajustada</span><strong><?php echo e($adjustedEffectiveness); ?>%</strong><small>Bruta: <?php echo e($effectiveness); ?>%</small></div></div>
</div>
<div class="row g-3 mb-4">
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11"><span class="metric-title">Total de llamadas</span><strong><?php echo e($summary['llamadas']); ?></strong><small>Recibidas + realizadas + manuales</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 warning"><span class="metric-title">Salientes no devueltas</span><strong><?php echo e($summary['salientes_no_devolucion']); ?></strong><small>Gestiones salientes fuera de devolución</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 info"><span class="metric-title">Manuales de gestión</span><strong><?php echo e($summary['manuales_gestion']); ?></strong><small>Llamadas manuales salientes no marcadas como devueltas</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 warning"><span class="metric-title">Pausa / logueo</span><strong><?php echo e($pausePct); ?>%</strong><small><?php echo e(seconds_to_hms($summary['pause_sec'])); ?> de pausa</small></div></div>
</div>

<div class="row g-3 mb-3">
    <div class="col-md-6"><div class="metric-card-v11 <?php echo $slaPct >= $slaTarget ? 'success' : 'danger'; ?>"><span class="metric-title">SLA del periodo</span><strong><?php echo e($slaPct); ?>%</strong><small><?php echo $slaPct >= $slaTarget ? 'CUMPLE' : 'NO CUMPLE'; ?> · Meta <?php echo e(rtrim(rtrim(number_format($slaTarget,2,'.',''),'0'),'.')); ?>%</small></div></div>
    <div class="col-md-6"><div class="metric-card-v11 info"><span class="metric-title">Política SLA vigente</span><strong><?php echo e(rtrim(rtrim(number_format($slaTarget,2,'.',''),'0'),'.')); ?>% / <?php echo e($slaSeconds); ?>s</strong><small>La modificación del tiempo recalcula el SLA de los reportes.</small></div></div>
</div>
<div class="alert alert-light border shadow-sm mb-3" style="border-radius:18px"><i class="bi bi-speedometer2"></i> <strong>SLA vigente: <?php echo e(report_sla_policy_label()); ?></strong> · El score utiliza el SLA real calculado con este tiempo objetivo.</div>

<div class="alert alert-info border-0 shadow-sm mb-4" style="border-radius:18px">
    <div class="d-flex gap-3 align-items-start">
        <i class="bi bi-info-circle fs-4"></i>
        <div>
            <strong>Lectura gerencial:</strong> la eficiencia ajustada suma las llamadas abandonadas que fueron devueltas. De esta forma, una llamada inicialmente perdida deja de impactar como pendiente si el agente la recuperó mediante una llamada saliente posterior. Las llamadas manuales que no son devolución quedan clasificadas como gestiones salientes.
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-xxl-8"><div class="card h-100"><div class="card-header d-flex justify-content-between align-items-center"><span><i class="bi bi-trophy"></i> Ranking de productividad por agente</span><span class="badge text-bg-success">Score con eficiencia ajustada</span></div><div class="card-body"><canvas id="scoreChart" height="120"></canvas></div></div></div>
    <div class="col-xxl-4"><div class="card h-100"><div class="card-header"><i class="bi bi-exclamation-octagon"></i> Horarios de mayor pérdida</div><div class="card-body p-0"><div class="table-responsive"><table class="table table-sm align-middle mb-0"><thead><tr><th>Hora</th><th>Cola</th><th class="text-end">Aband.</th><th>Espera prom.</th></tr></thead><tbody><?php foreach(array_slice($lost,0,8) as $r): ?><tr><td class="fw-bold"><?php echo e($r['hora']); ?></td><td><?php echo e($r['cola']); ?></td><td class="text-end"><span class="badge badge-danger-soft"><?php echo e($r['abandonadas']); ?></span></td><td><?php echo e($r['espera_promedio']); ?></td></tr><?php endforeach; if(empty($lost)): ?><tr><td colspan="4" class="text-center text-muted py-4">Sin llamadas perdidas en el rango.</td></tr><?php endif; ?></tbody></table></div></div></div></div>
</div>

<div class="card mb-4"><div class="card-header d-flex justify-content-between align-items-center"><span><i class="bi bi-table"></i> Rendimiento total por agente</span><div class="d-flex gap-2"><a class="btn btn-sm btn-outline-danger" href="export.php?report=agent_decision_total&format=pdf&<?php echo e(build_query_string(array())); ?>"><i class="bi bi-filetype-pdf"></i> PDF horizontal</a><a class="btn btn-sm btn-outline-success" href="export.php?report=agent_decision_total&format=csv&<?php echo e(build_query_string(array())); ?>"><i class="bi bi-filetype-csv"></i> CSV</a></div></div><div class="card-body p-0"><div class="table-responsive"><table class="table table-hover align-middle mb-0 table-polished"><thead><tr><th>Ranking</th><th>Agente</th><th>Extensión</th><th class="text-end">Score</th><th class="text-end">Efic. ajust.</th><th class="text-end">Recib.</th><th class="text-end">No resp.</th><th class="text-end">Devueltas</th><th class="text-end">Realiz.</th><th class="text-end">Sal. no dev.</th><th class="text-end">Manual gestión</th><th>Logueo</th><th>Pausa</th><th>Hablado</th><th class="text-end">Llam/h</th></tr></thead><tbody><?php $rank=1; foreach($metrics as $m): ?><tr class="<?php echo $m['agente']==='TOTAL'?'table-total-row':''; ?>"><td><?php if($m['agente']!=='TOTAL'): ?><span class="badge text-bg-dark">#<?php echo e($rank++); ?></span><?php else: ?><span class="badge text-bg-secondary">Total</span><?php endif; ?></td><td><div class="fw-bold"><?php echo e($m['agente']); ?></div><div class="small text-muted"><?php echo e($m['nombre']); ?></div></td><td><span class="badge badge-soft"><?php echo e($m['extension_relacionada']); ?></span></td><td class="text-end"><span class="score-pill"><?php echo e($m['score_productividad']); ?></span></td><td class="text-end"><strong><?php echo e(isset($m['efectividad_ajustada_pct'])?$m['efectividad_ajustada_pct']:$m['efectividad_pct']); ?></strong><div class="small text-muted">Bruta <?php echo e($m['efectividad_pct']); ?></div></td><td class="text-end"><?php echo e($m['total_recibidas']); ?></td><td class="text-end"><span class="badge badge-danger-soft"><?php echo e(isset($m['no_atendidas_netas'])?$m['no_atendidas_netas']:$m['no_atendidas']); ?></span></td><td class="text-end"><span class="badge badge-ok"><?php echo e($m['abandonadas_devueltas']); ?></span></td><td class="text-end"><?php echo e($m['total_realizadas']); ?></td><td class="text-end"><?php echo e(isset($m['salientes_no_devolucion'])?$m['salientes_no_devolucion']:0); ?></td><td class="text-end"><?php echo e(isset($m['manuales_salientes_gestion'])?$m['manuales_salientes_gestion']:0); ?></td><td><?php echo e($m['tiempo_logueo']); ?></td><td><?php echo e($m['tiempo_pausa']); ?></td><td><?php echo e($m['tiempo_hablado']); ?></td><td class="text-end"><?php echo e($m['llamadas_por_hora']); ?></td></tr><?php endforeach; ?></tbody></table></div></div></div>

<div class="row g-4">
    <div class="col-xl-7"><div class="card"><div class="card-header"><i class="bi bi-calendar-check"></i> Productividad diaria por agente</div><div class="card-body p-0"><div class="table-responsive"><table class="table table-sm table-hover table-polished mb-0"><thead><tr><th>Fecha</th><th>Agente</th><th class="text-end">Recib.</th><th class="text-end">Realiz.</th><th class="text-end">Dev.</th><th class="text-end">No resp.</th><th class="text-end">Manual gestión</th><th class="text-end">Efic. ajust.</th><th>Pausa</th><th>Logueo</th></tr></thead><tbody><?php foreach(array_slice($daily,0,80) as $d): ?><tr><td><?php echo e($d['fecha']); ?></td><td><strong><?php echo e($d['agente']); ?></strong><div class="small text-muted"><?php echo e($d['nombre']); ?></div></td><td class="text-end"><?php echo e($d['recibidas']); ?></td><td class="text-end"><?php echo e($d['realizadas']); ?></td><td class="text-end"><span class="badge badge-ok"><?php echo e(isset($d['devueltas'])?$d['devueltas']:0); ?></span></td><td class="text-end"><?php echo e($d['no_atendidas']); ?></td><td class="text-end"><?php echo e(isset($d['manuales_gestion'])?$d['manuales_gestion']:0); ?></td><td class="text-end"><strong><?php echo e(isset($d['efectividad_ajustada_pct'])?$d['efectividad_ajustada_pct']:$d['efectividad_pct']); ?></strong></td><td><?php echo e($d['tiempo_pausa']); ?></td><td><?php echo e($d['tiempo_logueo']); ?></td></tr><?php endforeach; ?></tbody></table></div></div></div></div>
    <div class="col-xl-5"><div class="card"><div class="card-header"><i class="bi bi-activity"></i> Nivel de servicio reciente</div><div class="card-body p-0"><div class="table-responsive"><table class="table table-sm mb-0"><thead><tr><th>Periodo</th><th>Cola</th><th>Agente</th><th class="text-end">SLA</th><th class="text-center">Cumple</th><th class="text-end">NS ajust.</th><th class="text-end">Dev.</th><th class="text-end">Pend.</th></tr></thead><tbody><?php foreach(array_slice($sl,0,18) as $r): ?><tr><td><?php echo e($r['periodo']); ?></td><td><?php echo e($r['cola']); ?></td><td><?php echo e($r['agente']); ?></td><td class="text-end"><span class="badge <?php echo (isset($r['cumple_sla']) && $r['cumple_sla']==='CUMPLE') ? 'text-bg-success':'text-bg-danger'; ?>"><?php echo e($r['nivel_servicio_pct']); ?></span></td><td class="text-center"><span class="badge <?php echo (isset($r['cumple_sla']) && $r['cumple_sla']==='CUMPLE') ? 'text-bg-success':'text-bg-danger'; ?>"><?php echo e(isset($r['cumple_sla'])?$r['cumple_sla']:'NO CUMPLE'); ?></span></td><td class="text-end"><span class="badge badge-soft"><?php echo e(isset($r['nivel_servicio_ajustado_pct'])?$r['nivel_servicio_ajustado_pct']:$r['nivel_servicio_pct']); ?></span></td><td class="text-end"><?php echo e(isset($r['devueltas'])?$r['devueltas']:0); ?></td><td class="text-end"><?php echo e(isset($r['abandonadas_pendientes'])?$r['abandonadas_pendientes']:$r['abandonadas']); ?></td></tr><?php endforeach; ?></tbody></table></div></div></div></div>
</div>
<script>
(function(){
const labels = <?php echo json_encode(array_map(function($r){return $r['agente'];}, $chartAgents)); ?>;
const scores = <?php echo json_encode(array_map(function($r){return (float)$r['score_productividad'];}, $chartAgents)); ?>;
const devueltas = <?php echo json_encode(array_map(function($r){return isset($r['abandonadas_devueltas']) ? (int)$r['abandonadas_devueltas'] : 0;}, $chartAgents)); ?>;
const noResp = <?php echo json_encode(array_map(function($r){return isset($r['no_atendidas_netas']) ? (int)$r['no_atendidas_netas'] : (int)$r['no_atendidas'];}, $chartAgents)); ?>;
if (window.Chart && document.getElementById('scoreChart')) {
    new Chart(document.getElementById('scoreChart'), {type:'bar', data:{labels:labels, datasets:[{label:'Score productividad', data:scores},{label:'Devueltas', data:devueltas},{label:'No respondidas netas', data:noResp}]}, options:{responsive:true, plugins:{legend:{position:'bottom'}}, scales:{y:{beginAtZero:true}}}});
}
})();
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
