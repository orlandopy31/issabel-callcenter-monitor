<?php
require_once __DIR__ . '/includes/bootstrap.php'; require_permission('callbacks.view');
$repo = new ReportRepository();
$range = range_from_request();
$agentId = current_agent_filter();
$agents = $repo->getAgents();
$perPage = (int)app_config('app.records_per_page',30);
$status = isset($_GET['status']) ? trim($_GET['status']) : 'pendientes';
if (!in_array($status, array('pendientes','devueltas','todas'), true)) $status = 'pendientes';
$q = isset($_GET['q']) ? trim($_GET['q']) : '';

$allRowsRaw = $repo->getCallbacks($range['from'],$range['to'],$agentId,(int)app_config('app.max_export_rows',30000));
$allRowsSearch = filter_rows_by_query($allRowsRaw, $q, array('numero_cliente','numero_cliente_original','fecha_abandono','cola','campania','devuelta','fecha_devolucion','extension_devolvio','agente_devolvio','agente_devolvio_numero','agente_devolvio_nombre','tipo_devolucion','origen_devolucion','estado_devolucion','uniqueid_abandono','uniqueid_devolucion','linkedid_devolucion'));

$totalDevueltas = 0;
$totalPendientes = 0;
foreach ($allRowsSearch as $tmpRow) {
    if (isset($tmpRow['devuelta']) && $tmpRow['devuelta'] === 'Sí') $totalDevueltas++; else $totalPendientes++;
}
$totalGeneralFiltrado = count($allRowsSearch);

$filteredRows = array();
foreach ($allRowsSearch as $r) {
    $isReturned = isset($r['devuelta']) && $r['devuelta'] === 'Sí';
    if ($status === 'devueltas' && !$isReturned) continue;
    if ($status === 'pendientes' && $isReturned) continue;
    $filteredRows[] = $r;
}

$pagination = paginate_array($filteredRows, $perPage, 'page');
$rows = $pagination['rows'];
$pageTitle='Devoluciones - Panel Issabel';
$pageSubtitle='Control profesional de llamadas abandonadas, devueltas y pendientes';
include __DIR__ . '/includes/header.php'; require_once __DIR__ . '/includes/filters.php'; render_filters($agents,$range,$agentId);

$statusLabels = array(
    'pendientes' => 'No devueltas',
    'devueltas' => 'Devueltas',
    'todas' => 'Todas'
);
$statusSub = array(
    'pendientes' => 'Lista de llamadas abandonadas pendientes de gestión',
    'devueltas' => 'Lista separada de llamadas que ya tuvieron devolución saliente',
    'todas' => 'Vista consolidada de devueltas y no devueltas'
);
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <div>
        <h4 class="fw-bold mb-0"><i class="bi bi-arrow-repeat"></i> Reporte de devolución de llamadas abandonadas</h4>
        <div class="text-muted small"><?php echo e($statusSub[$status]); ?>.</div>
    </div>
    <div class="btn-group">
        <a class="btn btn-outline-success btn-sm" href="export.php?report=callbacks&format=csv&<?php echo e(build_query_string(array('page'=>null))); ?>"><i class="bi bi-filetype-csv"></i> CSV</a>
        <a class="btn btn-outline-danger btn-sm" href="export.php?report=callbacks&format=pdf&<?php echo e(build_query_string(array('page'=>null))); ?>"><i class="bi bi-filetype-pdf"></i> PDF</a>
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-md-3">
        <div class="metric-card h-100">
            <div class="metric-label">No devueltas</div>
            <div class="metric-value text-danger"><?php echo e($totalPendientes); ?></div>
            <div class="metric-sub">Pendientes con filtros actuales</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="metric-card h-100">
            <div class="metric-label">Devueltas</div>
            <div class="metric-value text-success"><?php echo e($totalDevueltas); ?></div>
            <div class="metric-sub">Con llamada saliente detectada</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="metric-card h-100">
            <div class="metric-label">Total analizado</div>
            <div class="metric-value"><?php echo e($totalGeneralFiltrado); ?></div>
            <div class="metric-sub">Abandonadas del rango/búsqueda</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="metric-card h-100">
            <div class="metric-label">Vista actual</div>
            <div class="metric-value"><?php echo e($pagination['from']); ?>-<?php echo e($pagination['to']); ?></div>
            <div class="metric-sub"><?php echo e($statusLabels[$status]); ?> · <?php echo e($pagination['total']); ?> registros</div>
        </div>
    </div>
</div>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
            <ul class="nav nav-pills gap-1">
                <li class="nav-item">
                    <a class="nav-link <?php echo $status==='pendientes'?'active':''; ?>" href="callbacks.php?<?php echo e(build_query_string(array('status'=>'pendientes','page'=>null))); ?>">
                        <i class="bi bi-exclamation-triangle"></i> No devueltas
                        <span class="badge <?php echo $status==='pendientes'?'bg-light text-primary':'bg-danger'; ?> ms-1"><?php echo e($totalPendientes); ?></span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $status==='devueltas'?'active':''; ?>" href="callbacks.php?<?php echo e(build_query_string(array('status'=>'devueltas','page'=>null))); ?>">
                        <i class="bi bi-check2-circle"></i> Devueltas
                        <span class="badge <?php echo $status==='devueltas'?'bg-light text-primary':'bg-success'; ?> ms-1"><?php echo e($totalDevueltas); ?></span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $status==='todas'?'active':''; ?>" href="callbacks.php?<?php echo e(build_query_string(array('status'=>'todas','page'=>null))); ?>">
                        <i class="bi bi-list-check"></i> Todas
                        <span class="badge <?php echo $status==='todas'?'bg-light text-primary':'bg-secondary'; ?> ms-1"><?php echo e($totalGeneralFiltrado); ?></span>
                    </a>
                </li>
            </ul>
            <span class="badge bg-light text-dark border">Modo actual: <?php echo e($statusLabels[$status]); ?></span>
        </div>
        <form class="row g-2 align-items-end" method="get">
            <?php foreach($_GET as $k=>$v): if(in_array($k,array('q','page'))) continue; ?>
                <input type="hidden" name="<?php echo e($k); ?>" value="<?php echo e($v); ?>">
            <?php endforeach; ?>
            <div class="col-md-6">
                <label class="form-label small text-muted">Buscar en la vista actual</label>
                <input type="text" name="q" class="form-control" value="<?php echo e($q); ?>" placeholder="Número, agente, extensión, estado, campaña, uniqueid...">
            </div>
            <div class="col-md-3">
                <button class="btn btn-primary w-100"><i class="bi bi-search"></i> Buscar</button>
            </div>
            <div class="col-md-3">
                <a class="btn btn-outline-secondary w-100" href="callbacks.php?<?php echo e(build_query_string(array('q'=>null,'page'=>null))); ?>"><i class="bi bi-x-circle"></i> Limpiar búsqueda</a>
            </div>
        </form>
    </div>
</div>

<div class="alert alert-info small">
    <strong>Criterio usado:</strong> una llamada abandonada se considera devuelta cuando el mismo número aparece posteriormente como llamada <strong>saliente</strong>, ya sea desde campaña o desde CDR manual. La pestaña <strong>Devueltas</strong> muestra únicamente las llamadas ya gestionadas; la pestaña <strong>No devueltas</strong> permite volver a las pendientes.
</div>

<div class="card shadow-sm border-0">
    <div class="card-header bg-white d-flex flex-wrap justify-content-between align-items-center gap-2">
        <span class="fw-bold">Detalle - <?php echo e($statusLabels[$status]); ?></span>
        <span class="badge bg-light text-dark border">Total de la vista: <?php echo e($pagination['total']); ?></span>
    </div>
    <div class="card-body table-responsive p-0">
        <table class="table table-hover table-sm table-polished mb-0 align-middle">
            <thead>
                <tr>
                    <th>Número perdido</th>
                    <th>Fecha abandono</th>
                    <th>Espera</th>
                    <th>Cola/Campaña</th>
                    <th>Devuelta</th>
                    <th>Fecha devolución</th>
                    <th>Extensión devolvió</th>
                    <th>Agente devolvió</th>
                    <th>Tipo</th>
                    <th>Origen</th>
                    <th>Estado</th>
                    <th>Tiempo hasta devolución</th>
                    <th>Detalle</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach($rows as $r): ?>
                <tr>
                    <td>
                        <div class="code-small fw-bold"><?php echo e($r['numero_cliente']); ?></div>
                        <?php if(!empty($r['numero_cliente_original']) && $r['numero_cliente_original'] !== $r['numero_cliente']): ?>
                            <div class="text-muted small">Original: <?php echo e($r['numero_cliente_original']); ?></div>
                        <?php endif; ?>
                    </td>
                    <td class="text-nowrap"><?php echo e($r['fecha_abandono']); ?></td>
                    <td><?php echo e($r['espera']); ?></td>
                    <td><?php echo e(trim($r['cola'].' '.$r['campania'])); ?></td>
                    <td><span class="badge bg-<?php echo $r['devuelta']==='Sí'?'success':'danger'; ?>"><?php echo e($r['devuelta']); ?></span></td>
                    <td class="text-nowrap"><?php echo e($r['fecha_devolucion']); ?></td>
                    <td class="fw-bold code-small"><?php echo e($r['extension_devolvio']); ?></td>
                    <td><?php echo e($r['agente_devolvio']); ?></td>
                    <td><span class="badge bg-<?php echo $r['tipo_devolucion']==='Saliente'?'primary':'secondary'; ?>"><?php echo e($r['tipo_devolucion']); ?></span></td>
                    <td><?php echo e($r['origen_devolucion']); ?></td>
                    <td>
                        <?php if (!empty($r['estado_devolucion'])): ?>
                            <span class="badge" data-status-badge><?php echo e($r['estado_devolucion']); ?></span>
                        <?php else: ?>
                            <span class="text-muted small">-</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($r['tiempo_hasta_devolucion']); ?></td>
                    <td>
                        <?php if(!empty($r['uniqueid_devolucion'])): ?>
                            <a class="btn btn-sm btn-outline-primary" href="trace.php?uniqueid=<?php echo urlencode($r['uniqueid_devolucion']); ?><?php echo !empty($r['linkedid_devolucion']) ? '&linkedid='.urlencode($r['linkedid_devolucion']) : ''; ?>"><i class="bi bi-eye"></i> Ver</a>
                        <?php else: ?>
                            <span class="text-muted small">Pendiente</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; if(empty($rows)): ?>
                <tr><td colspan="13" class="text-center py-4 text-muted">No se encontraron registros en la lista <?php echo e(strtolower($statusLabels[$status])); ?> con los filtros seleccionados.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php render_pagination($pagination, 'page'); ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
