<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_permission('recordings.view');

/**
 * Servidor seguro de grabaciones para Issabel/Asterisk.
 *
 * Mejora v28:
 * - Ruta principal: /var/spool/asterisk/monitor.
 * - Soporta subcarpetas por fecha: YYYY/MM/DD, YYYY-MM-DD, YYYYMMDD, YYYY/MM.
 * - Si CDR recordingfile viene vacío o no coincide, busca por uniqueid/linkedid.
 * - Si uniqueid/linkedid no aparecen en el nombre físico, busca por contexto:
 *   fecha/hora + origen + destino.
 * - No expone rutas internas del servidor.
 */

function recording_allowed_dirs()
{
    $dirs = app_config('recordings.dirs', array('/var/spool/asterisk/monitor'));
    $out = array();
    foreach ($dirs as $dir) {
        $dir = rtrim((string)$dir, '/');
        if ($dir !== '' && is_dir($dir)) $out[] = $dir;
    }
    return $out;
}

function recording_allowed_extensions()
{
    return app_config('recordings.allowed_extensions', array('wav','WAV','wav49','WAV49','gsm','mp3','ogg','sln','ulaw','alaw','GSM','MP3'));
}

function recording_mime($path)
{
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    if ($ext === 'wav' || $ext === 'wav49') return 'audio/wav';
    if ($ext === 'mp3') return 'audio/mpeg';
    if ($ext === 'ogg') return 'audio/ogg';
    if ($ext === 'gsm') return 'audio/gsm';
    if ($ext === 'ulaw') return 'audio/basic';
    if ($ext === 'alaw') return 'audio/basic';
    if ($ext === 'sln') return 'application/octet-stream';
    return 'application/octet-stream';
}

function is_path_inside($path, $base)
{
    $rp = realpath($path);
    $rb = realpath($base);
    if (!$rp || !$rb) return false;
    return strpos($rp, rtrim($rb, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR) === 0 || $rp === $rb;
}

function recording_safe_request($value)
{
    $value = trim((string)$value);
    $value = str_replace("\0", '', $value);
    $value = str_replace('\\', '/', $value);
    if ($value === '') return '';
    if (strpos($value, '..') !== false) return '';
    return $value;
}

function recording_safe_token($value)
{
    $value = trim((string)$value);
    return preg_replace('/[^0-9A-Za-z_.-]+/', '', $value);
}

function recording_digits($value)
{
    return preg_replace('/\D+/', '', (string)$value);
}

function recording_file_allowed($path)
{
    if (!is_file($path)) return false;
    $ext = pathinfo($path, PATHINFO_EXTENSION);
    if ($ext === '') return false;
    $allowed = array_map('strtolower', recording_allowed_extensions());
    return in_array(strtolower($ext), $allowed, true);
}

function recording_ext_candidates($name)
{
    $allowed = array_unique(array_map('strtolower', recording_allowed_extensions()));
    $out = array();
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    if ($ext !== '') {
        $out[] = $name;
    } else {
        foreach ($allowed as $e) $out[] = $name . '.' . $e;
        foreach ($allowed as $e) $out[] = $name . '.' . strtoupper($e);
    }
    return array_values(array_unique($out));
}

function recording_candidate_dirs($base, $date)
{
    $dirs = array($base);
    $ts = strtotime((string)$date);
    if ($ts) {
        $y = date('Y', $ts);
        $m = date('m', $ts);
        $d = date('d', $ts);
        $dirs[] = $base . DIRECTORY_SEPARATOR . $y . DIRECTORY_SEPARATOR . $m . DIRECTORY_SEPARATOR . $d;
        $dirs[] = $base . DIRECTORY_SEPARATOR . $y . DIRECTORY_SEPARATOR . $m;
        $dirs[] = $base . DIRECTORY_SEPARATOR . $y . '-' . $m . '-' . $d;
        $dirs[] = $base . DIRECTORY_SEPARATOR . $y . $m . $d;
        $dirs[] = $base . DIRECTORY_SEPARATOR . $y . '-' . $m;
    }
    $out = array();
    foreach (array_unique($dirs) as $dir) {
        if (is_dir($dir)) $out[] = $dir;
    }
    return $out;
}

function find_recording_recursive_exact($base, $names, $maxDepth, &$scanned, $maxScanned)
{
    if ($maxDepth < 0 || $scanned > $maxScanned) return null;
    $items = @scandir($base);
    if (!$items) return null;
    $namesLower = array();
    foreach ($names as $n) $namesLower[] = strtolower($n);
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') continue;
        $path = $base . DIRECTORY_SEPARATOR . $item;
        $scanned++;
        if ($scanned > $maxScanned) return null;
        if (is_file($path) && in_array(strtolower($item), $namesLower, true) && recording_file_allowed($path)) return $path;
        if (is_dir($path) && $maxDepth > 0) {
            $found = find_recording_recursive_exact($path, $names, $maxDepth - 1, $scanned, $maxScanned);
            if ($found) return $found;
        }
    }
    return null;
}

function find_recording_recursive_tokens($base, $tokens, $maxDepth, &$scanned, $maxScanned)
{
    if ($maxDepth < 0 || $scanned > $maxScanned || empty($tokens)) return null;
    $items = @scandir($base);
    if (!$items) return null;
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') continue;
        $path = $base . DIRECTORY_SEPARATOR . $item;
        $scanned++;
        if ($scanned > $maxScanned) return null;
        if (is_file($path) && recording_file_allowed($path)) {
            $lower = strtolower($item);
            foreach ($tokens as $token) {
                $token = strtolower((string)$token);
                if ($token !== '' && strpos($lower, $token) !== false) return $path;
            }
        }
        if (is_dir($path) && $maxDepth > 0) {
            $found = find_recording_recursive_tokens($path, $tokens, $maxDepth - 1, $scanned, $maxScanned);
            if ($found) return $found;
        }
    }
    return null;
}

function find_recording_by_context($base, $date, $src, $dst, $maxDepth, &$scanned, $maxScanned)
{
    if ($maxDepth < 0 || $scanned > $maxScanned) return null;
    $items = @scandir($base);
    if (!$items) return null;

    $srcD = recording_digits($src);
    $dstD = recording_digits($dst);
    $ts = strtotime((string)$date);
    $dateTokens = array();
    if ($ts) {
        $dateTokens[] = date('Ymd', $ts);
        $dateTokens[] = date('Y-m-d', $ts);
        $dateTokens[] = date('Y/m/d', $ts);
        $dateTokens[] = date('His', $ts);
        $dateTokens[] = date('Hi', $ts);
    }

    foreach ($items as $item) {
        if ($item === '.' || $item === '..') continue;
        $path = $base . DIRECTORY_SEPARATOR . $item;
        $scanned++;
        if ($scanned > $maxScanned) return null;

        if (is_file($path) && recording_file_allowed($path)) {
            $name = strtolower($item);
            $score = 0;
            if ($srcD !== '' && strpos($name, strtolower($srcD)) !== false) $score += 3;
            if ($dstD !== '' && strpos($name, strtolower($dstD)) !== false) $score += 3;
            foreach ($dateTokens as $t) {
                $cleanT = str_replace('/', '', strtolower($t));
                if ($cleanT !== '' && strpos(str_replace(array('-', '_'), '', $name), str_replace('-', '', $cleanT)) !== false) {
                    $score += (strlen($cleanT) >= 8) ? 2 : 1;
                    break;
                }
            }
            // Coincidencia fuerte: origen+destino; o número+fecha/hora.
            if ($score >= 5) return $path;
        }

        if (is_dir($path) && $maxDepth > 0) {
            $found = find_recording_by_context($path, $date, $src, $dst, $maxDepth - 1, $scanned, $maxScanned);
            if ($found) return $found;
        }
    }
    return null;
}

function resolve_recording($requested, $uniqueid = '', $linkedid = '', $date = '', $src = '', $dst = '')
{
    $requested = recording_safe_request($requested);
    $uniqueid = recording_safe_token($uniqueid);
    $linkedid = recording_safe_token($linkedid);
    $src = recording_safe_token($src);
    $dst = recording_safe_token($dst);

    $dirs = recording_allowed_dirs();
    if (empty($dirs)) return null;

    $allowedExt = array_map('strtolower', recording_allowed_extensions());
    $maxDepth = (int)app_config('recordings.search_depth', 6);
    $maxScanned = (int)app_config('recordings.max_scan_files', 50000);

    if ($requested !== '') {
        $basename = basename($requested);
        $ext = strtolower(pathinfo($basename, PATHINFO_EXTENSION));
        if ($ext !== '' && !in_array($ext, $allowedExt, true)) return null;
        $names = recording_ext_candidates($basename);

        foreach ($dirs as $base) {
            // Ruta absoluta permitida.
            if (strpos($requested, '/') === 0 && is_file($requested) && is_path_inside($requested, $base) && recording_file_allowed($requested)) {
                return $requested;
            }

            // Ruta relativa dentro de monitor.
            $relative = ltrim($requested, '/');
            $candidate = $base . DIRECTORY_SEPARATOR . $relative;
            if (recording_file_allowed($candidate) && is_path_inside($candidate, $base)) return $candidate;

            // Nombre de archivo en carpeta base o carpetas típicas de fecha.
            foreach (recording_candidate_dirs($base, $date) as $dir) {
                foreach ($names as $name) {
                    $candidate = $dir . DIRECTORY_SEPARATOR . $name;
                    if (recording_file_allowed($candidate) && is_path_inside($candidate, $base)) return $candidate;
                }
            }
        }

        // Búsqueda recursiva por nombre exacto priorizando carpetas por fecha.
        foreach ($dirs as $base) {
            foreach (recording_candidate_dirs($base, $date) as $dir) {
                $scanned = 0;
                $found = find_recording_recursive_exact($dir, $names, 2, $scanned, $maxScanned);
                if ($found && is_path_inside($found, $base)) return $found;
            }
            $scanned = 0;
            $found = find_recording_recursive_exact($base, $names, $maxDepth, $scanned, $maxScanned);
            if ($found && is_path_inside($found, $base)) return $found;
        }
    }

    // Búsqueda por uniqueid/linkedid.
    $tokens = array_values(array_unique(array_filter(array($uniqueid, $linkedid))));
    if (!empty($tokens)) {
        foreach ($dirs as $base) {
            foreach (recording_candidate_dirs($base, $date) as $dir) {
                $scanned = 0;
                $found = find_recording_recursive_tokens($dir, $tokens, 2, $scanned, $maxScanned);
                if ($found && is_path_inside($found, $base)) return $found;
            }
            $scanned = 0;
            $found = find_recording_recursive_tokens($base, $tokens, $maxDepth, $scanned, $maxScanned);
            if ($found && is_path_inside($found, $base)) return $found;
        }
    }

    // Búsqueda contextual por fecha, origen y destino. Útil cuando el archivo no incluye uniqueid.
    if ($date !== '' && ($src !== '' || $dst !== '')) {
        foreach ($dirs as $base) {
            foreach (recording_candidate_dirs($base, $date) as $dir) {
                $scanned = 0;
                $found = find_recording_by_context($dir, $date, $src, $dst, 2, $scanned, $maxScanned);
                if ($found && is_path_inside($found, $base)) return $found;
            }
            $scanned = 0;
            $found = find_recording_by_context($base, $date, $src, $dst, $maxDepth, $scanned, $maxScanned);
            if ($found && is_path_inside($found, $base)) return $found;
        }
    }

    return null;
}

$file = isset($_GET['f']) ? $_GET['f'] : '';
$uniqueid = isset($_GET['u']) ? $_GET['u'] : '';
$linkedid = isset($_GET['l']) ? $_GET['l'] : '';
$date = isset($_GET['date']) ? $_GET['date'] : '';
$src = isset($_GET['src']) ? $_GET['src'] : '';
$dst = isset($_GET['dst']) ? $_GET['dst'] : '';
$path = resolve_recording($file, $uniqueid, $linkedid, $date, $src, $dst);

if (!$path || !is_readable($path)) {
    http_response_code(404);
    header('Content-Type: text/plain; charset=utf-8');
    echo "Grabación no encontrada o sin permiso de lectura.\n\n";
    echo "Ruta configurada principal: /var/spool/asterisk/monitor\n";
    echo "Verifique permisos de Apache y que el archivo exista en monitor o subcarpetas por fecha.\n";
    echo "Datos usados para búsqueda:\n";
    echo "recordingfile=" . $file . "\n";
    echo "uniqueid=" . $uniqueid . "\n";
    echo "linkedid=" . $linkedid . "\n";
    echo "fecha=" . $date . "\n";
    echo "origen=" . $src . "\n";
    echo "destino=" . $dst . "\n";
    exit;
}

$size = filesize($path);
$start = 0;
$end = $size - 1;
$status = 200;

if (isset($_SERVER['HTTP_RANGE']) && preg_match('/bytes=(\d*)-(\d*)/', $_SERVER['HTTP_RANGE'], $m)) {
    if ($m[1] !== '') $start = (int)$m[1];
    if ($m[2] !== '') $end = (int)$m[2];
    if ($end >= $size) $end = $size - 1;
    if ($start > $end) $start = 0;
    $status = 206;
}

$length = $end - $start + 1;
http_response_code($status);
header('Content-Type: ' . recording_mime($path));
header('Accept-Ranges: bytes');
header('Content-Disposition: inline; filename="' . basename($path) . '"');
header('Cache-Control: private, max-age=3600');
if ($status === 206) header("Content-Range: bytes {$start}-{$end}/{$size}");
header('Content-Length: ' . $length);

$fp = fopen($path, 'rb');
fseek($fp, $start);
$buffer = 8192;
$sent = 0;
while (!feof($fp) && $sent < $length) {
    $read = min($buffer, $length - $sent);
    echo fread($fp, $read);
    $sent += $read;
    if (ob_get_level()) @ob_flush();
    flush();
}
fclose($fp);
exit;
