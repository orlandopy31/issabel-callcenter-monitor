<?php
require_once __DIR__ . '/includes/bootstrap.php'; require_permission('forms.view');
$repo = new ReportRepository(); $range = range_from_request(); $agentId = current_agent_filter(); $agents = $repo->getAgents();
$rows = $repo->getForms($range['from'],$range['to'],$agentId,(int)app_config('app.max_export_rows',20000));
$pageTitle='Formularios - Panel Issabel'; include __DIR__ . '/includes/header.php'; require_once __DIR__ . '/includes/filters.php'; render_filters($agents,$range,$agentId);
?>
<div class="d-flex justify-content-between align-items-center mb-3"><h4 class="fw-bold mb-0">Detalle de formularios cargados</h4><div class="btn-group"><a class="btn btn-outline-success btn-sm" href="export.php?report=forms&format=csv&<?php echo e(build_query_string(array())); ?>">CSV</a><a class="btn btn-outline-danger btn-sm" href="export.php?report=forms&format=pdf&<?php echo e(build_query_string(array())); ?>">PDF</a></div></div>
<div class="card shadow-sm border-0"><div class="card-body table-responsive"><table class="table table-striped table-sm"><thead><tr><th>Fecha</th><th>Tipo llamada</th><th>ID llamada</th><th>Número</th><th>Agente</th><th>Campo</th><th>Valor</th></tr></thead><tbody>
<?php foreach($rows as $r): ?><tr><td><?php echo e($r['fecha']); ?></td><td><?php echo e($r['tipo_llamada']); ?></td><td><?php echo e($r['id_llamada']); ?></td><td class="code-small"><?php echo e($r['numero_cliente']); ?></td><td><b><?php echo e($r['agente']); ?></b><br><span class="small text-muted"><?php echo e($r['nombre']); ?></span></td><td><?php echo e($r['campo']); ?></td><td class="wrap-text"><?php echo e($r['valor']); ?></td></tr><?php endforeach; ?>
</tbody></table></div></div>
<?php include __DIR__ . '/includes/footer.php'; ?>
