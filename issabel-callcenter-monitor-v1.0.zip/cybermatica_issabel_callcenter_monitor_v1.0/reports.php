<?php
require_once __DIR__ . '/includes/bootstrap.php'; require_permission('reports.view');
$repo = new AnalyticsRepository(); $range = range_from_request(); $agentId = current_agent_filter(); $agents = $repo->getAgents();
$pageTitle='Centro de reportes';
$pageSubtitle='Descarga CSV/PDF por día, semana, mes, rango personalizado, global o por agente';
include __DIR__ . '/includes/header.php'; require_once __DIR__ . '/includes/filters.php'; render_filters($agents,$range,$agentId);
$reports = array(
    array('executive_summary','Resumen ejecutivo','PDF principal para gerencia: llamadas realizadas/recibidas, abandonadas, pausas, sesiones, transferencias, formularios y devoluciones.','bi-file-earmark-medical','Prioritario'),
    array('agent_total','Reporte total por agente','Sumatoria completa por agente: sesiones, extensión, llamadas entrantes, realizadas, manuales, pausas, logueo, hablado y formularios.','bi-person-badge','Prioritario'),
    array('agent_decision_total','Reporte ejecutivo de productividad','Reporte principal para decidir: score, efectividad, nivel de servicio, llamadas no atendidas, extensión, pausas y tiempos por agente.','bi-kanban','Nuevo'),
    array('agent_daily_decision','Productividad diaria por agente','Detalle por día para detectar comportamiento, efectividad, pausas, logueo, llamadas manuales y rendimiento del agente.','bi-calendar2-check','Nuevo'),
    array('service_level_hour','Nivel de servicio por hora','Nivel de servicio por hora, cola y agente usando la política SLA configurable; muestra meta y cumplimiento.','bi-activity','Nuevo'),
    array('inbound_queue_comparison','Comparativo entrantes de cola','Una sola vista del flujo de atención: llamadas ofrecidas, contestadas, abandonadas, devueltas, pendientes y eficiencia ajustada.','bi-bar-chart-steps','Nuevo'),
    array('service_level_day','Nivel de servicio por día','Consolidado diario contra la meta SLA configurada, con cumplimiento por cola y agente.','bi-calendar-day','SLA'),
    array('service_level_week','Nivel de servicio por semana','Consolidado semanal para evaluar dotación y cumplimiento de la meta SLA vigente.','bi-calendar-week','SLA'),
    array('service_level_month','Nivel de servicio por mes','Consolidado mensual de atención, abandono y cumplimiento de SLA por cola/agente.','bi-calendar-month','SLA'),
    array('outbound_campaigns_summary','Campañas salientes - resumen','Resumen por campaña: marcaciones del dialer, efectivas, atendidas, no atendidas, tasas, tiempos, transferidas y reintentos.','bi-megaphone','Nuevo'),
    array('outbound_campaigns_detail','Campañas salientes - detalle','Detalle de cada número marcado por campaña saliente: agente, estado, resultado, intentos, duración, falla y log de progreso.','bi-list-ul','Nuevo'),
    array('after_hours_guard','Fuera de horario a guardia','Llamadas que ingresaron fuera del horario de atención y fueron desviadas al número de guardia configurado.','bi-moon-stars','Nuevo'),
    array('not_answered','Llamadas no atendidas','Detalle completo de abandonadas, campañas sin respuesta y llamadas manuales no contestadas.','bi-telephone-x','Nuevo'),
    array('lost_calls_by_hour','Horario de mayor pérdida','Ranking por hora de llamadas abandonadas, cola y espera promedio/máxima.','bi-graph-down-arrow','Nuevo'),
    array('agent_session_detail','Detalle de sesión y pausas','Bitácora exacta de inicios/cierres de sesión, extensión utilizada, pausas, motivos y duración.','bi-clock-history','Auditoría'),
    array('agent_performance','Productividad por agente','Detalle por agente: llamadas recibidas, realizadas, manuales, pausas, sesión, ocupación, formularios y transferencias.','bi-people','Cliente'),
    array('agent_activity','Detalle completo de actividades','Bitácora completa por agente o global: sesiones, pausas, llamadas, formularios, transferencias, números y resultados.','bi-journal-text','PDF completo'),
    array('trend_daily','Comportamiento por día','Totales por día dentro del rango: recibidas, realizadas, abandonadas, pausas, sesiones y tiempo hablado.','bi-calendar3','Día/Semana/Mes'),
    array('calls','Seguimiento unificado de llamadas','Entrantes, salientes de campaña y llamadas manuales por extensión, con número, duración, transferencia y grabación cuando exista.','bi-telephone-inbound','Auditoría'),
    array('manual_direct_calls','Llamadas manuales y directas','Detalle de salientes manuales, devoluciones de llamadas perdidas, internas directas y llamadas recibidas por troncal en la extensión del agente.','bi-telephone-plus','Nuevo'),
    array('pauses','Pausas','Cantidad de pausas, motivo, promedio y tiempo total de pausa por agente.','bi-pause-circle','Cliente'),
    array('sessions','Sesiones','Tiempo logueado por agente, extensión de login, primer ingreso y último logout.','bi-clock-history','Cliente'),
    array('logged_by_hour','Agentes logueados por hora','Cantidad y detalle de agentes conectados por hora para dimensionamiento operativo.','bi-bar-chart-line','Cliente'),
    array('abandoned','Llamadas abandonadas','Detalle de número, cola/campaña, espera y estado.','bi-exclamation-triangle','Cliente'),
    array('callbacks','Devolución de llamadas','Cruza abandonadas con salientes posteriores; muestra extensión que devolvió, agente asociado y origen campaña/manual.','bi-arrow-repeat','Cliente'),
    array('forms','Formularios cargados','Campos y valores cargados por el agente en campañas entrantes y salientes.','bi-ui-checks','Calidad'),
    array('transfers','Transferencias','Llamadas transferidas y destino de transferencia registrado por Call Center.','bi-shuffle','Operativo'),
);
?>
<?php if (!has_permission('reports.export')): ?><div class="alert alert-info border-0 shadow-sm rounded-4"><i class="bi bi-eye"></i> Su usuario puede consultar el centro de reportes, pero no tiene habilitada la descarga CSV/PDF.</div><?php endif; ?>
<div class="row g-3 mb-4">
    <div class="col-xl-8"><div class="card"><div class="card-body"><h4 class="fw-bold mb-2">Reportes preparados para el pedido del cliente</h4><p class="text-muted mb-0">Cada reporte puede descargarse en CSV para Excel o PDF profesional para presentación. El filtro superior aplica a todos: día, semana, mes, rango personalizado, agente específico o global. El reporte “Reporte ejecutivo de productividad” es el más recomendado para gerencia; “Llamadas no atendidas” y “Nivel de servicio por hora” ayudan a tomar decisiones de dotación y calidad de atención.</p></div></div></div>
    <div class="col-xl-4"><div class="card bg-dark text-white"><div class="card-body"><div class="small text-white-50">Rango actual</div><div class="fw-bold"><?php echo e($range['label']); ?></div><div class="small text-white-50 mt-2">Exportación máxima: <?php echo e(app_config('app.max_export_rows')); ?> registros</div></div></div></div>
</div>
<div class="row g-4">
<?php foreach($reports as $r): if (!has_permission(report_required_permission($r[0]))) continue; ?>
<div class="col-md-6 col-xxl-4"><div class="card report-card h-100"><div class="card-body d-flex flex-column">
    <div class="d-flex justify-content-between align-items-start mb-3"><div class="report-icon"><i class="bi <?php echo e($r[3]); ?>"></i></div><span class="badge badge-soft"><?php echo e($r[4]); ?></span></div>
    <h5 class="fw-bold mb-2"><?php echo e($r[1]); ?></h5>
    <p class="text-muted small flex-grow-1"><?php echo e($r[2]); ?></p>
    <div class="btn-group"><a class="btn btn-outline-success btn-sm" href="export.php?report=<?php echo e($r[0]); ?>&format=csv&<?php echo e(build_query_string(array())); ?>"><i class="bi bi-filetype-csv"></i> CSV</a><a class="btn btn-outline-danger btn-sm" href="export.php?report=<?php echo e($r[0]); ?>&format=pdf&<?php echo e(build_query_string(array())); ?>"><i class="bi bi-filetype-pdf"></i> PDF</a></div>
</div></div></div>
<?php endforeach; ?>
</div>
<div class="card mt-4"><div class="card-header"><i class="bi bi-check2-square"></i> Indicadores cubiertos</div><div class="card-body"><div class="row g-3 small">
<?php
$items = array('Cantidad de llamadas realizadas y recibidas','Cantidad de llamadas abandonadas','Tiempo total de llamadas y tiempo hablado real','Cantidad de veces en pausa por agente y total diario','Total de agentes logueados por hora','Reporte de devolución de llamadas','Llamadas transferidas','Llamadas manuales/directas por extensión','Formularios cargados por llamada','Seguimiento detallado de cada llamada');
foreach($items as $it): ?>
<div class="col-md-6 col-xl-4"><div class="d-flex gap-2"><i class="bi bi-check-circle-fill text-success"></i><span><?php echo e($it); ?></span></div></div>
<?php endforeach; ?>
</div></div></div>
<?php include __DIR__ . '/includes/footer.php'; ?>
