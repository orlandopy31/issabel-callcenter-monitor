<?php
require_once __DIR__ . '/includes/bootstrap.php'; require_permission('calls.view');
$repo = new ReportRepository();
$range = range_from_request();
$agentId = current_agent_filter();
$agents = $repo->getAgents();
$type = isset($_GET['type']) ? $_GET['type'] : '';
$q = isset($_GET['q']) ? trim($_GET['q']) : '';
$perPage = (int)app_config('app.records_per_page',30);

$allCalls = $repo->getUnifiedCalls($range['from'],$range['to'],$agentId,$type,(int)app_config('app.max_export_rows',30000));
$allCalls = filter_rows_by_query($allCalls, $q, array('numero_cliente','agente','nombre','tipo_agente','estado','campania','cola','uniqueid','linkedid','grabacion','tipo_llamada'));
$pagination = paginate_array($allCalls, $perPage, 'page');
$calls = $pagination['rows'];

$pageTitle='Seguimiento unificado de llamadas';
$pageSubtitle='Entrantes, salientes de campaña, llamadas manuales por extensión y reproducción segura de grabaciones';
include __DIR__ . '/includes/header.php'; require_once __DIR__ . '/includes/filters.php';
render_filters($agents,$range,$agentId,array('type_filter'=>true,'q_filter'=>true));
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <div>
        <h4 class="fw-bold mb-0"><i class="bi bi-telephone-inbound"></i> Seguimiento exacto por llamada</h4>
        <div class="text-muted small">Vista paginada de 30 registros. La exportación CSV/PDF conserva el rango completo filtrado.</div>
    </div>
    <div class="btn-group">
        <a class="btn btn-outline-success btn-sm" href="export.php?report=calls&format=csv&<?php echo e(build_query_string(array('page'=>null))); ?>"><i class="bi bi-filetype-csv"></i> CSV</a>
        <a class="btn btn-outline-danger btn-sm" href="export.php?report=calls&format=pdf&<?php echo e(build_query_string(array('page'=>null))); ?>"><i class="bi bi-filetype-pdf"></i> PDF</a>
    </div>
</div>
<div class="alert alert-info small">Incluye llamadas entrantes del Call Center, salientes de campaña y llamadas manuales realizadas o recibidas desde la extensión del agente. El sistema evita duplicar registros cuando una misma llamada aparece en más de una fuente.</div>
<div class="card shadow-sm border-0">
    <div class="card-header bg-white d-flex flex-wrap justify-content-between align-items-center gap-2">
        <span class="fw-bold"><i class="bi bi-list-check"></i> Registros de llamadas</span>
        <span class="badge bg-light text-dark border">Total filtrado: <?php echo e($pagination['total']); ?></span>
    </div>
    <div class="card-body table-responsive p-0">
        <table class="table table-hover table-sm align-middle table-polished mb-0">
            <thead><tr><th>Fecha</th><th>Tipo</th><th>Número</th><th>Agente</th><th>Estado</th><th>Hablado</th><th>Total</th><th>Espera</th><th>Transferida</th><th>Campaña/Cola</th><th>Grabación</th><th>Detalle</th></tr></thead>
            <tbody>
            <?php foreach($calls as $r): $recUrl = recording_source_url($r['grabacion']); ?>
            <tr>
                <td class="text-nowrap"><?php echo e($r['fecha_inicio']); ?></td>
                <td><span class="badge badge-soft"><?php echo e($r['tipo_llamada']); ?></span></td>
                <td class="code-small fw-bold"><?php echo e($r['numero_cliente']); ?></td>
                <td><b><?php echo e($r['agente']); ?></b><br><span class="small text-muted"><?php echo e($r['nombre'].' / '.$r['tipo_agente']); ?></span></td>
                <td><span class="badge" data-status-badge><?php echo e($r['estado']); ?></span></td>
                <td><?php echo e($r['tiempo_hablado']); ?></td>
                <td><?php echo e($r['duracion_total']); ?></td>
                <td><?php echo e($r['espera']); ?></td>
                <td><?php if($r['transferida']=='Sí'): ?><span class="badge badge-warn">Sí</span> <?php echo e($r['transferencia']); ?><?php else: ?><span class="badge badge-neutral">No</span><?php endif; ?></td>
                <td><?php echo e(trim(($r['campania']?:'') . ' ' . ($r['cola']?:''))); ?></td>
                <td class="recording-cell">
                    <?php if(!empty($r['grabacion'])): ?>
                        <audio controls preload="none" class="recording-audio">
                            <source src="<?php echo e($recUrl); ?>">
                        </audio>
                        <div class="small text-muted wrap-text mt-1"><?php echo e(basename($r['grabacion'])); ?></div>
                        <a class="small" target="_blank" href="<?php echo e($recUrl); ?>"><i class="bi bi-box-arrow-up-right"></i> abrir</a>
                    <?php else: ?>
                        <span class="text-muted small">Sin grabación</span>
                    <?php endif; ?>
                </td>
                <td><a class="btn btn-sm btn-outline-primary" href="trace.php?uniqueid=<?php echo urlencode($r['uniqueid']); ?>&linkedid=<?php echo urlencode($r['linkedid']); ?>"><i class="bi bi-eye"></i> Ver</a></td>
            </tr>
            <?php endforeach; if(empty($calls)): ?>
            <tr><td colspan="12" class="text-center py-4 text-muted">No se encontraron llamadas con los filtros seleccionados.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php render_pagination($pagination, 'page'); ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
