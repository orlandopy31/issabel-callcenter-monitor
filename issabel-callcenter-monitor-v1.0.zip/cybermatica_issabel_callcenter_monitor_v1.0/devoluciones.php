<?php
/**
 * Vista pública de devoluciones para tablero.
 * No requiere login y no utiliza el menú lateral del panel.
 */
require_once __DIR__ . '/includes/bootstrap.php';
$publicMode = (bool)app_config('auth.public_devoluciones', true);
if (!$publicMode) {
    require_permission('callbacks.view');
}

$repo = new ReportRepository();
$range = range_from_request();
$agentId = current_agent_filter();
$agents = $repo->getAgents();
$perPage = (int)app_config('app.records_per_page', 30);
$status = isset($_GET['status']) ? trim($_GET['status']) : 'todas';
if (!in_array($status, array('pendientes', 'devueltas', 'todas'), true)) {
    $status = 'todas';
}
$q = isset($_GET['q']) ? trim($_GET['q']) : '';
$autoRefreshSeconds = 60;

$allRowsRaw = $repo->getCallbacks($range['from'], $range['to'], $agentId, (int)app_config('app.max_export_rows', 30000));
$allRowsSearch = filter_rows_by_query($allRowsRaw, $q, array(
    'numero_cliente',
    'numero_cliente_original',
    'fecha_abandono',
    'cola',
    'campania',
    'devuelta',
    'fecha_devolucion',
    'extension_devolvio',
    'agente_devolvio',
    'agente_devolvio_numero',
    'agente_devolvio_nombre',
    'tipo_devolucion',
    'origen_devolucion',
    'estado_devolucion',
    'uniqueid_abandono',
    'uniqueid_devolucion',
    'linkedid_devolucion'
));

$totalDevueltas = 0;
$totalPendientes = 0;
foreach ($allRowsSearch as $tmpRow) {
    if (isset($tmpRow['devuelta']) && $tmpRow['devuelta'] === 'Sí') {
        $totalDevueltas++;
    } else {
        $totalPendientes++;
    }
}
$totalGeneralFiltrado = count($allRowsSearch);

$filteredRows = array();
foreach ($allRowsSearch as $r) {
    $isReturned = isset($r['devuelta']) && $r['devuelta'] === 'Sí';
    if ($status === 'devueltas' && !$isReturned) continue;
    if ($status === 'pendientes' && $isReturned) continue;
    $filteredRows[] = $r;
}

$headers = array(
    'numero_cliente' => 'Número perdido',
    'numero_cliente_original' => 'Número original',
    'fecha_abandono' => 'Fecha abandono',
    'espera' => 'Espera',
    'cola' => 'Cola',
    'campania' => 'Campaña',
    'devuelta' => 'Devuelta',
    'fecha_devolucion' => 'Fecha devolución',
    'extension_devolvio' => 'Extensión devolvió',
    'agente_devolvio' => 'Agente devolvió',
    'tipo_devolucion' => 'Tipo',
    'origen_devolucion' => 'Origen',
    'estado_devolucion' => 'Estado',
    'tiempo_hasta_devolucion' => 'Tiempo hasta devolución',
    'uniqueid_abandono' => 'UniqueID abandono',
    'uniqueid_devolucion' => 'UniqueID devolución',
    'linkedid_devolucion' => 'LinkedID devolución'
);

$format = isset($_GET['format']) ? strtolower(trim($_GET['format'])) : '';
if (!$publicMode && in_array($format, array('csv','pdf'), true) && !has_permission('reports.export')) {
    deny_access('Su usuario puede consultar devoluciones, pero no tiene permiso para exportar CSV/PDF.');
}
if ($format === 'csv') {
    $filename = 'devoluciones_' . date('Ymd_His') . '.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    $out = fopen('php://output', 'w');
    fputcsv($out, array_values($headers), ';');
    foreach ($filteredRows as $row) {
        $line = array();
        foreach (array_keys($headers) as $key) {
            $line[] = isset($row[$key]) ? $row[$key] : '';
        }
        fputcsv($out, $line, ';');
    }
    fclose($out);
    exit;
}

if ($format === 'pdf') {
    $pdfRows = array_slice($filteredRows, 0, 1200);
    $pdfHeaders = array(
        'numero_cliente' => 'Número',
        'fecha_abandono' => 'Abandono',
        'espera' => 'Espera',
        'cola' => 'Cola',
        'devuelta' => 'Dev.',
        'fecha_devolucion' => 'Devolución',
        'extension_devolvio' => 'Ext.',
        'agente_devolvio' => 'Agente',
        'tipo_devolucion' => 'Tipo',
        'origen_devolucion' => 'Origen',
        'estado_devolucion' => 'Estado',
        'tiempo_hasta_devolucion' => 'T. devolución'
    );
    $pdf = new SimplePdf('Tablero de devoluciones');
    $pdf->addReportHeader('Tablero de devoluciones', 'Llamadas abandonadas, devueltas y pendientes', array(
        'Rango' => $range['label'],
        'Vista' => ucfirst($status),
        'Generado' => date('d/m/Y H:i'),
        'Registros' => (string)count($filteredRows)
    ));
    $pctDev = $totalGeneralFiltrado > 0 ? round(($totalDevueltas / $totalGeneralFiltrado) * 100, 2) . '%' : '0%';
    $pdf->addSummaryCards(array(
        'No devueltas' => $totalPendientes,
        'Devueltas' => $totalDevueltas,
        'Total analizado' => $totalGeneralFiltrado,
        'Recuperación' => $pctDev
    ));
    $pdf->addTable($pdfHeaders, $pdfRows);
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="devoluciones_' . date('Ymd_His') . '.pdf"');
    echo $pdf->render();
    exit;
}

$pagination = paginate_array($filteredRows, $perPage, 'page');
$rows = $pagination['rows'];
$statusLabels = array(
    'pendientes' => 'No devueltas',
    'devueltas' => 'Devueltas',
    'todas' => 'Todas'
);
$statusSub = array(
    'pendientes' => 'Lista de llamadas abandonadas pendientes de gestión',
    'devueltas' => 'Lista separada de llamadas que ya tuvieron devolución saliente',
    'todas' => 'Vista consolidada de devueltas y no devueltas'
);
$pctDevueltas = $totalGeneralFiltrado > 0 ? round(($totalDevueltas / $totalGeneralFiltrado) * 100, 2) : 0;
$pctPendientes = $totalGeneralFiltrado > 0 ? round(($totalPendientes / $totalGeneralFiltrado) * 100, 2) : 0;
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $publicMode ? 'Tablero público de devoluciones' : 'Devoluciones'; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/css/app.css?v=21" rel="stylesheet">
    <style>
        body { background: #f4f7fb; }
        .public-board-header {
            background: linear-gradient(135deg, #0f766e 0%, #064e3b 100%);
            color: #fff;
            border-radius: 0 0 26px 26px;
            box-shadow: 0 12px 34px rgba(15, 118, 110, .22);
        }
        .public-container { max-width: 1600px; margin: 0 auto; padding: 24px; }
        .board-title { font-size: 1.55rem; font-weight: 800; letter-spacing: -.02em; }
        .board-subtitle { color: rgba(255,255,255,.82); }
        .public-card { border: 0; border-radius: 18px; box-shadow: 0 10px 26px rgba(15, 23, 42, .07); }
        .metric-card { border-radius: 18px; }
        .table-polished thead th { position: sticky; top: 0; z-index: 3; }
        .board-table-wrap { max-height: 68vh; overflow: auto; }
        .status-chip { border-radius: 999px; padding: .35rem .65rem; font-weight: 700; }
        .no-sidebar-note { font-size: .78rem; color: rgba(255,255,255,.75); }
        @media print {
            .no-print { display: none !important; }
            body { background: #fff; }
            .public-board-header { border-radius: 0; box-shadow: none; }
            .board-table-wrap { max-height: none; overflow: visible; }
        }
    </style>
</head>
<body>
<header class="public-board-header mb-4">
    <div class="public-container py-4">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
            <div>
                <div class="board-title"><i class="bi bi-arrow-repeat"></i> Tablero de devolución de llamadas</div>
                <div class="board-subtitle">Abandonadas, devueltas, pendientes, agente que devolvió y extensión utilizada.</div>
                <div class="no-sidebar-note mt-1"><?php echo $publicMode ? 'Vista pública para tablero · Sin login · Sin menú lateral' : 'Vista protegida por usuario y permisos'; ?></div>
            </div>
            <div class="text-end">
                <div class="badge bg-light text-dark fs-6 mb-2"><i class="bi bi-calendar2-week"></i> <?php echo e($range['label']); ?></div><br>
                <span class="badge bg-success-subtle text-success border border-success-subtle"><i class="bi bi-clock-history"></i> Actualizado: <span id="lastUpdatedText"><?php echo e(date('d/m/Y H:i')); ?></span></span><br>
                <span class="badge bg-warning-subtle text-warning-emphasis border border-warning-subtle mt-2"><i class="bi bi-arrow-clockwise"></i> Auto-refresco en <span id="refreshCountdown"><?php echo e($autoRefreshSeconds); ?></span>s</span>
            </div>
        </div>
    </div>
</header>

<main class="public-container pt-0">
    <?php require_once __DIR__ . '/includes/filters.php'; render_filters($agents, $range, $agentId, array('action'=>'devoluciones.php')); ?>

    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
        <div>
            <h4 class="fw-bold mb-0"><i class="bi bi-kanban"></i> Vista: <?php echo e($statusLabels[$status]); ?></h4>
            <div class="text-muted small"><?php echo e($statusSub[$status]); ?>.</div>
        </div>
        <div class="btn-group no-print">
            <?php if ($publicMode || has_permission('reports.export')): ?>
            <a class="btn btn-outline-success btn-sm" href="devoluciones.php?format=csv&<?php echo e(build_query_string(array('page'=>null))); ?>"><i class="bi bi-filetype-csv"></i> CSV</a>
            <a class="btn btn-outline-danger btn-sm" href="devoluciones.php?format=pdf&<?php echo e(build_query_string(array('page'=>null))); ?>"><i class="bi bi-filetype-pdf"></i> PDF</a>
            <?php endif; ?>
            <button class="btn btn-outline-secondary btn-sm" onclick="window.print()"><i class="bi bi-printer"></i> Imprimir</button>
        </div>
    </div>

    <div class="row g-3 mb-3">
        <div class="col-md-3">
            <div class="metric-card h-100">
                <div class="metric-label">No devueltas</div>
                <div class="metric-value text-danger"><?php echo e($totalPendientes); ?></div>
                <div class="metric-sub">Pendientes con filtros actuales</div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="metric-card h-100">
                <div class="metric-label">Devueltas</div>
                <div class="metric-value text-success"><?php echo e($totalDevueltas); ?></div>
                <div class="metric-sub">Con llamada saliente detectada</div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="metric-card h-100">
                <div class="metric-label">Total analizado</div>
                <div class="metric-value"><?php echo e($totalGeneralFiltrado); ?></div>
                <div class="metric-sub">Abandonadas del rango/búsqueda</div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="metric-card h-100">
                <div class="metric-label">Recuperación</div>
                <div class="metric-value text-primary"><?php echo e($pctDevueltas); ?>%</div>
                <div class="metric-sub">Devueltas sobre total analizado</div>
            </div>
        </div>
    </div>

    <div class="card public-card mb-3">
        <div class="card-body">
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
                <div>
                    <div class="fw-bold"><i class="bi bi-graph-up-arrow"></i> Indicador de recuperación</div>
                    <div class="text-muted small">Porcentaje de llamadas abandonadas que ya fueron gestionadas como devolución saliente.</div>
                </div>
                <span class="badge bg-success fs-6"><?php echo e($pctDevueltas); ?>% devueltas</span>
            </div>
            <div class="progress" style="height: 20px;">
                <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo e($pctDevueltas); ?>%" aria-valuenow="<?php echo e($pctDevueltas); ?>" aria-valuemin="0" aria-valuemax="100">Devueltas</div>
                <div class="progress-bar bg-danger" role="progressbar" style="width: <?php echo e($pctPendientes); ?>%" aria-valuenow="<?php echo e($pctPendientes); ?>" aria-valuemin="0" aria-valuemax="100">Pendientes</div>
            </div>
        </div>
    </div>

    <div class="card public-card mb-3 no-print">
        <div class="card-body">
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                <ul class="nav nav-pills gap-1">
                    <li class="nav-item">
                        <a class="nav-link <?php echo $status==='pendientes'?'active':''; ?>" href="devoluciones.php?<?php echo e(build_query_string(array('status'=>'pendientes','page'=>null))); ?>">
                            <i class="bi bi-exclamation-triangle"></i> No devueltas
                            <span class="badge <?php echo $status==='pendientes'?'bg-light text-primary':'bg-danger'; ?> ms-1"><?php echo e($totalPendientes); ?></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $status==='devueltas'?'active':''; ?>" href="devoluciones.php?<?php echo e(build_query_string(array('status'=>'devueltas','page'=>null))); ?>">
                            <i class="bi bi-check2-circle"></i> Devueltas
                            <span class="badge <?php echo $status==='devueltas'?'bg-light text-primary':'bg-success'; ?> ms-1"><?php echo e($totalDevueltas); ?></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $status==='todas'?'active':''; ?>" href="devoluciones.php?<?php echo e(build_query_string(array('status'=>'todas','page'=>null))); ?>">
                            <i class="bi bi-list-check"></i> Todas
                            <span class="badge <?php echo $status==='todas'?'bg-light text-primary':'bg-secondary'; ?> ms-1"><?php echo e($totalGeneralFiltrado); ?></span>
                        </a>
                    </li>
                </ul>
                <span class="badge bg-light text-dark border">Modo actual: <?php echo e($statusLabels[$status]); ?></span>
            </div>
            <form class="row g-2 align-items-end" method="get" action="devoluciones.php">
                <?php foreach($_GET as $k=>$v): if(in_array($k,array('q','page','format'))) continue; ?>
                    <input type="hidden" name="<?php echo e($k); ?>" value="<?php echo e($v); ?>">
                <?php endforeach; ?>
                <div class="col-md-6">
                    <label class="form-label small text-muted">Buscar en la vista actual</label>
                    <input type="text" name="q" class="form-control" value="<?php echo e($q); ?>" placeholder="Número, agente, extensión, estado, campaña, uniqueid...">
                </div>
                <div class="col-md-3">
                    <button class="btn btn-primary w-100"><i class="bi bi-search"></i> Buscar</button>
                </div>
                <div class="col-md-3">
                    <a class="btn btn-outline-secondary w-100" href="devoluciones.php?<?php echo e(build_query_string(array('q'=>null,'page'=>null,'format'=>null))); ?>"><i class="bi bi-x-circle"></i> Limpiar búsqueda</a>
                </div>
            </form>
        </div>
    </div>

    <div class="alert alert-info small">
        <strong>Criterio usado:</strong> una llamada abandonada se considera devuelta cuando el mismo número aparece posteriormente como llamada <strong>saliente</strong>, ya sea desde campaña o desde CDR manual.
    </div>

    <div class="card public-card">
        <div class="card-header bg-white d-flex flex-wrap justify-content-between align-items-center gap-2">
            <span class="fw-bold"><i class="bi bi-table"></i> Detalle - <?php echo e($statusLabels[$status]); ?></span>
            <span class="badge bg-light text-dark border">Página <?php echo e($pagination['page']); ?> · Registros <?php echo e($pagination['from']); ?>-<?php echo e($pagination['to']); ?> de <?php echo e($pagination['total']); ?></span>
        </div>
        <div class="card-body table-responsive p-0 board-table-wrap">
            <table class="table table-hover table-sm table-polished mb-0 align-middle">
                <thead>
                    <tr>
                        <th>Número perdido</th>
                        <th>Fecha abandono</th>
                        <th>Espera</th>
                        <th>Cola/Campaña</th>
                        <th>Devuelta</th>
                        <th>Fecha devolución</th>
                        <th>Extensión devolvió</th>
                        <th>Agente devolvió</th>
                        <th>Tipo</th>
                        <th>Origen</th>
                        <th>Estado</th>
                        <th>Tiempo hasta devolución</th>
                        <th>UniqueID</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach($rows as $r): ?>
                    <tr>
                        <td>
                            <div class="code-small fw-bold"><?php echo e($r['numero_cliente']); ?></div>
                            <?php if(!empty($r['numero_cliente_original']) && $r['numero_cliente_original'] !== $r['numero_cliente']): ?>
                                <div class="text-muted small">Original: <?php echo e($r['numero_cliente_original']); ?></div>
                            <?php endif; ?>
                        </td>
                        <td class="text-nowrap"><?php echo e($r['fecha_abandono']); ?></td>
                        <td><?php echo e($r['espera']); ?></td>
                        <td><?php echo e(trim($r['cola'].' '.$r['campania'])); ?></td>
                        <td><span class="badge bg-<?php echo $r['devuelta']==='Sí'?'success':'danger'; ?>"><?php echo e($r['devuelta']); ?></span></td>
                        <td class="text-nowrap"><?php echo e($r['fecha_devolucion']); ?></td>
                        <td class="fw-bold code-small"><?php echo e($r['extension_devolvio']); ?></td>
                        <td><?php echo e($r['agente_devolvio']); ?></td>
                        <td><span class="badge bg-<?php echo $r['tipo_devolucion']==='Saliente'?'primary':'secondary'; ?>"><?php echo e($r['tipo_devolucion']); ?></span></td>
                        <td><?php echo e($r['origen_devolucion']); ?></td>
                        <td>
                            <?php if (!empty($r['estado_devolucion'])): ?>
                                <span class="badge" data-status-badge><?php echo e($r['estado_devolucion']); ?></span>
                            <?php else: ?>
                                <span class="text-muted small">-</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($r['tiempo_hasta_devolucion']); ?></td>
                        <td>
                            <?php if(!empty($r['uniqueid_devolucion'])): ?>
                                <span class="code-small"><?php echo e($r['uniqueid_devolucion']); ?></span>
                                <?php if(!empty($r['linkedid_devolucion'])): ?><div class="text-muted small">L: <?php echo e($r['linkedid_devolucion']); ?></div><?php endif; ?>
                            <?php else: ?>
                                <span class="text-muted small">Pendiente</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; if(empty($rows)): ?>
                    <tr><td colspan="13" class="text-center py-4 text-muted">No se encontraron registros en la lista <?php echo e(strtolower($statusLabels[$status])); ?> con los filtros seleccionados.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php render_pagination($pagination, 'page'); ?>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/app.js?v=21"></script>
<script>
(function () {
    var seconds = <?php echo (int)$autoRefreshSeconds; ?>;
    var remaining = seconds;
    var countdown = document.getElementById('refreshCountdown');

    function updateCountdown() {
        if (countdown) {
            countdown.textContent = remaining;
        }
    }

    function shouldPauseRefresh() {
        var active = document.activeElement;
        if (!active) return false;
        var tag = (active.tagName || '').toLowerCase();
        return tag === 'input' || tag === 'select' || tag === 'textarea';
    }

    updateCountdown();
    setInterval(function () {
        if (shouldPauseRefresh()) {
            remaining = seconds;
            updateCountdown();
            return;
        }

        remaining -= 1;
        if (remaining <= 0) {
            var url = new URL(window.location.href);
            url.searchParams.set('_refresh', Date.now().toString());
            window.location.replace(url.toString());
            return;
        }
        updateCountdown();
    }, 1000);
})();
</script>
</body>
</html>
