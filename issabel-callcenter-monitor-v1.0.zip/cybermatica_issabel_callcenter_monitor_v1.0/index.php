<?php
require_once __DIR__ . '/includes/bootstrap.php'; require_permission('dashboard.view');
$repo = new ReportRepository();
$range = range_from_request();
$agentId = current_agent_filter();
$agents = $repo->getAgents();
$summary = $repo->getSummary($range['from'], $range['to'], $agentId);
$performance = $repo->getAgentPerformance($range['from'], $range['to'], $agentId);
$trend = $repo->getDailyTrend($range['from'], $range['to'], $agentId);
$hourly = $repo->getHourlyCallVolume($range['from'], $range['to'], $agentId);
$logged = $repo->getLoggedByHour($range['from'], $range['to'], $agentId);
$pageTitle='Dashboard ejecutivo';
$pageSubtitle='Indicadores operativos: volumen por hora, agentes logueados, comportamiento diario, devoluciones y productividad';
include __DIR__ . '/includes/header.php'; require_once __DIR__ . '/includes/filters.php'; render_filters($agents,$range,$agentId);
$totalRecibidas = $summary['incoming'] + $summary['manual_incoming'];
$totalRealizadas = $summary['outgoing_campaign'] + $summary['manual_outgoing'];
$abRate = $totalRecibidas > 0 ? round(($summary['abandoned'] / $totalRecibidas) * 100, 2) . '%' : '0%';
$occ = $summary['session_seconds'] > 0 ? round(($summary['talk_seconds'] / $summary['session_seconds']) * 100, 2) . '%' : '0%';
$pausePct = $summary['session_seconds'] > 0 ? round(($summary['pause_seconds'] / $summary['session_seconds']) * 100, 2) . '%' : '0%';
$cards = array(
    array('Llamadas recibidas',$totalRecibidas,'bi-telephone-inbound','Incluye entrantes Call Center + directas a extensión'),
    array('Llamadas realizadas',$totalRealizadas,'bi-telephone-outbound','Campañas salientes + llamadas manuales'),
    array('Abandonadas',$summary['abandoned'],'bi-exclamation-triangle','Tasa abandono: '.$abRate),
    array('Devueltas',$summary['callbacks_done'],'bi-arrow-counterclockwise','Abandonadas macheadas con llamada saliente posterior'),
    array('Tiempo hablado',seconds_to_hms($summary['talk_seconds']),'bi-stopwatch','Duración hablada real / billsec'),
    array('Pausas',$summary['pause_count'],'bi-pause-circle','Tiempo pausa: '.seconds_to_hms($summary['pause_seconds'])),
    array('Sesiones',$summary['session_count'],'bi-person-check','Tiempo sesión: '.seconds_to_hms($summary['session_seconds'])),
    array('Transferidas',$summary['transferred'],'bi-shuffle','Transferencias detectadas'),
    array('Callbacks pendientes',$summary['callbacks_pending'],'bi-arrow-repeat','Abandonadas aún no devueltas'),
);
?>
<div class="row g-3 mb-4">
<?php foreach($cards as $c): ?>
    <div class="col-sm-6 col-xl-3">
        <div class="card metric-card"><div class="card-body">
            <div class="d-flex justify-content-between align-items-start mb-3"><div class="metric-icon"><i class="bi <?php echo e($c[2]); ?>"></i></div><span class="badge badge-neutral">Periodo</span></div>
            <div class="metric-value"><?php echo e($c[1]); ?></div>
            <div class="metric-label"><?php echo e($c[0]); ?></div>
            <div class="metric-help mt-2"><?php echo e($c[3]); ?></div>
        </div></div>
    </div>
<?php endforeach; ?>
</div>

<div class="row g-4 mb-4">
    <div class="col-xl-8">
        <div class="card h-100"><div class="card-header d-flex justify-content-between align-items-center"><span><i class="bi bi-graph-up-arrow"></i> Comportamiento diario</span><div class="btn-group no-print"><a class="btn btn-outline-success btn-sm" href="export.php?report=trend_daily&format=csv&<?php echo e(build_query_string(array())); ?>">CSV</a><a class="btn btn-outline-danger btn-sm" href="export.php?report=trend_daily&format=pdf&<?php echo e(build_query_string(array())); ?>">PDF</a></div></div><div class="card-body"><div class="chart-box"><canvas id="dailyTrend"></canvas></div><div class="table-responsive mt-3"><table class="table table-sm table-polished mb-0"><thead><tr><th>Fecha</th><th>Recibidas</th><th>Realizadas</th><th>Abandonadas</th><th>Devueltas</th><th>Transferidas</th><th>Hablado</th></tr></thead><tbody><?php foreach(array_slice($trend, -10) as $r): ?><tr><td><?php echo e($r['fecha']); ?></td><td><?php echo e($r['recibidas']); ?></td><td><?php echo e($r['realizadas']); ?></td><td><?php echo e($r['abandonadas']); ?></td><td><span class="badge badge-ok"><?php echo e(isset($r['devueltas']) ? $r['devueltas'] : 0); ?></span></td><td><?php echo e($r['transferidas']); ?></td><td><?php echo e($r['tiempo_hablado']); ?></td></tr><?php endforeach; if(empty($trend)): ?><tr><td colspan="7" class="text-muted text-center">Sin registros en el rango seleccionado.</td></tr><?php endif; ?></tbody></table></div></div></div>
    </div>
    <div class="col-xl-4">
        <div class="card h-100"><div class="card-header"><i class="bi bi-pie-chart"></i> Productividad global</div><div class="card-body">
            <div class="d-flex justify-content-between py-2 border-bottom"><span>Ocupación</span><b><?php echo e($occ); ?></b></div>
            <div class="d-flex justify-content-between py-2 border-bottom"><span>% en pausa</span><b><?php echo e($pausePct); ?></b></div>
            <div class="d-flex justify-content-between py-2 border-bottom"><span>Tasa abandono</span><b><?php echo e($abRate); ?></b></div>
            <div class="d-flex justify-content-between py-2 border-bottom"><span>Formularios cargados</span><b><?php echo e($summary['forms_count']); ?></b></div>
            <div class="d-flex justify-content-between py-2"><span>Callbacks realizados</span><b><?php echo e($summary['callbacks_done']); ?></b></div>
            <div class="mt-4 d-grid gap-2"><a class="btn btn-primary" href="export.php?report=executive_summary&format=pdf&<?php echo e(build_query_string(array())); ?>"><i class="bi bi-filetype-pdf"></i> Descargar resumen ejecutivo PDF</a><a class="btn btn-outline-primary" href="reports.php?<?php echo e(build_query_string(array())); ?>"><i class="bi bi-file-earmark-bar-graph"></i> Ver centro de reportes</a></div>
        </div></div>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-xl-7"><div class="card h-100"><div class="card-header"><i class="bi bi-clock"></i> Volumen por hora</div><div class="card-body"><div class="chart-box"><canvas id="hourlyVolume"></canvas></div><div class="table-responsive mt-3"><table class="table table-sm table-polished mb-0"><thead><tr><th>Hora</th><th>Recibidas</th><th>Realizadas</th><th>Abandonadas</th><th>Devueltas</th></tr></thead><tbody><?php foreach($hourly as $r): if(((int)$r['recibidas']+(int)$r['realizadas']+(int)$r['abandonadas']+(int)(isset($r['devueltas'])?$r['devueltas']:0))===0) continue; ?><tr><td><?php echo e(substr($r['hora'],0,16)); ?></td><td><?php echo e($r['recibidas']); ?></td><td><?php echo e($r['realizadas']); ?></td><td><?php echo e($r['abandonadas']); ?></td><td><span class="badge badge-ok"><?php echo e(isset($r['devueltas']) ? $r['devueltas'] : 0); ?></span></td></tr><?php endforeach; ?></tbody></table><div class="text-muted small mt-2">Incluye llamadas de campañas y llamadas manuales detectadas en CDR.</div></div></div></div></div>
    <div class="col-xl-5"><div class="card h-100"><div class="card-header"><i class="bi bi-person-lines-fill"></i> Agentes logueados por hora</div><div class="card-body"><div class="chart-box"><canvas id="loggedChart"></canvas></div><div class="table-responsive mt-3"><table class="table table-sm table-polished mb-0"><thead><tr><th>Hora</th><th>Logueados</th><th>Detalle</th></tr></thead><tbody><?php foreach($logged as $r): if((int)$r['agentes_logueados']===0) continue; ?><tr><td><?php echo e(substr($r['hora'],0,16)); ?></td><td><b><?php echo e($r['agentes_logueados']); ?></b></td><td class="small text-muted"><?php echo e($r['detalle_agentes']); ?></td></tr><?php endforeach; ?></tbody></table><div class="text-muted small mt-2">Se cuenta cualquier agente con sesión solapada dentro de la hora.</div></div></div></div></div>
</div>

<div class="card"><div class="card-header d-flex justify-content-between align-items-center"><span><i class="bi bi-trophy"></i> Ranking operativo por agente</span><a class="btn btn-outline-primary btn-sm" href="agents.php?<?php echo e(build_query_string(array())); ?>">Ver detalle completo</a></div><div class="card-body table-responsive">
<table class="table table-hover align-middle"><thead><tr><th>Agente</th><th>Tipo</th><th>Recibidas</th><th>Realizadas</th><th>Abandonadas</th><th>Devueltas</th><th>Transferidas</th><th>Hablado</th><th>Sesión</th><th>Pausa</th><th>Ocupación</th><th>Formularios</th></tr></thead><tbody>
<?php $limit=0; foreach($performance as $r): if($limit++>=10) break; ?>
<tr><td><b><?php echo e($r['agente']); ?></b><br><span class="small text-muted"><?php echo e($r['nombre']); ?></span></td><td><span class="badge badge-soft"><?php echo e($r['tipo']); ?></span></td><td><?php echo e($r['recibidas']); ?></td><td><?php echo e($r['realizadas']); ?></td><td><?php echo e($r['abandonadas']); ?></td><td><span class="badge badge-ok"><?php echo e(isset($r['devueltas']) ? $r['devueltas'] : 0); ?></span></td><td><?php echo e($r['transferidas']); ?></td><td><?php echo e($r['tiempo_hablado']); ?></td><td><?php echo e($r['tiempo_sesion']); ?></td><td><?php echo e($r['tiempo_pausa']); ?></td><td><?php echo e($r['ocupacion_pct']); ?></td><td><?php echo e($r['formularios']); ?></td></tr>
<?php endforeach; ?>
</tbody></table></div></div>

<script>
document.addEventListener('DOMContentLoaded', function(){
const trendLabels = <?php echo json_encode(array_map(function($r){return $r['fecha'];},$trend)); ?>;
safeChart('dailyTrend',{type:'bar',data:{labels:trendLabels,datasets:[{label:'Recibidas',data:<?php echo json_encode(array_map(function($r){return (int)$r['recibidas'];},$trend)); ?>},{label:'Realizadas',data:<?php echo json_encode(array_map(function($r){return (int)$r['realizadas'];},$trend)); ?>},{label:'Abandonadas',data:<?php echo json_encode(array_map(function($r){return (int)$r['abandonadas'];},$trend)); ?>},{label:'Devueltas',data:<?php echo json_encode(array_map(function($r){return (int)(isset($r['devueltas']) ? $r['devueltas'] : 0);},$trend)); ?>}]},options:{plugins:{legend:{position:'bottom'}}}});
safeChart('hourlyVolume',{type:'line',data:{labels:<?php echo json_encode(array_map(function($r){return substr($r['hora'],11,5);},$hourly)); ?>,datasets:[{label:'Recibidas',data:<?php echo json_encode(array_map(function($r){return (int)$r['recibidas'];},$hourly)); ?>,tension:.25},{label:'Realizadas',data:<?php echo json_encode(array_map(function($r){return (int)$r['realizadas'];},$hourly)); ?>,tension:.25},{label:'Abandonadas',data:<?php echo json_encode(array_map(function($r){return (int)$r['abandonadas'];},$hourly)); ?>,tension:.25},{label:'Devueltas',data:<?php echo json_encode(array_map(function($r){return (int)(isset($r['devueltas']) ? $r['devueltas'] : 0);},$hourly)); ?>,tension:.25}]},options:{plugins:{legend:{position:'bottom'}}}});
safeChart('loggedChart',{type:'bar',data:{labels:<?php echo json_encode(array_map(function($r){return substr($r['hora'],11,5);},$logged)); ?>,datasets:[{label:'Logueados',data:<?php echo json_encode(array_map(function($r){return (int)$r['agentes_logueados'];},$logged)); ?>}]},options:{plugins:{legend:{display:false}}}});
});
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
