<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_permission('settings.sla.manage');

$currentUser = current_user();
$error = '';
$saved = isset($_GET['saved']) && $_GET['saved'] === '1';
$slaSeconds = report_sla_seconds();
$slaTarget = report_sla_target_pct();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check(isset($_POST['csrf']) ? $_POST['csrf'] : '')) {
        $error = 'La sesión del formulario venció. Recargue la página e intente nuevamente.';
    } else {
        $secondsRaw = isset($_POST['sla_seconds']) ? trim((string)$_POST['sla_seconds']) : '';
        $targetRaw = isset($_POST['sla_target_pct']) ? str_replace(',', '.', trim((string)$_POST['sla_target_pct'])) : '';
        $seconds = filter_var($secondsRaw, FILTER_VALIDATE_INT);
        $target = is_numeric($targetRaw) ? round((float)$targetRaw, 2) : 0;

        if ($seconds === false || $seconds < 1 || $seconds > 600) {
            $error = 'El tiempo SLA debe ser un número entero entre 1 y 600 segundos.';
        } elseif ($target < 1 || $target > 100) {
            $error = 'La meta SLA debe estar entre 1% y 100%.';
        } else {
            try {
                $before = report_sla_policy_label();
                $uid = ($currentUser && !empty($currentUser['id'])) ? (int)$currentUser['id'] : null;
                panel_setting_set('sla_seconds', (string)$seconds, 'Tiempo SLA (segundos)', 'Tiempo máximo de espera para considerar una llamada atendida dentro del SLA.', $uid);
                panel_setting_set('sla_target_pct', number_format($target, 2, '.', ''), 'Meta SLA (%)', 'Porcentaje objetivo de llamadas ofrecidas que deben ser atendidas dentro del tiempo SLA.', $uid);
                $after = report_sla_policy_label();
                auth_audit('settings.sla.update', 'Política SLA modificada de ' . $before . ' a ' . $after . '.');
                redirect('sla_settings.php?saved=1');
            } catch (Exception $e) {
                $error = app_config('app.debug', false) ? $e->getMessage() : 'No se pudo guardar la configuración. Verifique que haya ejecutado la migración SQL de SLA.';
            }
        }
    }
}

$slaSeconds = report_sla_seconds();
$slaTarget = report_sla_target_pct();
$pageTitle = 'Configuración SLA';
$pageSubtitle = 'Definición central de la meta de atención utilizada por los reportes';
include __DIR__ . '/includes/header.php';
?>
<div class="row g-4">
    <div class="col-xl-7">
        <div class="card">
            <div class="card-header d-flex align-items-center gap-2"><i class="bi bi-sliders"></i> Política SLA vigente</div>
            <div class="card-body">
                <?php if ($saved): ?>
                    <div class="alert alert-success"><i class="bi bi-check-circle"></i> La política SLA fue actualizada. Los reportes ya utilizan los nuevos valores.</div>
                <?php endif; ?>
                <?php if ($error !== ''): ?>
                    <div class="alert alert-danger"><i class="bi bi-exclamation-triangle"></i> <?php echo e($error); ?></div>
                <?php endif; ?>

                <div class="alert alert-info border-0" style="border-radius:16px">
                    <div class="fw-bold fs-5 mb-1">SLA actual: <?php echo e(report_sla_policy_label()); ?></div>
                    <div>Ejemplo: <strong>80% / 20 seg</strong> significa que la meta es atender al menos el 80% de las llamadas ofrecidas dentro de los primeros 20 segundos de espera.</div>
                </div>

                <form method="post" autocomplete="off">
                    <input type="hidden" name="csrf" value="<?php echo e(csrf_token()); ?>">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold" for="sla_target_pct">Meta SLA (%)</label>
                            <div class="input-group">
                                <input class="form-control form-control-lg" id="sla_target_pct" name="sla_target_pct" type="number" min="1" max="100" step="0.01" required value="<?php echo e(number_format($slaTarget, 2, '.', '')); ?>">
                                <span class="input-group-text">%</span>
                            </div>
                            <div class="form-text">Porcentaje mínimo que se considera cumplimiento.</div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold" for="sla_seconds">Tiempo SLA</label>
                            <div class="input-group">
                                <input class="form-control form-control-lg" id="sla_seconds" name="sla_seconds" type="number" min="1" max="600" step="1" required value="<?php echo e($slaSeconds); ?>">
                                <span class="input-group-text">segundos</span>
                            </div>
                            <div class="form-text">Espera máxima para considerar una llamada “dentro del SLA”.</div>
                        </div>
                    </div>

                    <div class="mt-4">
                        <div class="small fw-semibold mb-2">Configuraciones rápidas</div>
                        <div class="d-flex flex-wrap gap-2">
                            <button type="button" class="btn btn-outline-secondary btn-sm sla-preset" data-target="80" data-seconds="20">80 / 20</button>
                            <button type="button" class="btn btn-outline-secondary btn-sm sla-preset" data-target="80" data-seconds="30">80 / 30</button>
                            <button type="button" class="btn btn-outline-secondary btn-sm sla-preset" data-target="90" data-seconds="20">90 / 20</button>
                            <button type="button" class="btn btn-outline-secondary btn-sm sla-preset" data-target="90" data-seconds="30">90 / 30</button>
                        </div>
                    </div>

                    <div class="alert alert-warning mt-4 mb-3">
                        <i class="bi bi-exclamation-circle"></i>
                        <strong>Importante:</strong> al modificar estos valores, los reportes históricos se recalculan con la política SLA actualmente vigente. No se altera la información original de llamadas; solo cambia el criterio con el que se clasifican y evalúan.
                    </div>

                    <button class="btn btn-primary" type="submit"><i class="bi bi-save"></i> Guardar configuración SLA</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-xl-5">
        <div class="card mb-4">
            <div class="card-header"><i class="bi bi-info-circle"></i> ¿Qué es el SLA?</div>
            <div class="card-body">
                <p><strong>SLA</strong> significa <em>Service Level Agreement</em> o <strong>Acuerdo de Nivel de Servicio</strong>. En un call center se utiliza para medir qué porcentaje de las llamadas que ingresan son atendidas dentro de un tiempo definido.</p>
                <div class="bg-light rounded-3 p-3 mb-3">
                    <div class="small text-muted">Fórmula usada por este panel</div>
                    <div class="fw-bold">SLA = llamadas atendidas dentro del tiempo / llamadas ofrecidas × 100</div>
                </div>
                <p class="mb-0">Una llamada abandonada o atendida después del tiempo objetivo reduce el SLA. Una devolución posterior se mide por separado como recuperación de llamada y no modifica el SLA real.</p>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><i class="bi bi-bar-chart-line"></i> ¿Dónde impacta?</div>
            <div class="card-body">
                <ul class="mb-0">
                    <li>Nivel de servicio por hora, día, semana y mes.</li>
                    <li>Comparativo de llamadas entrantes.</li>
                    <li>Tablero de productividad y score de agentes.</li>
                    <li>Reportes CSV y PDF relacionados con SLA.</li>
                    <li>Indicador de cumplimiento contra la meta configurada.</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<script>
document.querySelectorAll('.sla-preset').forEach(function(btn){
    btn.addEventListener('click', function(){
        document.getElementById('sla_target_pct').value = btn.dataset.target;
        document.getElementById('sla_seconds').value = btn.dataset.seconds;
    });
});
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
