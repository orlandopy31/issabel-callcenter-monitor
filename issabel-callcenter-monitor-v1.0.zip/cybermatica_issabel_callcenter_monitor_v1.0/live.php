<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_permission('live.view');

$repo = new ReportRepository();
$ami = new AmiClient();
$runtime = $repo->getCurrentAgentRuntime();
$snapshot = $ami->cachedAgentOperationalSnapshot($runtime);
$summary = isset($snapshot['summary']) ? $snapshot['summary'] : array();

$pageTitle = 'Estado operativo del Call Center';
$pageSubtitle = 'Wallboard en tiempo real de agentes y estados de gestión';
include __DIR__ . '/includes/header.php';

$tvMode = isset($_GET['tv']) && $_GET['tv'] === '1';
$company = app_config('app.company', 'Call Center');

function live_kpi_value($summary, $key) {
    return isset($summary[$key]) ? (int)$summary[$key] : 0;
}
?>
<style>
/* ==============================================================
   WALLBOARD LIVE - estilos encapsulados para no afectar el panel
   ============================================================== */
.live-wallboard{
    --wb-navy:#0b172a;
    --wb-navy-2:#10233d;
    --wb-teal:#0f766e;
    --wb-teal-soft:#dff8f3;
    --wb-green:#15803d;
    --wb-green-soft:#e8f8ee;
    --wb-blue:#0369a1;
    --wb-blue-soft:#e6f5fc;
    --wb-amber:#b45309;
    --wb-amber-soft:#fff5dc;
    --wb-violet:#6d28d9;
    --wb-violet-soft:#f2eafe;
    --wb-red:#b91c1c;
    --wb-red-soft:#fdecec;
    --wb-slate:#64748b;
    --wb-slate-soft:#eef2f6;
    --wb-border:#dbe4ec;
    --wb-shadow:0 14px 34px rgba(15,23,42,.08);
}
.live-wallboard .wallboard-hero{
    position:relative;
    overflow:hidden;
    border-radius:28px;
    background:linear-gradient(125deg,var(--wb-navy) 0%,#123654 54%,var(--wb-teal) 130%);
    color:#fff;
    padding:22px 24px;
    box-shadow:0 18px 44px rgba(15,23,42,.17);
    margin-bottom:18px;
}
.live-wallboard .wallboard-hero:after{
    content:"";
    position:absolute;
    width:300px;
    height:300px;
    border-radius:50%;
    right:-110px;
    top:-150px;
    background:rgba(45,212,191,.14);
}
.live-wallboard .hero-content{position:relative;z-index:2;display:flex;justify-content:space-between;gap:20px;align-items:center}
.live-wallboard .hero-company{font-size:.72rem;font-weight:900;letter-spacing:.14em;text-transform:uppercase;color:#99f6e4;margin-bottom:4px}
.live-wallboard .hero-title{font-size:clamp(1.35rem,2vw,2rem);font-weight:900;letter-spacing:-.045em;line-height:1.05;margin:0}
.live-wallboard .hero-subtitle{color:#cbd5e1;font-weight:600;margin-top:7px;font-size:.88rem}
.live-wallboard .hero-right{display:flex;gap:10px;align-items:center;flex-wrap:wrap;justify-content:flex-end}
.live-wallboard .hero-pill{display:inline-flex;align-items:center;gap:8px;padding:9px 12px;border-radius:999px;background:rgba(255,255,255,.10);border:1px solid rgba(255,255,255,.12);font-size:.78rem;font-weight:800;white-space:nowrap}
.live-wallboard .hero-pill .live-dot{margin-right:1px;box-shadow:0 0 0 5px rgba(34,197,94,.15)}
.live-wallboard .hero-clock{font-variant-numeric:tabular-nums;font-size:1rem;letter-spacing:.02em}
.live-wallboard .btn-wallboard{border:1px solid rgba(255,255,255,.22);color:#fff;background:rgba(255,255,255,.08);border-radius:12px;font-weight:800;padding:.48rem .72rem}
.live-wallboard .btn-wallboard:hover{background:#fff;color:var(--wb-navy)}

.live-wallboard .connection-alert{display:none;border:0;border-radius:18px;padding:13px 16px;margin-bottom:16px;background:#fff4e5;color:#8a4b08;box-shadow:var(--wb-shadow);font-weight:700}
.live-wallboard .connection-alert.show{display:flex;align-items:center;gap:10px}

.live-wallboard .kpi-grid{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:12px;margin-bottom:18px}
.live-wallboard .kpi-card{background:#fff;border:1px solid var(--wb-border);border-radius:20px;padding:14px 16px;box-shadow:var(--wb-shadow);min-height:96px;display:flex;align-items:center;gap:13px;position:relative;overflow:hidden}
.live-wallboard .kpi-card:after{content:"";position:absolute;right:-28px;top:-30px;width:95px;height:95px;border-radius:50%;background:currentColor;opacity:.055}
.live-wallboard .kpi-icon{width:44px;height:44px;min-width:44px;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:1.2rem}
.live-wallboard .kpi-copy{min-width:0}
.live-wallboard .kpi-value{font-size:1.75rem;line-height:1;font-weight:950;letter-spacing:-.055em;color:#0f172a;font-variant-numeric:tabular-nums}
.live-wallboard .kpi-label{font-size:.67rem;font-weight:900;letter-spacing:.055em;text-transform:uppercase;color:#64748b;margin-top:6px;white-space:nowrap}
.live-wallboard .kpi-connected{color:var(--wb-blue)} .live-wallboard .kpi-connected .kpi-icon{background:var(--wb-blue-soft);color:var(--wb-blue)}
.live-wallboard .kpi-available{color:var(--wb-green)} .live-wallboard .kpi-available .kpi-icon{background:var(--wb-green-soft);color:var(--wb-green)}
.live-wallboard .kpi-call{color:var(--wb-teal)} .live-wallboard .kpi-call .kpi-icon{background:var(--wb-teal-soft);color:var(--wb-teal)}
.live-wallboard .kpi-pause{color:var(--wb-amber)} .live-wallboard .kpi-pause .kpi-icon{background:var(--wb-amber-soft);color:var(--wb-amber)}
.live-wallboard .kpi-ring{color:var(--wb-violet)} .live-wallboard .kpi-ring .kpi-icon{background:var(--wb-violet-soft);color:var(--wb-violet)}
.live-wallboard .kpi-offline{color:var(--wb-slate)} .live-wallboard .kpi-offline .kpi-icon{background:var(--wb-slate-soft);color:var(--wb-slate)}

.live-wallboard .agents-panel{background:#fff;border:1px solid var(--wb-border);border-radius:24px;box-shadow:var(--wb-shadow);overflow:hidden}
.live-wallboard .agents-panel-head{padding:14px 18px;border-bottom:1px solid var(--wb-border);display:flex;align-items:center;justify-content:space-between;gap:16px;background:linear-gradient(180deg,#fff,#fbfdff)}
.live-wallboard .agents-panel-title{display:flex;align-items:center;gap:10px;font-weight:900;color:#172033}
.live-wallboard .agents-panel-title i{color:var(--wb-teal)}
.live-wallboard .updated-copy{font-size:.75rem;color:#64748b;font-weight:700;text-align:right}
.live-wallboard .updated-copy strong{color:#334155;font-variant-numeric:tabular-nums}
.live-wallboard .agents-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(245px,1fr));gap:12px;padding:14px;background:#f7fafc}

.live-wallboard .agent-card{position:relative;background:#fff;border:1px solid #dfe7ee;border-left:6px solid #94a3b8;border-radius:18px;padding:14px 15px 13px;min-height:150px;box-shadow:0 6px 16px rgba(15,23,42,.045);transition:transform .15s ease,box-shadow .15s ease;overflow:hidden}
.live-wallboard .agent-card:after{content:"";position:absolute;right:-32px;bottom:-42px;width:110px;height:110px;border-radius:50%;background:currentColor;opacity:.035}
.live-wallboard .agent-card:hover{transform:translateY(-2px);box-shadow:0 12px 26px rgba(15,23,42,.08)}
.live-wallboard .agent-card.state-available{border-left-color:var(--wb-green);color:var(--wb-green)}
.live-wallboard .agent-card.state-call{border-left-color:var(--wb-teal);color:var(--wb-teal)}
.live-wallboard .agent-card.state-pause{border-left-color:var(--wb-amber);color:var(--wb-amber)}
.live-wallboard .agent-card.state-ring{border-left-color:var(--wb-violet);color:var(--wb-violet);animation:ringPulse 1.25s ease-in-out infinite alternate}
.live-wallboard .agent-card.state-offline{border-left-color:#94a3b8;color:#64748b;background:#fbfcfd}
.live-wallboard .agent-card.state-activity{border-left-color:var(--wb-blue);color:var(--wb-blue)}
@keyframes ringPulse{from{box-shadow:0 6px 16px rgba(109,40,217,.06)}to{box-shadow:0 8px 24px rgba(109,40,217,.22)}}
.live-wallboard .agent-top{display:flex;align-items:flex-start;justify-content:space-between;gap:10px;position:relative;z-index:2}
.live-wallboard .agent-identity{min-width:0}
.live-wallboard .agent-name{font-size:1.03rem;font-weight:950;color:#111827;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;line-height:1.12}
.live-wallboard .agent-meta{font-size:.74rem;color:#64748b;font-weight:750;margin-top:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.live-wallboard .agent-status{display:inline-flex;align-items:center;gap:6px;border-radius:999px;padding:5px 9px;font-size:.67rem;font-weight:950;letter-spacing:.035em;text-transform:uppercase;white-space:nowrap}
.live-wallboard .state-available .agent-status{background:var(--wb-green-soft);color:var(--wb-green)}
.live-wallboard .state-call .agent-status{background:var(--wb-teal-soft);color:var(--wb-teal)}
.live-wallboard .state-pause .agent-status{background:var(--wb-amber-soft);color:var(--wb-amber)}
.live-wallboard .state-ring .agent-status{background:var(--wb-violet-soft);color:var(--wb-violet)}
.live-wallboard .state-offline .agent-status{background:var(--wb-slate-soft);color:var(--wb-slate)}
.live-wallboard .state-activity .agent-status{background:var(--wb-blue-soft);color:var(--wb-blue)}
.live-wallboard .status-dot{width:7px;height:7px;border-radius:50%;background:currentColor}
.live-wallboard .agent-main-time{font-size:1.55rem;line-height:1;font-weight:950;letter-spacing:-.05em;color:#172033;margin-top:18px;font-variant-numeric:tabular-nums;position:relative;z-index:2}
.live-wallboard .agent-main-label{font-size:.67rem;text-transform:uppercase;letter-spacing:.06em;color:#718096;font-weight:900;margin-top:5px;position:relative;z-index:2}
.live-wallboard .agent-footer{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:12px;padding-top:10px;border-top:1px solid #edf1f5;font-size:.72rem;color:#64748b;font-weight:750;position:relative;z-index:2}
.live-wallboard .agent-footer span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.live-wallboard .agent-footer i{margin-right:4px;color:#94a3b8}
.live-wallboard .empty-agents{grid-column:1/-1;padding:52px 20px;text-align:center;color:#64748b;font-weight:700}

.live-wallboard .wallboard-legend{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:12px;padding:0 4px;color:#64748b;font-size:.72rem;font-weight:700}
.live-wallboard .legend-items{display:flex;gap:13px;flex-wrap:wrap}
.live-wallboard .legend-item{display:inline-flex;align-items:center;gap:5px}
.live-wallboard .legend-dot{width:8px;height:8px;border-radius:50%;display:inline-block}
.live-wallboard .legend-dot.available{background:var(--wb-green)}
.live-wallboard .legend-dot.call{background:var(--wb-teal)}
.live-wallboard .legend-dot.pause{background:var(--wb-amber)}
.live-wallboard .legend-dot.ring{background:var(--wb-violet)}
.live-wallboard .legend-dot.offline{background:#94a3b8}

/* Modo TV: elimina navegación y aprovecha toda la pantalla */
body.wallboard-tv{background:#eef3f7;overflow-x:hidden}
body.wallboard-tv .sidebar,body.wallboard-tv .topbar{display:none!important}
body.wallboard-tv .main-wrap{margin-left:0!important;width:100%!important}
body.wallboard-tv .content{padding:14px 16px 16px!important}
body.wallboard-tv .live-wallboard .wallboard-hero{padding:15px 18px;margin-bottom:12px;border-radius:20px}
body.wallboard-tv .live-wallboard .hero-title{font-size:1.55rem}
body.wallboard-tv .live-wallboard .hero-subtitle{display:none}
body.wallboard-tv .live-wallboard .kpi-grid{gap:9px;margin-bottom:12px}
body.wallboard-tv .live-wallboard .kpi-card{min-height:82px;border-radius:16px;padding:10px 12px}
body.wallboard-tv .live-wallboard .kpi-icon{width:38px;height:38px;min-width:38px;border-radius:12px}
body.wallboard-tv .live-wallboard .kpi-value{font-size:1.55rem}
body.wallboard-tv .live-wallboard .agents-panel{border-radius:18px}
body.wallboard-tv .live-wallboard .agents-panel-head{padding:10px 14px}
body.wallboard-tv .live-wallboard .agents-grid{grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:9px;padding:10px}
body.wallboard-tv .live-wallboard .agent-card{min-height:132px;border-radius:15px;padding:11px 13px 10px}
body.wallboard-tv .live-wallboard .agent-main-time{margin-top:13px;font-size:1.42rem}
body.wallboard-tv .live-wallboard .agent-footer{margin-top:9px;padding-top:8px}
body.wallboard-tv .live-wallboard .wallboard-legend{margin-top:8px}

@media (min-width:1700px){
    body.wallboard-tv .live-wallboard .agents-grid{grid-template-columns:repeat(auto-fit,minmax(250px,1fr))}
    body.wallboard-tv .live-wallboard .agent-name{font-size:1.08rem}
}
@media (max-width:1350px){.live-wallboard .kpi-grid{grid-template-columns:repeat(3,1fr)}}
@media (max-width:780px){
    .live-wallboard .hero-content{align-items:flex-start;flex-direction:column}
    .live-wallboard .hero-right{justify-content:flex-start}
    .live-wallboard .kpi-grid{grid-template-columns:repeat(2,1fr)}
    .live-wallboard .agents-grid{grid-template-columns:1fr}
    .live-wallboard .wallboard-legend{align-items:flex-start;flex-direction:column}
}
</style>

<div class="live-wallboard" id="live-wallboard">
    <section class="wallboard-hero">
        <div class="hero-content">
            <div>
                <div class="hero-company"><?php echo e($company); ?></div>
                <h2 class="hero-title">Estado operativo del Call Center</h2>
                <div class="hero-subtitle">Visión compartida del equipo · estados y tiempos actualizados automáticamente</div>
            </div>
            <div class="hero-right">
                <span class="hero-pill" id="connection-pill"><span class="live-dot"></span><span id="connection-text">En línea</span></span>
                <span class="hero-pill"><i class="bi bi-arrow-repeat"></i> <span id="live-updated"><?php echo e(isset($snapshot['updated_at']) ? $snapshot['updated_at'] : ''); ?></span></span>
                <span class="hero-pill hero-clock"><i class="bi bi-clock"></i> <span id="wall-clock">--:--:--</span></span>
                <button class="btn btn-wallboard" type="button" id="tv-button" onclick="toggleTvMode()" title="Alternar vista para pantalla completa">
                    <i class="bi bi-display"></i> <span id="tv-button-label">Modo TV</span>
                </button>
                <button class="btn btn-wallboard" type="button" onclick="loadLiveAgents(true)" title="Actualizar ahora">
                    <i class="bi bi-arrow-clockwise"></i>
                </button>
            </div>
        </div>
    </section>

    <div class="connection-alert<?php echo empty($snapshot['connected']) ? ' show' : ''; ?>" id="connection-alert">
        <i class="bi bi-exclamation-triangle-fill"></i>
        <span>AMI no respondió. Se muestran temporalmente los últimos datos disponibles del Call Center.</span>
    </div>

    <section class="kpi-grid" aria-label="Resumen operativo">
        <div class="kpi-card kpi-connected">
            <div class="kpi-icon"><i class="bi bi-person-check-fill"></i></div>
            <div class="kpi-copy"><div class="kpi-value" data-kpi="logueados"><?php echo live_kpi_value($summary,'logueados'); ?></div><div class="kpi-label">Conectados</div></div>
        </div>
        <div class="kpi-card kpi-available">
            <div class="kpi-icon"><i class="bi bi-check-circle-fill"></i></div>
            <div class="kpi-copy"><div class="kpi-value" data-kpi="disponibles"><?php echo live_kpi_value($summary,'disponibles'); ?></div><div class="kpi-label">Disponibles</div></div>
        </div>
        <div class="kpi-card kpi-call">
            <div class="kpi-icon"><i class="bi bi-telephone-fill"></i></div>
            <div class="kpi-copy"><div class="kpi-value" data-kpi="en_llamada"><?php echo live_kpi_value($summary,'en_llamada'); ?></div><div class="kpi-label">En llamada</div></div>
        </div>
        <div class="kpi-card kpi-pause">
            <div class="kpi-icon"><i class="bi bi-pause-circle-fill"></i></div>
            <div class="kpi-copy"><div class="kpi-value" data-kpi="en_pausa"><?php echo live_kpi_value($summary,'en_pausa'); ?></div><div class="kpi-label">En pausa</div></div>
        </div>
        <div class="kpi-card kpi-ring">
            <div class="kpi-icon"><i class="bi bi-bell-fill"></i></div>
            <div class="kpi-copy"><div class="kpi-value" data-kpi="timbrando"><?php echo live_kpi_value($summary,'timbrando'); ?></div><div class="kpi-label">Timbrando</div></div>
        </div>
        <div class="kpi-card kpi-offline">
            <div class="kpi-icon"><i class="bi bi-person-x-fill"></i></div>
            <div class="kpi-copy"><div class="kpi-value" data-kpi="desconectados"><?php echo live_kpi_value($summary,'desconectados'); ?></div><div class="kpi-label">Desconectados</div></div>
        </div>
    </section>

    <section class="agents-panel">
        <div class="agents-panel-head">
            <div class="agents-panel-title"><i class="bi bi-grid-1x2-fill"></i> Equipo en tiempo real</div>
            <div class="updated-copy">
                <span id="agents-count"><?php echo live_kpi_value($summary,'total'); ?></span> agentes · actualización automática cada 5 segundos
            </div>
        </div>
        <div class="agents-grid" id="live-agents-grid"></div>
    </section>

    <div class="wallboard-legend">
        <div class="legend-items">
            <span class="legend-item"><span class="legend-dot available"></span> Disponible</span>
            <span class="legend-item"><span class="legend-dot call"></span> En llamada</span>
            <span class="legend-item"><span class="legend-dot pause"></span> En pausa</span>
            <span class="legend-item"><span class="legend-dot ring"></span> Timbrando</span>
            <span class="legend-item"><span class="legend-dot offline"></span> Desconectado</span>
        </div>
        <div><i class="bi bi-shield-check"></i> Vista operativa · sin datos del cliente</div>
    </div>
</div>

<script>
(function(){
    const initialTv = <?php echo $tvMode ? 'true' : 'false'; ?>;
    if(initialTv) document.body.classList.add('wallboard-tv');
})();

function esc(v){
    return (v ?? '').toString().replace(/[&<>'"]/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[s]));
}

function safeText(v, fallback){
    const s = (v ?? '').toString().trim();
    return s === '' ? (fallback || '') : s;
}

function stateInfo(agent){
    const state = safeText(agent.estado_operativo, 'Desconectado').toLowerCase();
    if(state.includes('timbr')) return {cls:'state-ring', icon:'bi-bell-fill', rank:0};
    if(state.includes('llamada')) return {cls:'state-call', icon:'bi-telephone-fill', rank:1};
    if(state.includes('pausa')) return {cls:'state-pause', icon:'bi-pause-circle-fill', rank:2};
    if(state.includes('dispon')) return {cls:'state-available', icon:'bi-check-circle-fill', rank:3};
    if(state.includes('actividad')) return {cls:'state-activity', icon:'bi-activity', rank:4};
    return {cls:'state-offline', icon:'bi-person-x-fill', rank:5};
}

function primaryTimer(agent){
    const state = safeText(agent.estado_operativo, 'Desconectado').toLowerCase();
    if(state.includes('llamada') || state.includes('timbr')){
        return {value:safeText(agent.duracion_llamada_actual,'00:00:00'), label:state.includes('timbr') ? 'Tiempo timbrando' : 'Tiempo en llamada'};
    }
    if(state.includes('pausa')){
        return {value:safeText(agent.tiempo_pausa_actual,'00:00:00'), label:safeText(agent.motivo_pausa,'Tiempo en pausa')};
    }
    if(agent.logueado === 'Sí'){
        return {value:safeText(agent.tiempo_sesion,'00:00:00'), label:'Tiempo de sesión'};
    }
    return {value:'—', label:'Fuera de sesión'};
}

function renderAgents(data){
    const grid = document.getElementById('live-agents-grid');
    const agents = Array.isArray(data.agents) ? [...data.agents] : [];

    agents.sort((a,b) => {
        const ra = stateInfo(a).rank, rb = stateInfo(b).rank;
        if(ra !== rb) return ra-rb;
        return safeText(a.nombre,a.agente).localeCompare(safeText(b.nombre,b.agente),'es',{sensitivity:'base'});
    });

    if(!agents.length){
        grid.innerHTML = '<div class="empty-agents"><i class="bi bi-people fs-2 d-block mb-2"></i>No hay agentes configurados para mostrar.</div>';
    }else{
        grid.innerHTML = agents.map(a => {
            const info = stateInfo(a);
            const timer = primaryTimer(a);
            const agentNo = safeText(a.agente,'—');
            const name = safeText(a.nombre,'Agente ' + agentNo);
            const ext = safeText(a.login_extension,'Sin extensión activa');
            const state = safeText(a.estado_operativo,'Desconectado');
            const sessionText = a.logueado === 'Sí' ? 'Sesión activa' : 'Sin sesión';
            const callType = (state.toLowerCase().includes('llamada') || state.toLowerCase().includes('timbr'))
                ? safeText(a.tipo_llamada_actual,'Gestión telefónica')
                : sessionText;

            return `
                <article class="agent-card ${info.cls}" data-agent="${esc(agentNo)}">
                    <div class="agent-top">
                        <div class="agent-identity">
                            <div class="agent-name" title="${esc(name)}">${esc(name)}</div>
                            <div class="agent-meta">Agente ${esc(agentNo)} · ${esc(ext)}</div>
                        </div>
                        <span class="agent-status"><span class="status-dot"></span>${esc(state)}</span>
                    </div>
                    <div class="agent-main-time">${esc(timer.value)}</div>
                    <div class="agent-main-label">${esc(timer.label)}</div>
                    <div class="agent-footer">
                        <span title="${esc(callType)}"><i class="bi ${info.icon}"></i>${esc(callType)}</span>
                        <span><i class="bi bi-person-badge"></i>${a.logueado === 'Sí' ? 'Activo' : 'Offline'}</span>
                    </div>
                </article>`;
        }).join('');
    }

    const summary = data.summary || {};
    Object.keys(summary).forEach(key => {
        const el = document.querySelector(`[data-kpi="${key}"]`);
        if(el) el.textContent = summary[key];
    });
    const count = document.getElementById('agents-count');
    if(count) count.textContent = summary.total ?? agents.length;

    const updated = document.getElementById('live-updated');
    if(updated) updated.textContent = safeText(data.updated_at,'—');

    updateConnectionState(data.connected !== false, data.cache_status || 'live');
}

function updateConnectionState(connected, cacheStatus){
    const text = document.getElementById('connection-text');
    const alert = document.getElementById('connection-alert');
    const pill = document.getElementById('connection-pill');
    if(connected){
        if(text) text.textContent = cacheStatus === 'cache' ? 'En línea · caché' : 'En línea';
        if(alert) alert.classList.remove('show');
        if(pill) pill.style.background = 'rgba(255,255,255,.10)';
    }else{
        if(text) text.textContent = 'AMI sin respuesta';
        if(alert) alert.classList.add('show');
        if(pill) pill.style.background = 'rgba(245,158,11,.18)';
    }
}

let liveRequestRunning = false;
async function loadLiveAgents(manual){
    if(liveRequestRunning) return;
    liveRequestRunning = true;
    try{
        const res = await fetch('api/live_agents.php?_=' + Date.now() + (manual ? '&manual=1' : ''), {
            cache:'no-store',
            headers:{'Accept':'application/json'}
        });
        if(!res.ok) throw new Error('HTTP ' + res.status);
        const data = await res.json();
        renderAgents(data);
    }catch(err){
        console.error('Error actualizando wallboard:', err);
        const text = document.getElementById('connection-text');
        const alert = document.getElementById('connection-alert');
        if(text) text.textContent = 'Sin actualización';
        if(alert){
            alert.classList.add('show');
            alert.querySelector('span').textContent = 'No fue posible actualizar en este momento. La pantalla conserva el último estado recibido.';
        }
    }finally{
        liveRequestRunning = false;
    }
}

function updateClock(){
    const el = document.getElementById('wall-clock');
    if(!el) return;
    el.textContent = new Intl.DateTimeFormat('es-PY',{
        hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false
    }).format(new Date());
}

async function toggleTvMode(){
    const enable = !document.body.classList.contains('wallboard-tv');
    document.body.classList.toggle('wallboard-tv', enable);
    const label = document.getElementById('tv-button-label');
    if(label) label.textContent = enable ? 'Salir TV' : 'Modo TV';

    const url = new URL(window.location.href);
    if(enable) url.searchParams.set('tv','1'); else url.searchParams.delete('tv');
    history.replaceState({},'',url.toString());

    try{
        if(enable && !document.fullscreenElement && document.documentElement.requestFullscreen){
            await document.documentElement.requestFullscreen();
        }else if(!enable && document.fullscreenElement && document.exitFullscreen){
            await document.exitFullscreen();
        }
    }catch(e){ /* El modo TV visual funciona aunque el navegador bloquee fullscreen. */ }
}

document.addEventListener('fullscreenchange', () => {
    if(!document.fullscreenElement && document.body.classList.contains('wallboard-tv')){
        // Mantener el layout TV aunque el usuario salga de F11/Esc.
        const label = document.getElementById('tv-button-label');
        if(label) label.textContent = 'Salir TV';
    }
});

renderAgents(<?php echo json_encode($snapshot, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>);
updateClock();
setInterval(updateClock,1000);
setInterval(() => loadLiveAgents(false),5000);

if(document.body.classList.contains('wallboard-tv')){
    const label = document.getElementById('tv-button-label');
    if(label) label.textContent = 'Salir TV';
}
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
