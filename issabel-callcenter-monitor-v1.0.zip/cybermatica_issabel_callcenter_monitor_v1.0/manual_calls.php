<?php
require_once __DIR__ . '/includes/bootstrap.php'; require_permission('manual_calls.view');
$repo = new AnalyticsRepository();
$range = range_from_request();
$agentId = current_agent_filter();
$agents = $repo->getAgents();
$q = isset($_GET['q']) ? trim($_GET['q']) : '';
$tipoFilter = isset($_GET['tipo_manual']) ? trim($_GET['tipo_manual']) : '';
$perPage = (int)app_config('app.records_per_page', 30);

$allRows = $repo->getManualDirectCalls($range['from'], $range['to'], $agentId, (int)app_config('app.max_export_rows', 30000));
if ($tipoFilter !== '') {
    $tmp = array();
    foreach ($allRows as $r) {
        if ($tipoFilter === 'devuelta' && $r['devuelta'] === 'Sí') $tmp[] = $r;
        elseif ($tipoFilter === 'saliente_manual' && $r['tipo'] === 'Saliente' && $r['devuelta'] !== 'Sí') $tmp[] = $r;
        elseif ($tipoFilter === 'interna' && $r['clasificacion'] === 'Interna directa') $tmp[] = $r;
        elseif ($tipoFilter === 'troncal' && $r['clasificacion'] === 'Entrante por troncal directa') $tmp[] = $r;
    }
    $allRows = $tmp;
}
$allRows = filter_rows_by_query($allRows, $q, array('numero','numero_normalizado','agente','nombre','extension_relacionada','clasificacion','tipo','estado','uniqueid','linkedid','channel','dstchannel','dcontext','did','grabacion'));
$pagination = paginate_array($allRows, $perPage, 'page');
$rows = $pagination['rows'];

$summary = array('total'=>count($allRows),'devueltas'=>0,'salientes'=>0,'internas'=>0,'troncal'=>0,'talk'=>0);
foreach ($allRows as $r) {
    if ($r['devuelta'] === 'Sí') $summary['devueltas']++;
    if ($r['tipo'] === 'Saliente' && $r['devuelta'] !== 'Sí') $summary['salientes']++;
    if ($r['clasificacion'] === 'Interna directa') $summary['internas']++;
    if ($r['clasificacion'] === 'Entrante por troncal directa') $summary['troncal']++;
    $summary['talk'] += (int)$r['tiempo_hablado_seg'];
}

$pageTitle='Llamadas manuales y directas por agente';
$pageSubtitle='Salientes manuales, devoluciones de llamadas perdidas y llamadas directas recibidas por extensión';
include __DIR__ . '/includes/header.php'; require_once __DIR__ . '/includes/filters.php';
render_filters($agents,$range,$agentId,array('q_filter'=>true));
?>
<form method="get" class="card filter-card border-0 shadow-sm mb-4">
    <input type="hidden" name="period" value="<?php echo e($range['period']); ?>">
    <input type="hidden" name="from" value="<?php echo e($range['from_date']); ?>">
    <input type="hidden" name="to" value="<?php echo e($range['to_date']); ?>">
    <?php if ($agentId !== null): ?><input type="hidden" name="agent_id" value="<?php echo e($agentId); ?>"><?php endif; ?>
    <?php if ($q !== ''): ?><input type="hidden" name="q" value="<?php echo e($q); ?>"><?php endif; ?>
    <div class="card-body py-3">
        <div class="row g-3 align-items-end">
            <div class="col-md-4">
                <label class="form-label">Clasificación</label>
                <select name="tipo_manual" class="form-select">
                    <option value="" <?php echo $tipoFilter===''?'selected':''; ?>>Todas las manuales/directas</option>
                    <option value="devuelta" <?php echo $tipoFilter==='devuelta'?'selected':''; ?>>Devoluciones de llamadas perdidas</option>
                    <option value="saliente_manual" <?php echo $tipoFilter==='saliente_manual'?'selected':''; ?>>Salientes manuales</option>
                    <option value="interna" <?php echo $tipoFilter==='interna'?'selected':''; ?>>Internas recibidas directas</option>
                    <option value="troncal" <?php echo $tipoFilter==='troncal'?'selected':''; ?>>Entrantes directas por troncal</option>
                </select>
            </div>
            <div class="col-md-2 d-grid"><button class="btn btn-primary"><i class="bi bi-funnel"></i> Filtrar tipo</button></div>
        </div>
    </div>
</form>
<div class="row g-3 mb-4">
    <div class="col-md-6 col-xl-2"><div class="metric-card-v11"><span class="metric-title">Total</span><strong><?php echo e($summary['total']); ?></strong><small>registros filtrados</small></div></div>
    <div class="col-md-6 col-xl-2"><div class="metric-card-v11 success"><span class="metric-title">Devueltas</span><strong><?php echo e($summary['devueltas']); ?></strong><small>salientes a perdidas</small></div></div>
    <div class="col-md-6 col-xl-2"><div class="metric-card-v11"><span class="metric-title">Salientes</span><strong><?php echo e($summary['salientes']); ?></strong><small>manuales no callback</small></div></div>
    <div class="col-md-6 col-xl-2"><div class="metric-card-v11 warning"><span class="metric-title">Internas</span><strong><?php echo e($summary['internas']); ?></strong><small>recibidas directas</small></div></div>
    <div class="col-md-6 col-xl-2"><div class="metric-card-v11 danger"><span class="metric-title">Por troncal</span><strong><?php echo e($summary['troncal']); ?></strong><small>entrantes directas</small></div></div>
    <div class="col-md-6 col-xl-2"><div class="metric-card-v11 info"><span class="metric-title">Hablado</span><strong><?php echo e(seconds_to_hms($summary['talk'])); ?></strong><small>tiempo total</small></div></div>
</div>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <div>
        <h4 class="fw-bold mb-0"><i class="bi bi-telephone-plus"></i> Llamadas manuales/directas</h4>
        <div class="text-muted small">Paginación de 30 registros. Identifica devolución, saliente manual, interna directa y entrante por troncal.</div>
    </div>
    <div class="btn-group">
        <a class="btn btn-outline-success btn-sm" href="export.php?report=manual_direct_calls&format=csv&<?php echo e(build_query_string(array('page'=>null))); ?>"><i class="bi bi-filetype-csv"></i> CSV</a>
        <a class="btn btn-outline-danger btn-sm" href="export.php?report=manual_direct_calls&format=pdf&<?php echo e(build_query_string(array('page'=>null))); ?>"><i class="bi bi-filetype-pdf"></i> PDF</a>
    </div>
</div>
<div class="card border-0 shadow-sm">
    <div class="card-header bg-white d-flex flex-wrap justify-content-between align-items-center gap-2">
        <span class="fw-bold"><i class="bi bi-list-ul"></i> Detalle operativo</span>
        <span class="badge bg-light text-dark border">Mostrando <?php echo e($pagination['from']); ?> - <?php echo e($pagination['to']); ?> de <?php echo e($pagination['total']); ?></span>
    </div>
    <div class="card-body p-0 table-responsive">
        <table class="table table-hover table-sm align-middle table-polished mb-0">
            <thead><tr><th>Fecha</th><th>Clasificación</th><th>Tipo</th><th>Número</th><th>Agente / extensión</th><th>Estado</th><th>Hablado</th><th>Canales</th><th>Callback</th><th>Grabación</th><th>Detalle</th></tr></thead>
            <tbody>
            <?php foreach($rows as $r): $recUrl = recording_player_url($r['grabacion'], $r['uniqueid'], $r['linkedid'], $r['fecha'], $r['origen'], $r['destino']); ?>
            <tr>
                <td class="text-nowrap"><?php echo e($r['fecha']); ?></td>
                <td>
                    <?php if($r['devuelta']==='Sí'): ?><span class="badge badge-ok">Devolución</span>
                    <?php elseif($r['clasificacion']==='Entrante por troncal directa'): ?><span class="badge badge-danger-soft">Troncal directa</span>
                    <?php elseif($r['clasificacion']==='Interna directa'): ?><span class="badge badge-warn">Interna directa</span>
                    <?php else: ?><span class="badge badge-soft"><?php echo e($r['clasificacion']); ?></span><?php endif; ?>
                </td>
                <td><?php echo e($r['tipo']); ?></td>
                <td><b class="code-small"><?php echo e($r['numero_normalizado'] ?: $r['numero']); ?></b><br><span class="small text-muted">Original: <?php echo e($r['numero']); ?></span></td>
                <td><b><?php echo e($r['agente']); ?></b> <span class="badge badge-soft"><?php echo e($r['extension_relacionada']); ?></span><br><span class="small text-muted"><?php echo e($r['nombre'].' / '.$r['tipo_agente']); ?></span></td>
                <td><span class="badge" data-status-badge><?php echo e($r['estado']); ?></span></td>
                <td><?php echo e($r['tiempo_hablado']); ?><br><span class="small text-muted">Total <?php echo e($r['duracion_total']); ?></span></td>
                <td class="small wrap-text"><b>Canal:</b> <?php echo e($r['channel']); ?><br><b>Destino:</b> <?php echo e($r['dstchannel']); ?><br><b>Contexto:</b> <?php echo e($r['dcontext']); ?></td>
                <td class="small">
                    <?php if($r['devuelta']==='Sí'): ?>
                        <b>Abandono:</b> <?php echo e($r['fecha_abandono']); ?><br>
                        <b>Espera:</b> <?php echo e($r['espera_abandono']); ?><br>
                        <b>Cola:</b> <?php echo e($r['cola_abandono']); ?>
                    <?php else: ?>
                        <span class="text-muted">No aplica</span>
                    <?php endif; ?>
                </td>
                <td class="recording-cell">
                    <?php if($recUrl !== ''): ?>
                        <audio controls preload="none" class="recording-audio">
                            <source src="<?php echo e($recUrl); ?>">
                            Tu navegador no puede reproducir este audio.
                        </audio>
                        <div class="small text-muted wrap-text mt-1">
                            <?php echo !empty($r['grabacion']) ? e(basename($r['grabacion'])) : 'Búsqueda por UniqueID/LinkedID'; ?>
                        </div>
                        <a class="small" href="<?php echo e($recUrl); ?>" target="_blank"><i class="bi bi-box-arrow-up-right"></i> abrir audio</a>
                    <?php else: ?><span class="text-muted small">Sin grabación</span><?php endif; ?>
                </td>
                <td><a class="btn btn-sm btn-outline-primary" href="trace.php?uniqueid=<?php echo urlencode($r['uniqueid']); ?>&linkedid=<?php echo urlencode($r['linkedid']); ?>"><i class="bi bi-eye"></i> Ver</a></td>
            </tr>
            <?php endforeach; if(empty($rows)): ?>
            <tr><td colspan="11" class="text-center py-4 text-muted">No se encontraron registros manuales/directos con los filtros seleccionados.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php render_pagination($pagination, 'page'); ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
