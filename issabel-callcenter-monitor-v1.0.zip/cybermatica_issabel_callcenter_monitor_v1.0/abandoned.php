<?php
require_once __DIR__ . '/includes/bootstrap.php'; require_permission('abandoned.view');
$repo = new ReportRepository();
$range = range_from_request();
$agentId = current_agent_filter();
$agents = $repo->getAgents();
$perPage = (int)app_config('app.records_per_page',30);
$allRows = $repo->getAbandoned($range['from'],$range['to'],$agentId,(int)app_config('app.max_export_rows',30000));
$pagination = paginate_array($allRows, $perPage, 'page');
$rows = $pagination['rows'];
$pageTitle='Abandonadas - Panel Issabel';
$pageSubtitle='Detalle de llamadas perdidas con paginación y exportación completa';
include __DIR__ . '/includes/header.php'; require_once __DIR__ . '/includes/filters.php'; render_filters($agents,$range,$agentId);
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <div>
        <h4 class="fw-bold mb-0"><i class="bi bi-exclamation-triangle"></i> Llamadas abandonadas</h4>
        <div class="text-muted small">Vista paginada de 30 registros. El PDF/CSV exporta todos los registros del rango filtrado.</div>
    </div>
    <div class="btn-group"><a class="btn btn-outline-success btn-sm" href="export.php?report=abandoned&format=csv&<?php echo e(build_query_string(array('page'=>null))); ?>"><i class="bi bi-filetype-csv"></i> CSV</a><a class="btn btn-outline-danger btn-sm" href="export.php?report=abandoned&format=pdf&<?php echo e(build_query_string(array('page'=>null))); ?>"><i class="bi bi-filetype-pdf"></i> PDF</a></div>
</div>
<div class="card shadow-sm border-0">
    <div class="card-header bg-white d-flex justify-content-between align-items-center"><span class="fw-bold">Detalle de abandonadas</span><span class="badge bg-light text-dark border">Total: <?php echo e($pagination['total']); ?></span></div>
    <div class="card-body table-responsive p-0"><table class="table table-hover table-sm table-polished mb-0"><thead><tr><th>Fecha abandono</th><th>Número</th><th>Espera</th><th>Estado</th><th>Cola</th><th>Campaña</th><th>UniqueID</th></tr></thead><tbody>
    <?php foreach($rows as $r): ?><tr><td class="text-nowrap"><?php echo e($r['fecha_abandono']); ?></td><td class="code-small fw-bold"><?php echo e($r['numero_cliente']); ?></td><td><?php echo e($r['espera']); ?></td><td><span class="badge badge-danger-soft"><?php echo e($r['estado']); ?></span></td><td><?php echo e($r['cola']); ?></td><td><?php echo e($r['campania']); ?></td><td class="code-small"><?php echo e($r['uniqueid']); ?></td></tr><?php endforeach; if(empty($rows)): ?>
    <tr><td colspan="7" class="text-center py-4 text-muted">No se encontraron llamadas abandonadas.</td></tr><?php endif; ?>
    </tbody></table></div>
</div>
<?php render_pagination($pagination, 'page'); ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
