<?php
require_once __DIR__ . '/includes/bootstrap.php'; require_permission('service_level.view');
$repo = new AnalyticsRepository();
$slaSeconds = report_sla_seconds();
$slaTarget = report_sla_target_pct();
$range = range_from_request();
$agentId = current_agent_filter();
$bucket = isset($_GET['bucket']) ? $_GET['bucket'] : 'hour';
if (!in_array($bucket, array('hour','day','week','month'))) $bucket = 'hour';
$agents = $repo->getAgents();
$perPage = (int)app_config('app.records_per_page',30);
$serviceAll = $repo->getServiceLevel($range['from'], $range['to'], $agentId, $bucket);
$lost = $repo->getLostCallsByHour($range['from'], $range['to'], $agentId);
$notAnsweredAll = $repo->getNotAnsweredCalls($range['from'], $range['to'], $agentId, (int)app_config('app.max_export_rows',30000));
$servicePg = paginate_array($serviceAll, $perPage, 'service_page');
$notPg = paginate_array($notAnsweredAll, $perPage, 'not_page');
$service = $servicePg['rows'];
$notAnswered = $notPg['rows'];
$pageTitle='Nivel de servicio y llamadas no atendidas';
$pageSubtitle='Control por cola, agente, hora, día, semana y mes para decisiones operativas';
include __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/filters.php'; render_filters($agents,$range,$agentId,array('hidden'=>array('bucket'=>$bucket)));
$tot = array('ofrecidas'=>0,'atendidas'=>0,'abandonadas'=>0,'devueltas'=>0,'pendientes'=>0,'dentro_sla'=>0);
foreach ($serviceAll as $r) {
    $tot['ofrecidas'] += (int)$r['ofrecidas'];
    $tot['atendidas'] += (int)$r['atendidas'];
    $tot['abandonadas'] += (int)$r['abandonadas'];
    $tot['devueltas'] += isset($r['devueltas']) ? (int)$r['devueltas'] : 0;
    $tot['pendientes'] += isset($r['abandonadas_pendientes']) ? (int)$r['abandonadas_pendientes'] : 0;
    $tot['dentro_sla'] += (int)$r['dentro_sla'];
}
$ns = $tot['ofrecidas']>0 ? round(($tot['dentro_sla']/$tot['ofrecidas'])*100,2) : 0;
$nsAjustado = $tot['ofrecidas']>0 ? round((min($tot['ofrecidas'], $tot['dentro_sla']+$tot['devueltas'])/$tot['ofrecidas'])*100,2) : 0;
$answerRate = $tot['ofrecidas']>0 ? round(($tot['atendidas']/$tot['ofrecidas'])*100,2) : 0;
$abRate = $tot['ofrecidas']>0 ? round(($tot['abandonadas']/$tot['ofrecidas'])*100,2) : 0;
$abNetoRate = $tot['ofrecidas']>0 ? round(($tot['pendientes']/$tot['ofrecidas'])*100,2) : 0;
$returnRate = $tot['abandonadas']>0 ? round(($tot['devueltas']/$tot['abandonadas'])*100,2) : 0;
$slaCumple = $ns >= $slaTarget;
?>
<div class="row g-3 mb-4">
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 info"><span class="metric-title">SLA actual</span><strong><?php echo e($ns); ?>%</strong><small><?php echo e($tot['dentro_sla']); ?> dentro de <?php echo e($slaSeconds); ?> seg.</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 success"><span class="metric-title">Tasa de atención</span><strong><?php echo e($answerRate); ?>%</strong><small><?php echo e($tot['atendidas']); ?> atendidas de <?php echo e($tot['ofrecidas']); ?></small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 danger"><span class="metric-title">Abandono neto</span><strong><?php echo e($abNetoRate); ?>%</strong><small><?php echo e($tot['pendientes']); ?> pendientes / <?php echo e($tot['abandonadas']); ?> abandonadas</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 success"><span class="metric-title">Nivel de devolución</span><strong><?php echo e($returnRate); ?>%</strong><small><?php echo e($tot['devueltas']); ?> abandonadas devueltas</small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 info"><span class="metric-title">Meta SLA</span><strong><?php echo e(rtrim(rtrim(number_format($slaTarget,2,'.',''),'0'),'.')); ?>%</strong><small><?php echo e($slaSeconds); ?> seg. · <?php echo $slaCumple ? '<span class="text-success fw-bold">CUMPLE</span>' : '<span class="text-danger fw-bold">NO CUMPLE</span>'; ?></small></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card-v11 warning"><span class="metric-title">No atendidas totales</span><strong><?php echo e(count($notAnsweredAll)); ?></strong><small>Abandonadas + campañas/manuales sin respuesta</small></div></div>
</div>
<div class="alert alert-info border-0 shadow-sm mb-4" style="border-radius:18px">
    <div class="d-flex gap-3 align-items-start"><i class="bi bi-info-circle fs-4"></i><div>
        <strong>Política SLA vigente: <?php echo e(report_sla_policy_label()); ?>.</strong> El SLA real se calcula como llamadas atendidas dentro de <?php echo e($slaSeconds); ?> segundos / llamadas ofrecidas × 100.
        El <strong>NS ajustado por recuperación</strong> agrega devoluciones posteriores solo como indicador de gestión; no reemplaza el SLA real.
        <?php if (has_permission('settings.sla.manage')): ?><a class="ms-1" href="sla_settings.php">Cambiar configuración SLA</a><?php endif; ?>
    </div></div>
</div>
<div class="card mb-4"><div class="card-body d-flex flex-wrap justify-content-between gap-2 align-items-center"><div><h5 class="fw-bold mb-1">Agrupación del nivel de servicio</h5><div class="text-muted small">Seleccioná cómo querés ver la cola de atención y el rendimiento por agente. Las tablas muestran 30 registros por página.</div></div><div class="btn-group"><a class="btn btn-sm <?php echo $bucket==='hour'?'btn-primary':'btn-outline-primary'; ?>" href="?<?php echo e(build_query_string(array('bucket'=>'hour','service_page'=>null,'not_page'=>null))); ?>">Hora</a><a class="btn btn-sm <?php echo $bucket==='day'?'btn-primary':'btn-outline-primary'; ?>" href="?<?php echo e(build_query_string(array('bucket'=>'day','service_page'=>null,'not_page'=>null))); ?>">Día</a><a class="btn btn-sm <?php echo $bucket==='week'?'btn-primary':'btn-outline-primary'; ?>" href="?<?php echo e(build_query_string(array('bucket'=>'week','service_page'=>null,'not_page'=>null))); ?>">Semana</a><a class="btn btn-sm <?php echo $bucket==='month'?'btn-primary':'btn-outline-primary'; ?>" href="?<?php echo e(build_query_string(array('bucket'=>'month','service_page'=>null,'not_page'=>null))); ?>">Mes</a></div></div></div>
<div class="row g-4 mb-4">
    <div class="col-xxl-8"><div class="card"><div class="card-header d-flex flex-wrap justify-content-between gap-2"><span><i class="bi bi-activity"></i> Nivel de servicio por <?php echo e($bucket); ?></span><div class="d-flex gap-2"><a class="btn btn-sm btn-outline-danger" href="export.php?report=service_level_<?php echo e($bucket); ?>&format=pdf&<?php echo e(build_query_string(array('service_page'=>null,'not_page'=>null))); ?>"><i class="bi bi-filetype-pdf"></i> PDF horizontal</a><a class="btn btn-sm btn-outline-success" href="export.php?report=service_level_<?php echo e($bucket); ?>&format=csv&<?php echo e(build_query_string(array('service_page'=>null,'not_page'=>null))); ?>"><i class="bi bi-filetype-csv"></i> CSV</a></div></div><div class="card-body p-0"><div class="table-responsive"><table class="table table-hover table-polished align-middle mb-0"><thead><tr><th>Periodo</th><th>Cola</th><th>Agente</th><th class="text-end">Ofrecidas</th><th class="text-end">Atendidas</th><th class="text-end">Aband.</th><th class="text-end">Devueltas</th><th class="text-end">Pendientes</th><th class="text-end">SLA</th><th class="text-end">Meta</th><th class="text-center">Cumplimiento</th><th class="text-end">NS ajust. recuperación</th><th class="text-end">Nivel devolución</th><th class="text-end">Abandono neto</th><th>Espera prom.</th><th>Espera máx.</th></tr></thead><tbody><?php foreach($service as $r): ?><tr><td class="fw-bold"><?php echo e($r['periodo']); ?></td><td><?php echo e($r['cola']); ?></td><td><?php echo e($r['agente'].' - '.$r['nombre']); ?></td><td class="text-end"><?php echo e($r['ofrecidas']); ?></td><td class="text-end"><?php echo e($r['atendidas']); ?></td><td class="text-end"><span class="badge badge-danger-soft"><?php echo e($r['abandonadas']); ?></span></td><td class="text-end"><span class="badge badge-ok"><?php echo e(isset($r['devueltas']) ? $r['devueltas'] : 0); ?></span></td><td class="text-end"><span class="badge badge-warn"><?php echo e(isset($r['abandonadas_pendientes']) ? $r['abandonadas_pendientes'] : $r['abandonadas']); ?></span></td><td class="text-end"><span class="badge <?php echo (isset($r['cumple_sla']) && $r['cumple_sla']==='CUMPLE') ? 'text-bg-success' : 'text-bg-danger'; ?>"><?php echo e($r['nivel_servicio_pct']); ?></span></td><td class="text-end"><?php echo e(isset($r['sla_meta_pct']) ? $r['sla_meta_pct'] : number_format($slaTarget,2,'.','').'%'); ?></td><td class="text-center"><span class="badge <?php echo (isset($r['cumple_sla']) && $r['cumple_sla']==='CUMPLE') ? 'text-bg-success' : 'text-bg-danger'; ?>"><?php echo e(isset($r['cumple_sla'])?$r['cumple_sla']:'NO CUMPLE'); ?></span></td><td class="text-end"><span class="badge badge-soft"><?php echo e(isset($r['nivel_servicio_ajustado_pct']) ? $r['nivel_servicio_ajustado_pct'] : $r['nivel_servicio_pct']); ?></span></td><td class="text-end"><?php echo e(isset($r['nivel_devolucion_pct']) ? $r['nivel_devolucion_pct'] : '0.00%'); ?></td><td class="text-end"><?php echo e(isset($r['tasa_abandono_neta_pct']) ? $r['tasa_abandono_neta_pct'] : $r['tasa_abandono_pct']); ?></td><td><?php echo e($r['espera_promedio']); ?></td><td><?php echo e($r['espera_maxima']); ?></td></tr><?php endforeach; if(empty($service)): ?><tr><td colspan="16" class="text-center py-4 text-muted">Sin datos de cola en el rango seleccionado.</td></tr><?php endif; ?></tbody></table></div></div></div><?php render_pagination($servicePg, 'service_page'); ?></div>
    <div class="col-xxl-4"><div class="card h-100"><div class="card-header"><i class="bi bi-graph-down-arrow"></i> Mayor pérdida por horario</div><div class="card-body p-0"><div class="table-responsive"><table class="table table-sm mb-0"><thead><tr><th>Hora</th><th>Cola</th><th class="text-end">Perdidas</th><th>Espera máx.</th></tr></thead><tbody><?php foreach(array_slice($lost,0,14) as $r): ?><tr><td class="fw-bold"><?php echo e($r['hora']); ?></td><td><?php echo e($r['cola']); ?></td><td class="text-end"><span class="badge badge-danger-soft"><?php echo e($r['abandonadas']); ?></span></td><td><?php echo e($r['espera_maxima']); ?></td></tr><?php endforeach; if(empty($lost)): ?><tr><td colspan="4" class="text-center text-muted py-4">Sin abandonadas.</td></tr><?php endif; ?></tbody></table></div></div></div></div>
</div>
<div class="card"><div class="card-header d-flex flex-wrap justify-content-between gap-2"><span><i class="bi bi-telephone-x"></i> Detalle de llamadas no atendidas</span><div class="d-flex gap-2"><a class="btn btn-sm btn-outline-danger" href="export.php?report=not_answered&format=pdf&<?php echo e(build_query_string(array('service_page'=>null,'not_page'=>null))); ?>"><i class="bi bi-filetype-pdf"></i> PDF horizontal</a><a class="btn btn-sm btn-outline-success" href="export.php?report=not_answered&format=csv&<?php echo e(build_query_string(array('service_page'=>null,'not_page'=>null))); ?>"><i class="bi bi-filetype-csv"></i> CSV</a></div></div><div class="card-body p-0"><div class="table-responsive"><table class="table table-hover table-polished mb-0"><thead><tr><th>Fecha</th><th>Fuente</th><th>Agente</th><th>Ext.</th><th>Número</th><th>Tipo</th><th>Estado</th><th>Espera</th><th>Duración</th><th>Detalle</th></tr></thead><tbody><?php foreach($notAnswered as $r): ?><tr><td class="text-nowrap"><?php echo e($r['fecha']); ?></td><td><span class="badge badge-danger-soft"><?php echo e($r['fuente']); ?></span></td><td><?php echo e(trim($r['agente'].' '.$r['nombre'])); ?></td><td><?php echo e($r['extension_login']); ?></td><td class="fw-bold"><?php echo e($r['numero']); ?></td><td><?php echo e($r['tipo_llamada']); ?></td><td><?php echo e($r['estado']); ?></td><td><?php echo e($r['espera']); ?></td><td><?php echo e($r['duracion']); ?></td><td class="wrap-text"><?php echo e($r['detalle']); ?></td></tr><?php endforeach; if(empty($notAnswered)): ?><tr><td colspan="10" class="text-center py-4 text-muted">Sin llamadas no atendidas.</td></tr><?php endif; ?></tbody></table></div></div></div>
<?php render_pagination($notPg, 'not_page'); ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
