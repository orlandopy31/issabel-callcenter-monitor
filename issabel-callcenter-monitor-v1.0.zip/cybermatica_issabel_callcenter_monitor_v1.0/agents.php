<?php
require_once __DIR__ . '/includes/bootstrap.php'; require_permission('agents.view');
$repo = new ReportRepository();
$range = range_from_request();
$agentId = current_agent_filter();
$agents = $repo->getAgents();
$totals = $repo->getAgentTotalReport($range['from'], $range['to'], $agentId);
$pageTitle='Reporte total por agente';
$pageSubtitle='Detalle completo de llamadas, sesiones, pausas, extensión y productividad';
include __DIR__ . '/includes/header.php'; require_once __DIR__ . '/includes/filters.php'; render_filters($agents,$range,$agentId);
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <div>
        <h4 class="fw-bold mb-1">Reporte total de agentes</h4>
        <div class="text-muted">Incluye llamadas entrantes, manuales, campañas, abandonadas devueltas, pausas, logueo, formularios, transferencias y extensión asociada.</div>
    </div>
    <div class="btn-group">
        <a class="btn btn-outline-success btn-sm" href="export.php?report=agent_total&format=csv&<?php echo e(build_query_string(array())); ?>"><i class="bi bi-filetype-csv"></i> CSV total</a>
        <a class="btn btn-outline-danger btn-sm" href="export.php?report=agent_total&format=pdf&<?php echo e(build_query_string(array())); ?>"><i class="bi bi-filetype-pdf"></i> PDF total</a>
        <a class="btn btn-primary btn-sm" href="export.php?report=agent_activity&format=pdf&<?php echo e(build_query_string(array())); ?>"><i class="bi bi-journal-text"></i> Bitácora PDF</a>
    </div>
</div>
<div class="card shadow-sm border-0 mb-4"><div class="card-body table-responsive p-0">
<table class="table table-striped table-hover table-sm align-middle mb-0 wide-table">
<thead><tr>
<th>Agente</th><th>Extensión login</th><th>Sesiones</th><th>Logueo</th><th>Pausas</th><th>Tiempo pausa</th><th>Entrantes CC</th><th>Manual entrante</th><th>Salientes campaña</th><th>Manual saliente</th><th>Total recibidas</th><th>Total realizadas</th><th>Total llamadas</th><th>Abandonadas</th><th>Aband. devueltas</th><th>Transferidas</th><th>Hablado</th><th>Total llamada</th><th>Prom. hablado</th><th>Ocupación</th><th>% Pausa</th><th>Formularios</th>
</tr></thead>
<tbody>
<?php foreach($totals as $r): $isTotal = ($r['agente']==='TOTAL'); ?>
<tr class="<?php echo $isTotal ? 'table-total-row' : ''; ?>">
<td><b><?php echo e($r['agente']); ?></b><br><span class="small text-muted"><?php echo e($r['nombre']); ?> <?php echo $r['tipo'] ? '· '.e($r['tipo']) : ''; ?></span></td>
<td><?php echo e($r['extension_login']); ?></td>
<td><?php echo e($r['sesiones']); ?></td>
<td><?php echo e($r['tiempo_logueo']); ?></td>
<td><?php echo e($r['pausas']); ?></td>
<td><?php echo e($r['tiempo_pausa']); ?></td>
<td><?php echo e($r['entrantes_callcenter']); ?></td>
<td><?php echo e($r['manuales_entrantes']); ?></td>
<td><?php echo e($r['salientes_campania']); ?></td>
<td><?php echo e($r['manuales_salientes']); ?></td>
<td><b><?php echo e($r['total_recibidas']); ?></b></td>
<td><b><?php echo e($r['total_realizadas']); ?></b></td>
<td><b><?php echo e($r['total_llamadas']); ?></b></td>
<td><?php echo e($r['abandonadas']); ?></td>
<td><span class="badge bg-success-subtle text-success border border-success-subtle"><?php echo e(isset($r['abandonadas_devueltas']) ? $r['abandonadas_devueltas'] : 0); ?></span></td>
<td><?php echo e($r['transferidas']); ?></td>
<td><?php echo e($r['tiempo_hablado']); ?></td>
<td><?php echo e($r['tiempo_total_llamadas']); ?></td>
<td><?php echo e($r['promedio_hablado']); ?></td>
<td><?php echo e($r['ocupacion_pct']); ?></td>
<td><?php echo e($r['pausa_pct']); ?></td>
<td><?php echo e($r['formularios']); ?></td>
</tr>
<?php endforeach; ?>
</tbody></table></div></div>
<div class="row g-4">
    <div class="col-xl-6"><div class="card h-100"><div class="card-body"><h5 class="fw-bold"><i class="bi bi-person-lines-fill"></i> Detalle de sesión</h5><p class="text-muted">Para auditar entradas, salidas y pausas exactas por agente, descargá el nuevo reporte de detalle de sesión.</p><a class="btn btn-outline-primary" href="export.php?report=agent_session_detail&format=pdf&<?php echo e(build_query_string(array())); ?>"><i class="bi bi-filetype-pdf"></i> PDF detalle de sesión</a></div></div></div>
    <div class="col-xl-6"><div class="card h-100"><div class="card-body"><h5 class="fw-bold"><i class="bi bi-telephone-outbound"></i> Llamadas manuales</h5><p class="text-muted">Las llamadas manuales salen del CDR y se relacionan con la extensión del agente: PJSIP, SIP o IAX2.</p><a class="btn btn-outline-success" href="export.php?report=calls&type=manual_saliente&format=csv&<?php echo e(build_query_string(array())); ?>"><i class="bi bi-filetype-csv"></i> CSV manuales salientes</a></div></div></div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
